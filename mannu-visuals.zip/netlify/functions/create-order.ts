import QRCode from 'qrcode';
import {
  BUCKETS,
  containsSensitiveCredentials,
  deriveTicketNumber,
  deriveTicketStatus,
  findOrCreateCustomerByPhone,
  getSupabase,
  jsonResponse,
  loadSettingsFromDb,
  maskEmail,
  maskPhone,
  normalizeKenyanPhone,
  safeInsertSingle,
  safeUpdateById,
  writeAuditLog,
} from './_supabase.js';

const ALLOWED_MIME_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
];
const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10 MB

function sanitizeFileName(name: string): string {
  return (name || 'upload')
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/_{2,}/g, '_')
    .slice(0, 90);
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const supabase = getSupabase();

    // 1. Action: Create Signed Upload URL for order-files bucket
    if (body.action === 'create-upload-url') {
      const fileName = sanitizeFileName(String(body.fileName || 'document'));
      const mimeType = String(body.mimeType || 'application/octet-stream').toLowerCase();
      const sizeBytes = Number(body.sizeBytes || 0);

      if (!ALLOWED_MIME_TYPES.includes(mimeType)) {
        return jsonResponse(400, {
          error: 'Unsupported file type. Only JPG, PNG, WEBP and PDF files are allowed.',
        });
      }
      if (sizeBytes <= 0 || sizeBytes > MAX_FILE_BYTES) {
        return jsonResponse(400, {
          error: 'File size must be between 1 byte and 10 MB.',
        });
      }

      const storagePath = `customer-uploads/${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 8)}-${fileName}`;

      const { data, error } = await supabase.storage
        .from(BUCKETS.ORDER_FILES)
        .createSignedUploadUrl(storagePath);

      if (error || !data) {
        return jsonResponse(500, {
          error: error?.message || 'Could not create signed upload URL for order-files bucket.',
        });
      }

      return jsonResponse(200, {
        bucket: BUCKETS.ORDER_FILES,
        storagePath,
        signedUrl: data.signedUrl,
        token: data.token,
      });
    }

    // 2. Action: Create Order in Supabase
    const customerName = String(body.customerName || body.name || '').trim();
    const cleanPhone = normalizeKenyanPhone(
      String(body.customerPhone || body.phone || '')
    );
    const rawEmail = body.customerEmail ?? body.email;
    const customerEmail = rawEmail ? String(rawEmail).trim() : null;
    const serviceCategory = body.serviceCategory;
    const serviceName = String(body.serviceName || '').trim();
    const details = String(body.details || '').trim();

    if (!customerName || customerName.length < 2) {
      return jsonResponse(400, { error: 'Please enter your full name.' });
    }
    if (!cleanPhone) {
      return jsonResponse(400, {
        error: 'Please enter a valid Kenyan phone number (for example 0712 345 678).',
      });
    }
    if (!['government', 'graphic_design', 'other'].includes(serviceCategory)) {
      return jsonResponse(400, { error: 'Please select a valid service category.' });
    }
    if (!serviceName) {
      return jsonResponse(400, { error: 'Please select a specific service.' });
    }

    const combinedText = [
      details,
      body.helpNeeded,
      body.exactText,
      body.eventDetails,
      body.portalName,
    ]
      .filter(Boolean)
      .join(' ');

    if (containsSensitiveCredentials(combinedText)) {
      return jsonResponse(400, {
        error:
          'For your security, do not enter passwords, PINs, or national ID numbers in this form. We will guide you safely on WhatsApp.',
      });
    }

    const incomingFiles = Array.isArray(body.files) ? body.files : [];
    for (const f of incomingFiles) {
      const mime = String(f.mimeType || '').toLowerCase();
      const size = Number(f.sizeBytes || 0);
      if (!ALLOWED_MIME_TYPES.includes(mime)) {
        return jsonResponse(400, {
          error: `Unsupported file type (${f.fileName}). Only JPG, PNG, WEBP and PDF are allowed.`,
        });
      }
      if (size <= 0 || size > MAX_FILE_BYTES) {
        return jsonResponse(400, {
          error: `File "${f.fileName}" exceeds the 10 MB limit.`,
        });
      }
    }

    // Match customer by normalised phone (2547XXXXXXXX) — reuse existing or insert new
    const customer = await findOrCreateCustomerByPhone(supabase, {
      name: customerName,
      phone: cleanPhone,
      email: customerEmail || undefined,
      incrementOrders: 1,
    });

    const deliveryMethod = ['WhatsApp', 'Email', 'Download link'].includes(body.deliveryMethod)
      ? body.deliveryMethod
      : 'WhatsApp';

    const paymentPreference =
      body.paymentPreference === 'pay_later' ? 'pay_later' : 'mpesa_stk';

    // Insert into orders — order_number, ticket_number and tracking_token are generated by database defaults!
    const orderInsertPayload: Record<string, any> = {
      customer_id: customer?.id || null,
      customer_name: customerName,
      customer_phone: cleanPhone,
      customer_email: customerEmail,
      service_category: serviceCategory,
      service_name: serviceName,
      details,
      deadline: body.deadline ? String(body.deadline) : null,
      delivery_method: deliveryMethod,
      portal_name: body.portalName ? String(body.portalName).trim() : null,
      help_needed: body.helpNeeded ? String(body.helpNeeded).trim() : null,
      design_type: body.designType ? String(body.designType).trim() : null,
      exact_text: body.exactText ? String(body.exactText).trim() : null,
      event_details: body.eventDetails ? String(body.eventDetails).trim() : null,
      colour_preferences: body.colourPreferences
        ? String(body.colourPreferences).trim()
        : null,
      size_or_format: body.sizeOrFormat ? String(body.sizeOrFormat).trim() : null,
      has_extra_whatsapp_files: Boolean(body.hasExtraWhatsappFiles),
      document_type: body.documentType ? String(body.documentType).trim() : null,
      page_count: body.pageCount ? String(body.pageCount).trim() : null,
      document_language: body.documentLanguage
        ? String(body.documentLanguage).trim()
        : null,
      status: 'Received',
      ticket_status: 'PENDING_PAYMENT',
      payment_status: 'UNPAID',
      payment_preference: paymentPreference,
      price_kes: 0,
      paid_kes: 0,
    };

    const { data: insertedOrder, error: orderError } = await safeInsertSingle(
      supabase,
      'orders',
      orderInsertPayload
    );

    if (orderError || !insertedOrder) {
      return jsonResponse(500, {
        error: orderError?.message || 'Failed to save order in database.',
      });
    }

    const origin =
      event.headers?.origin ||
      (event.headers?.host ? `https://${event.headers.host}` : process.env.APP_URL) ||
      'https://mannuvisuals.netlify.app';
    const baseOrigin = String(origin).replace(/\/$/, '');

    const ticketNumber = deriveTicketNumber(insertedOrder);
    const ticketStatus = deriveTicketStatus(insertedOrder);
    const verifyUrl = `${baseOrigin}/verify-ticket?ticket=${encodeURIComponent(ticketNumber)}`;

    let qrCodeData = insertedOrder.qr_code_data || '';
    if (!qrCodeData) {
      try {
        qrCodeData = await QRCode.toDataURL(verifyUrl, {
          width: 240,
          margin: 1,
          color: {
            dark: '#0F172A',
            light: '#FFFFFF',
          },
        });
      } catch {
        qrCodeData = verifyUrl;
      }
    }

    // Persist ticket_number and qr_code_data if column exists
    const { data: updatedOrder } = await safeUpdateById(
      supabase,
      'orders',
      insertedOrder.id,
      {
        ticket_number: ticketNumber,
        ticket_status: ticketStatus,
        qr_code_data: qrCodeData,
      }
    );

    const order = updatedOrder || insertedOrder;

    // Upload any attached customer files to order-files bucket & save rows in order_files
    for (const f of incomingFiles) {
      const safeName = sanitizeFileName(f.fileName || 'attachment');
      let storagePath = f.storagePath || '';

      if (!storagePath && f.dataUrl && String(f.dataUrl).startsWith('data:')) {
        const commaIdx = String(f.dataUrl).indexOf(',');
        const base64Data = commaIdx >= 0 ? String(f.dataUrl).slice(commaIdx + 1) : '';
        const buffer = Buffer.from(base64Data, 'base64');
        storagePath = `customer-uploads/${order.id}/${Date.now()}-${safeName}`;

        const { error: uploadErr } = await supabase.storage
          .from(BUCKETS.ORDER_FILES)
          .upload(storagePath, buffer, {
            contentType: f.mimeType,
            upsert: true,
          });

        if (uploadErr) {
          storagePath = `order-files/${order.id}/${safeName}`;
        }
      }

      if (storagePath) {
        await safeInsertSingle(supabase, 'order_files', {
          order_id: order.id,
          file_name: f.fileName || safeName,
          mime_type: f.mimeType,
          size_bytes: Number(f.sizeBytes),
          storage_path: storagePath,
          file_kind: 'customer_upload',
        });
      }
    }

    await writeAuditLog(supabase, {
      actorUsername: 'customer',
      actorRole: 'PUBLIC',
      action: 'ORDER_CREATED',
      targetType: 'order',
      targetId: order.order_number,
      details: `New order ${order.order_number} (Ticket ${ticketNumber}) created for ${serviceName} (${cleanPhone}).`,
    });

    const settings = await loadSettingsFromDb(supabase);
    const trackingUrl = `${baseOrigin}/?order=${encodeURIComponent(order.order_number)}`;

    const waLines = [
      `Hello ${settings.businessName}, I have placed an online order.`,
      `Order Number: ${order.order_number}`,
      `Ticket Number: ${ticketNumber}`,
      `Service: ${order.service_name}`,
      `Name: ${order.customer_name}`,
      `Phone: ${order.customer_phone}`,
      order.portal_name ? `Portal: ${order.portal_name}` : '',
      order.help_needed ? `Help Needed: ${order.help_needed}` : '',
      order.design_type ? `Design Type: ${order.design_type}` : '',
      order.document_type ? `Document Type: ${order.document_type}` : '',
      order.details ? `Details: ${order.details}` : '',
      order.deadline ? `Preferred Date: ${order.deadline}` : '',
      `Delivery Method: ${order.delivery_method}`,
      `Track Order: ${trackingUrl}`,
      `Verify Ticket: ${verifyUrl}`,
    ].filter(Boolean);

    const whatsappUrl = `https://wa.me/${settings.whatsappWaMe}?text=${encodeURIComponent(
      waLines.join('\n')
    )}`;

    return jsonResponse(201, {
      orderNumber: order.order_number,
      ticketNumber,
      ticketStatus,
      qrCodeData,
      verifyUrl,
      trackingToken: order.tracking_token,
      trackingUrl,
      whatsappUrl,
      order: {
        orderNumber: order.order_number,
        ticketNumber,
        ticketStatus,
        qrCodeData,
        verifyUrl,
        customerName: order.customer_name,
        customerPhoneMasked: maskPhone(order.customer_phone),
        customerEmailMasked: maskEmail(order.customer_email),
        serviceName: order.service_name,
        serviceCategory: order.service_category,
        status: order.status,
        paymentStatus: order.payment_status,
        priceKes: Number(order.price_kes || 0),
        paidKes: Number(order.paid_kes || 0),
        balanceKes: 0,
        deadline: order.deadline || null,
        deliveryMethod: order.delivery_method,
        createdAt: order.created_at,
        updatedAt: order.updated_at || order.created_at,
      },
    });
  } catch (err: any) {
    return jsonResponse(400, {
      error: err.message || 'Invalid order request.',
    });
  }
};
