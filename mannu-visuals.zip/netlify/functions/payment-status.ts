import { getSupabase, jsonResponse } from './_supabase.js';

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'GET') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const query = event.queryStringParameters || {};
    const checkoutRequestId = String(
      query.checkoutRequestId || query.checkout_request_id || ''
    ).trim();

    if (!checkoutRequestId) {
      return jsonResponse(400, { error: 'checkoutRequestId is required.' });
    }

    const supabase = getSupabase();

    // Read the payments row by checkout_request_id so the page can show success, cancelled or failed
    const { data: payment, error } = await supabase
      .from('payments')
      .select('*')
      .eq('checkout_request_id', checkoutRequestId)
      .maybeSingle();

    if (error || !payment) {
      return jsonResponse(404, { error: 'Payment record not found.' });
    }

    let receipt: any = null;
    if (payment.status === 'SUCCESS') {
      const { data: rec } = await supabase
        .from('receipts')
        .select('*')
        .eq('payment_id', payment.id)
        .maybeSingle();
      receipt = rec;
    }

    // Determine normalized status for UI: PENDING, SUCCESS, CANCELLED, or FAILED
    let displayStatus = payment.status || 'PENDING';
    if (
      displayStatus === 'FAILED' &&
      (Number(payment.result_code) === 1032 ||
        /cancel/i.test(String(payment.result_desc || '')))
    ) {
      displayStatus = 'CANCELLED';
    }

    return jsonResponse(200, {
      payment: {
        id: payment.id,
        checkoutRequestId: payment.checkout_request_id,
        orderId: payment.order_id || null,
        invoiceId: payment.invoice_id || null,
        orderNumber: payment.order_number || null,
        amountKes: Number(payment.amount_kes ?? payment.amount ?? 0),
        status: displayStatus,
        rawStatus: payment.status,
        mpesaReceiptCode:
          payment.mpesa_receipt_number ||
          payment.mpesa_receipt_code ||
          receipt?.mpesa_receipt_code ||
          null,
        resultCode: payment.result_code ?? null,
        resultDesc: payment.result_desc || null,
        receiptNumber: receipt?.receipt_number || null,
        receiptToken: receipt?.public_token || null,
        updatedAt: payment.updated_at || payment.created_at,
      },
    });
  } catch (err: any) {
    return jsonResponse(500, {
      error: err.message || 'Could not check payment status.',
    });
  }
};
