import {
  BUCKETS,
  getSupabase,
  jsonResponse,
  verifyAdminToken,
} from './_supabase.js';

const ALLOWED_IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_IMAGE_BYTES = 8 * 1024 * 1024; // 8 MB

function sanitizeName(name: string): string {
  return (name || 'design')
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/_{2,}/g, '_')
    .slice(0, 75);
}

function parseDataUrlToBuffer(dataUrl: string): { buffer: Buffer; mimeType: string } | null {
  if (!dataUrl || !dataUrl.startsWith('data:')) return null;
  const commaIdx = dataUrl.indexOf(',');
  if (commaIdx < 0) return null;
  const header = dataUrl.slice(5, commaIdx);
  const mimeType = header.split(';')[0] || 'image/webp';
  const base64 = dataUrl.slice(commaIdx + 1);
  return {
    buffer: Buffer.from(base64, 'base64'),
    mimeType,
  };
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const authHeader = event.headers?.authorization || event.headers?.Authorization;
    const session = verifyAdminToken(authHeader);
    if (!session) {
      return jsonResponse(401, { error: 'Authentication required. Please sign in.' });
    }

    const body = event.body ? JSON.parse(event.body) : {};
    const supabase = getSupabase();

    // 1. Multi-file signed upload URL slots (portfolio-public + portfolio-private)
    if (Array.isArray(body.files)) {
      const slots = [];
      for (const f of body.files) {
        const fileName = sanitizeName(String(f.fileName || 'design.webp'));
        const mimeType = String(f.mimeType || f.contentType || 'image/webp').toLowerCase();
        const sizeBytes = Number(f.sizeBytes || 1024);

        if (!ALLOWED_IMAGE_MIMES.includes(mimeType)) {
          return jsonResponse(400, {
            error: `Unsupported image format (${fileName}). Only JPG, PNG and WEBP are allowed.`,
          });
        }
        if (sizeBytes <= 0 || sizeBytes > MAX_IMAGE_BYTES) {
          return jsonResponse(400, {
            error: `File "${fileName}" exceeds the 8 MB limit.`,
          });
        }

        const prefix = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const baseNameNoExt = fileName.replace(/\.[a-zA-Z0-9]+$/, '');
        const publicStoragePath = `public/${prefix}-${baseNameNoExt}-1200w.webp`;
        const originalStoragePath = `originals/${prefix}-${fileName}`;

        const [signedPub, signedPriv] = await Promise.all([
          supabase.storage
            .from(BUCKETS.PORTFOLIO_PUBLIC)
            .createSignedUploadUrl(publicStoragePath),
          supabase.storage
            .from(BUCKETS.PORTFOLIO_PRIVATE)
            .createSignedUploadUrl(originalStoragePath),
        ]);

        slots.push({
          fileName,
          publicBucket: BUCKETS.PORTFOLIO_PUBLIC,
          privateBucket: BUCKETS.PORTFOLIO_PRIVATE,
          publicPath: publicStoragePath,
          originalPath: `${BUCKETS.PORTFOLIO_PRIVATE}/${originalStoragePath}`,
          signedPublicUploadUrl: signedPub.data?.signedUrl || null,
          signedPrivateUploadUrl: signedPriv.data?.signedUrl || null,
        });
      }

      return jsonResponse(200, { ok: true, slots });
    }

    // 2. Single file upload & signed URL creation
    const fileName = sanitizeName(String(body.fileName || 'design.webp'));
    const contentType = String(body.contentType || body.mimeType || 'image/webp').toLowerCase();
    const sizeBytes = Number(body.sizeBytes || 1024);

    if (!ALLOWED_IMAGE_MIMES.includes(contentType)) {
      return jsonResponse(400, {
        error: 'Unsupported image format. Only JPG, PNG and WEBP are allowed.',
      });
    }
    if (sizeBytes <= 0 || sizeBytes > MAX_IMAGE_BYTES) {
      return jsonResponse(400, {
        error: 'Image file size must be under 8 MB.',
      });
    }

    const prefix = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const baseNameNoExt = fileName.replace(/\.[a-zA-Z0-9]+$/, '');

    const thumbStoragePath = `thumbs/${prefix}-${baseNameNoExt}-480w.webp`;
    const mediumStoragePath = `medium/${prefix}-${baseNameNoExt}-1200w.webp`;
    const publicStoragePath = `public/${prefix}-${baseNameNoExt}-1200w.webp`;
    const originalStoragePath = `originals/${prefix}-${fileName}`;

    let thumbUrl = String(body.thumbDataUrl || '');
    let mediumUrl = String(body.mediumDataUrl || '');
    let publicUrl = String(body.publicDataUrl || '');

    const thumbParsed = parseDataUrlToBuffer(thumbUrl);
    if (thumbParsed) {
      const { error } = await supabase.storage
        .from(BUCKETS.PORTFOLIO_PUBLIC)
        .upload(thumbStoragePath, thumbParsed.buffer, {
          contentType: 'image/webp',
          upsert: true,
        });
      if (!error) {
        const { data: pub } = supabase.storage
          .from(BUCKETS.PORTFOLIO_PUBLIC)
          .getPublicUrl(thumbStoragePath);
        if (pub?.publicUrl) thumbUrl = pub.publicUrl;
      }
    }

    const mediumParsed = parseDataUrlToBuffer(mediumUrl);
    if (mediumParsed) {
      const { error } = await supabase.storage
        .from(BUCKETS.PORTFOLIO_PUBLIC)
        .upload(mediumStoragePath, mediumParsed.buffer, {
          contentType: 'image/webp',
          upsert: true,
        });
      if (!error) {
        const { data: pub } = supabase.storage
          .from(BUCKETS.PORTFOLIO_PUBLIC)
          .getPublicUrl(mediumStoragePath);
        if (pub?.publicUrl) mediumUrl = pub.publicUrl;
      }
    }

    const publicParsed = parseDataUrlToBuffer(publicUrl);
    if (publicParsed) {
      const { error } = await supabase.storage
        .from(BUCKETS.PORTFOLIO_PUBLIC)
        .upload(publicStoragePath, publicParsed.buffer, {
          contentType: 'image/webp',
          upsert: true,
        });
      if (!error) {
        const { data: pub } = supabase.storage
          .from(BUCKETS.PORTFOLIO_PUBLIC)
          .getPublicUrl(publicStoragePath);
        if (pub?.publicUrl) publicUrl = pub.publicUrl;
      }
    }

    const originalParsed = parseDataUrlToBuffer(String(body.originalDataUrl || ''));
    if (originalParsed) {
      await supabase.storage
        .from(BUCKETS.PORTFOLIO_PRIVATE)
        .upload(originalStoragePath, originalParsed.buffer, {
          contentType: originalParsed.mimeType,
          upsert: true,
        });
    }

    const [signedPublic, signedPrivate] = await Promise.all([
      supabase.storage.from(BUCKETS.PORTFOLIO_PUBLIC).createSignedUploadUrl(publicStoragePath),
      supabase.storage.from(BUCKETS.PORTFOLIO_PRIVATE).createSignedUploadUrl(originalStoragePath),
    ]);

    return jsonResponse(200, {
      ok: true,
      publicBucket: BUCKETS.PORTFOLIO_PUBLIC,
      privateBucket: BUCKETS.PORTFOLIO_PRIVATE,
      originalPath: `${BUCKETS.PORTFOLIO_PRIVATE}/${originalStoragePath}`,
      thumbUrl: thumbUrl || publicUrl,
      mediumUrl: mediumUrl || publicUrl,
      publicUrl: publicUrl || mediumUrl || thumbUrl,
      signedPublicUploadUrl: signedPublic.data?.signedUrl || null,
      signedPrivateUploadUrl: signedPrivate.data?.signedUrl || null,
    });
  } catch (err: any) {
    return jsonResponse(400, {
      error: err.message || 'Upload preparation error.',
    });
  }
};
