import {
  getSupabase,
  jsonResponse,
  loadSettingsFromDb,
  normalizeKenyanPhone,
  safeInsertSingle,
  writeAuditLog,
} from './_supabase.js';

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const supabase = getSupabase();

    const cleanPhone = normalizeKenyanPhone(String(body.phone || ''));
    if (!cleanPhone) {
      return jsonResponse(400, {
        error: 'Please enter a valid Kenyan M-Pesa phone number (for example 0712 345 678).',
      });
    }

    const orderNumberInput = body.orderNumber
      ? String(body.orderNumber).trim().toUpperCase()
      : '';
    const invoiceTokenInput = body.invoiceToken ? String(body.invoiceToken).trim() : '';

    let order: any = null;
    let invoice: any = null;
    let accountReference = '';
    let maxPayableKes = 0;

    if (invoiceTokenInput) {
      const { data: inv } = await supabase
        .from('invoices')
        .select('*')
        .eq('public_token', invoiceTokenInput)
        .maybeSingle();

      if (!inv) {
        return jsonResponse(404, { error: 'Invoice not found.' });
      }
      invoice = inv;
      const totalKes = Number(inv.total_kes ?? inv.total_amount ?? 0);
      const paidKes = Number(inv.paid_kes ?? inv.amount_paid ?? 0);
      maxPayableKes = Math.max(0, totalKes - paidKes);
      accountReference = inv.invoice_number;

      if (inv.order_id) {
        const { data: linkedOrder } = await supabase
          .from('orders')
          .select('*')
          .eq('id', inv.order_id)
          .maybeSingle();
        if (linkedOrder) {
          order = linkedOrder;
          accountReference = linkedOrder.order_number;
        }
      }
    } else if (orderNumberInput) {
      const { data: ord } = await supabase
        .from('orders')
        .select('*')
        .eq('order_number', orderNumberInput)
        .maybeSingle();

      if (!ord) {
        return jsonResponse(404, { error: 'Order not found.' });
      }
      order = ord;
      const priceKes = Number(ord.price_kes ?? ord.total_amount ?? 0);
      const paidKes = Number(ord.paid_kes ?? ord.amount_paid ?? 0);
      if (priceKes <= 0) {
        return jsonResponse(400, {
          error: 'The price for this order has not been confirmed yet. Please chat on WhatsApp first.',
        });
      }
      maxPayableKes = Math.max(0, priceKes - paidKes);
      accountReference = ord.order_number;
    } else {
      return jsonResponse(400, { error: 'Order number or invoice token is required.' });
    }

    if (maxPayableKes <= 0) {
      return jsonResponse(400, { error: 'This order or invoice is already paid in full.' });
    }

    const requestedAmount = body.amountKes !== undefined ? Number(body.amountKes) : maxPayableKes;
    if (!Number.isInteger(requestedAmount) || requestedAmount <= 0) {
      return jsonResponse(400, {
        error: 'Payment amount must be a whole number in KES greater than 0.',
      });
    }
    if (requestedAmount > maxPayableKes) {
      return jsonResponse(400, {
        error: `Amount cannot exceed the remaining balance of KES ${maxPayableKes.toLocaleString()}.`,
      });
    }

    const settings = await loadSettingsFromDb(supabase);
    const transactionType =
      process.env.DARAJA_TXN_TYPE ||
      process.env.MPESA_TRANSACTION_TYPE ||
      settings.mpesaTransactionType ||
      'CustomerPayBillOnline';

    const consumerKey = process.env.DARAJA_KEY || process.env.MPESA_CONSUMER_KEY || '';
    const consumerSecret = process.env.DARAJA_SECRET || process.env.MPESA_CONSUMER_SECRET || '';
    const shortcode = process.env.DARAJA_SHORTCODE || process.env.MPESA_SHORTCODE || '174379';
    const partyB = process.env.DARAJA_TILL || process.env.MPESA_PARTYB || shortcode;
    const passkey = process.env.DARAJA_PASSKEY || process.env.MPESA_PASSKEY || '';
    const darajaEnv = (process.env.DARAJA_ENV || process.env.MPESA_ENV || 'sandbox').toLowerCase();
    const callbackUrl =
      process.env.DARAJA_CALLBACK_URL ||
      process.env.MPESA_CALLBACK_URL ||
      `${(process.env.APP_URL || 'https://mannuvisuals.netlify.app').replace(
        /\/$/,
        ''
      )}/.netlify/functions/mpesa-callback`;

    let merchantRequestId = `MR_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    let checkoutRequestId = `ws_CO_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    let customerMessage = `STK Push sent to ${cleanPhone} for KES ${requestedAmount.toLocaleString()}. Enter your M-Pesa PIN to complete payment.`;
    let simulatedDaraja = true;

    const hasLiveDarajaCreds =
      consumerKey &&
      consumerSecret &&
      passkey &&
      !consumerKey.includes('your-') &&
      !consumerSecret.includes('your-');

    if (hasLiveDarajaCreds) {
      const baseUrl =
        darajaEnv === 'production'
          ? 'https://api.safaricom.co.ke'
          : 'https://sandbox.safaricom.co.ke';

      const basicAuth = Buffer.from(`${consumerKey}:${consumerSecret}`).toString('base64');
      const tokenRes = await fetch(
        `${baseUrl}/oauth/v1/generate?grant_type=client_credentials`,
        {
          method: 'GET',
          headers: { Authorization: `Basic ${basicAuth}` },
        }
      );

      if (!tokenRes.ok) {
        return jsonResponse(502, {
          error: 'Could not authenticate with Safaricom Daraja API. Check DARAJA_KEY and DARAJA_SECRET.',
        });
      }

      const tokenData: any = await tokenRes.json();
      const accessToken = tokenData.access_token;

      const now = new Date();
      const timestamp =
        now.getFullYear().toString() +
        String(now.getMonth() + 1).padStart(2, '0') +
        String(now.getDate()).padStart(2, '0') +
        String(now.getHours()).padStart(2, '0') +
        String(now.getMinutes()).padStart(2, '0') +
        String(now.getSeconds()).padStart(2, '0');

      const password = Buffer.from(`${shortcode}${passkey}${timestamp}`).toString('base64');

      const stkPayload = {
        BusinessShortCode: shortcode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: transactionType,
        Amount: requestedAmount,
        PartyA: cleanPhone,
        PartyB: partyB,
        PhoneNumber: cleanPhone,
        CallBackURL: callbackUrl,
        AccountReference: accountReference.slice(0, 12),
        TransactionDesc: `Payment for ${accountReference}`.slice(0, 13),
      };

      const stkRes = await fetch(`${baseUrl}/mpesa/stkpush/v1/processrequest`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(stkPayload),
      });

      const stkData: any = await stkRes.json();
      if (!stkRes.ok || stkData.ResponseCode !== '0') {
        return jsonResponse(400, {
          error:
            stkData.CustomerMessage ||
            stkData.errorMessage ||
            'Safaricom Daraja STK Push request could not be completed.',
        });
      }

      merchantRequestId = stkData.MerchantRequestID || merchantRequestId;
      checkoutRequestId = stkData.CheckoutRequestID || checkoutRequestId;
      customerMessage = stkData.CustomerMessage || customerMessage;
      simulatedDaraja = false;
    }

    // Insert PENDING payment row into Supabase payments table with method 'MPESA'
    let { data: payment, error: insertErr } = await safeInsertSingle(supabase, 'payments', {
      order_id: order?.id || null,
      invoice_id: invoice?.id || null,
      order_number: accountReference,
      phone: cleanPhone,
      amount_kes: requestedAmount,
      method: 'MPESA',
      transaction_type: transactionType,
      merchant_request_id: merchantRequestId,
      checkout_request_id: checkoutRequestId,
      status: 'PENDING',
    });

    // If the database check constraint expects 'MPESA_STK' instead of 'MPESA', retry with 'MPESA_STK'
    if (insertErr && /method/i.test(insertErr.message || '')) {
      const retry = await safeInsertSingle(supabase, 'payments', {
        order_id: order?.id || null,
        invoice_id: invoice?.id || null,
        order_number: accountReference,
        phone: cleanPhone,
        amount_kes: requestedAmount,
        method: 'MPESA_STK',
        transaction_type: transactionType,
        merchant_request_id: merchantRequestId,
        checkout_request_id: checkoutRequestId,
        status: 'PENDING',
      });
      payment = retry.data;
      insertErr = retry.error;
    }

    if (insertErr || !payment) {
      return jsonResponse(500, {
        error: insertErr?.message || 'Could not record pending M-Pesa payment in database.',
      });
    }

    await writeAuditLog(supabase, {
      actorUsername: 'customer',
      actorRole: 'PUBLIC',
      action: 'MPESA_STK_INITIATED',
      targetType: 'payment',
      targetId: payment.id,
      details: `Initiated M-Pesa STK Push (${checkoutRequestId}) of KES ${requestedAmount} for ${accountReference} (${cleanPhone}).`,
    });

    return jsonResponse(200, {
      paymentId: payment.id,
      checkoutRequestId,
      merchantRequestId,
      status: 'PENDING',
      amountKes: requestedAmount,
      accountReference,
      customerMessage,
      simulatedDaraja,
    });
  } catch (err: any) {
    return jsonResponse(400, {
      error: err.message || 'Could not initiate M-Pesa payment.',
    });
  }
};
