import {
  deriveTicketNumber,
  getSupabase,
  jsonResponse,
  normalizeKenyanPhone,
  safeUpdateById,
  writeAuditLog,
} from './_supabase.js';

function parseSafaricomTimestamp(rawDate: any): string {
  const s = String(rawDate || '').trim();
  if (/^\d{14}$/.test(s)) {
    const year = s.slice(0, 4);
    const month = s.slice(4, 6);
    const day = s.slice(6, 8);
    const hour = s.slice(8, 10);
    const min = s.slice(10, 12);
    const sec = s.slice(12, 14);
    return `${year}-${month}-${day}T${hour}:${min}:${sec}+03:00`;
  }
  const parsed = Date.parse(s);
  if (!Number.isNaN(parsed)) {
    return new Date(parsed).toISOString();
  }
  return new Date().toISOString();
}

export async function callRecordMpesaPayment(
  supabase: any,
  {
    checkoutRequestId,
    mpesaReceiptNumber,
    amount,
    phone,
    transactionTime,
    rawCallback,
  }: {
    checkoutRequestId: string;
    mpesaReceiptNumber: string;
    amount: number;
    phone: string;
    transactionTime: string;
    rawCallback: any;
  }
) {
  // 1. Try standard p_ prefixed parameter names
  const attempt1 = await supabase.rpc('record_mpesa_payment', {
    p_checkout_request_id: checkoutRequestId,
    p_mpesa_receipt_number: mpesaReceiptNumber,
    p_amount: amount,
    p_phone: phone,
    p_transaction_time: transactionTime,
    p_raw_callback: rawCallback,
  });

  let rpcResult = attempt1;

  if (attempt1.error) {
    // 2. Fallback to unprefixed parameter names if function uses unprefixed args
    const attempt2 = await supabase.rpc('record_mpesa_payment', {
      checkout_request_id: checkoutRequestId,
      mpesa_receipt_number: mpesaReceiptNumber,
      amount,
      phone,
      transaction_time: transactionTime,
      raw_callback: rawCallback,
    });

    if (!attempt2.error) {
      rpcResult = attempt2;
    } else {
      // 3. Fallback to p_mpesa_receipt_code / p_amount_kes variant
      rpcResult = await supabase.rpc('record_mpesa_payment', {
        p_checkout_request_id: checkoutRequestId,
        p_mpesa_receipt_code: mpesaReceiptNumber,
        p_amount_kes: amount,
        p_phone: phone,
        p_transaction_time: transactionTime,
        p_raw_callback: rawCallback,
      });
    }
  }

  // Ensure ticket_status transitions automatically from PENDING_PAYMENT to CONFIRMED upon payment
  try {
    const { data: payRow } = await supabase
      .from('payments')
      .select('id, order_id')
      .eq('checkout_request_id', checkoutRequestId)
      .maybeSingle();

    if (payRow?.order_id) {
      const { data: ordRow } = await supabase
        .from('orders')
        .select('*')
        .eq('id', payRow.order_id)
        .maybeSingle();

      if (
        ordRow &&
        (!ordRow.ticket_status || ordRow.ticket_status === 'PENDING_PAYMENT')
      ) {
        const tktNum = deriveTicketNumber(ordRow);
        await safeUpdateById(supabase, 'orders', ordRow.id, {
          ticket_number: tktNum,
          ticket_status: 'CONFIRMED',
          updated_at: new Date().toISOString(),
        });
        await writeAuditLog(supabase, {
          actorUsername: 'safaricom-daraja',
          actorRole: 'SYSTEM',
          action: 'TICKET_CONFIRMED',
          targetType: 'ticket',
          targetId: tktNum,
          details: `Ticket ${tktNum} for order ${ordRow.order_number} transitioned from PENDING_PAYMENT to CONFIRMED upon M-Pesa payment (${mpesaReceiptNumber}).`,
        });
      }
    }
  } catch {
    // Non-fatal if ticket_status column is handled by DB function
  }

  return rpcResult;
}

export async function callRecordMpesaFailure(
  supabase: any,
  {
    checkoutRequestId,
    resultCode,
    resultDesc,
    rawCallback,
  }: {
    checkoutRequestId: string;
    resultCode: number;
    resultDesc: string;
    rawCallback: any;
  }
) {
  // 1. Try standard p_ prefixed parameter names
  const attempt1 = await supabase.rpc('record_mpesa_failure', {
    p_checkout_request_id: checkoutRequestId,
    p_result_code: resultCode,
    p_result_desc: resultDesc,
    p_raw_callback: rawCallback,
  });

  if (!attempt1.error) return attempt1;

  // 2. Fallback to unprefixed parameter names
  return supabase.rpc('record_mpesa_failure', {
    checkout_request_id: checkoutRequestId,
    result_code: resultCode,
    result_desc: resultDesc,
    raw_callback: rawCallback,
  });
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const rawBody = event.body ? JSON.parse(event.body) : {};
    const supabase = getSupabase();

    // Parse either Safaricom's Body.stkCallback or direct simulation payload
    const stkCallback = rawBody?.Body?.stkCallback;

    let checkoutRequestId = '';
    let resultCode = -1;
    let resultDesc = '';
    let mpesaReceiptNumber = '';
    let amount = 0;
    let phone = '';
    let transactionTime = new Date().toISOString();

    if (stkCallback) {
      checkoutRequestId = String(stkCallback.CheckoutRequestID || '').trim();
      resultCode = Number(stkCallback.ResultCode ?? -1);
      resultDesc = String(stkCallback.ResultDesc || '');

      const items: any[] = stkCallback?.CallbackMetadata?.Item || [];
      for (const item of items) {
        if (item.Name === 'Amount') amount = Math.round(Number(item.Value || 0));
        if (item.Name === 'MpesaReceiptNumber')
          mpesaReceiptNumber = String(item.Value || '').trim();
        if (item.Name === 'PhoneNumber') {
          phone = normalizeKenyanPhone(String(item.Value || '')) || String(item.Value || '');
        }
        if (item.Name === 'TransactionDate') {
          transactionTime = parseSafaricomTimestamp(item.Value);
        }
      }
    } else {
      checkoutRequestId = String(rawBody.checkoutRequestId || '').trim();
      resultCode = Number(rawBody.resultCode ?? 0);
      resultDesc = String(rawBody.resultDesc || 'Processed');
      mpesaReceiptNumber = String(
        rawBody.mpesaReceiptNumber || rawBody.mpesaReceiptCode || ''
      ).trim();
      amount = Math.round(Number(rawBody.amount ?? rawBody.amountKes ?? 0));
      phone =
        normalizeKenyanPhone(String(rawBody.phone || '')) || String(rawBody.phone || '');
      transactionTime = rawBody.transactionTime
        ? parseSafaricomTimestamp(rawBody.transactionTime)
        : new Date().toISOString();
    }

    if (!checkoutRequestId) {
      return jsonResponse(200, {
        ResultCode: 0,
        ResultDesc: 'Accepted',
      });
    }

    if (resultCode === 0) {
      if (!amount || !phone) {
        const { data: existingPayment } = await supabase
          .from('payments')
          .select('*')
          .eq('checkout_request_id', checkoutRequestId)
          .maybeSingle();

        if (existingPayment) {
          if (!amount) {
            amount = Number(existingPayment.amount_kes ?? existingPayment.amount ?? 0);
          }
          if (!phone) {
            phone = existingPayment.phone || existingPayment.payer_phone || '';
          }
        }
      }

      if (!mpesaReceiptNumber) {
        mpesaReceiptNumber = `MPE${Date.now().toString().slice(-7).toUpperCase()}`;
      }

      await callRecordMpesaPayment(supabase, {
        checkoutRequestId,
        mpesaReceiptNumber,
        amount,
        phone,
        transactionTime,
        rawCallback: rawBody,
      });
    } else {
      await callRecordMpesaFailure(supabase, {
        checkoutRequestId,
        resultCode,
        resultDesc: resultDesc || 'Payment failed or cancelled by user',
        rawCallback: rawBody,
      });
    }

    return jsonResponse(200, {
      ResultCode: 0,
      ResultDesc: 'Accepted',
    });
  } catch {
    return jsonResponse(200, {
      ResultCode: 0,
      ResultDesc: 'Accepted',
    });
  }
};
