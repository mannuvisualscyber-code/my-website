import QRCode from 'qrcode';
import {
  BUCKETS,
  DEFAULT_PORTFOLIO_CATEGORIES,
  DEFAULT_SERVICES,
  DEFAULT_SETTINGS,
  deriveOrderNumberFromTicket,
  deriveTicketNumber,
  deriveTicketStatus,
  getSupabase,
  isSupabaseConfigured,
  jsonResponse,
  loadPortfolioCategoriesFromDb,
  loadServicesFromDb,
  loadSettingsFromDb,
  mapServiceRowToClient,
  maskEmail,
  maskPhone,
} from './_supabase.js';

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'GET') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  const query = event.queryStringParameters || {};

  try {
    // 1. Public site bootstrap (settings, services, portfolio categories from Supabase)
    if (query.action === 'bootstrap' || query.publicBootstrap === '1') {
      if (!isSupabaseConfigured()) {
        return jsonResponse(200, {
          settings: DEFAULT_SETTINGS,
          services: DEFAULT_SERVICES.map((s, idx) =>
            mapServiceRowToClient({ id: `srv-${idx + 1}`, ...s })
          ),
          portfolioCategories: DEFAULT_PORTFOLIO_CATEGORIES.map((c, idx) => ({
            id: `cat-${idx + 1}`,
            name: c.name,
            slug: c.slug,
            sortOrder: c.sort_order,
          })),
          supabaseConnected: false,
        });
      }

      const supabase = getSupabase();
      const [settings, services, portfolioCategories] = await Promise.all([
        loadSettingsFromDb(supabase),
        loadServicesFromDb(supabase, false),
        loadPortfolioCategoriesFromDb(supabase),
      ]);

      return jsonResponse(200, {
        settings,
        services,
        portfolioCategories,
        supabaseConnected: true,
      });
    }

    const supabase = getSupabase();

    // 2. Public invoice view by unguessable public_token
    const invoiceTokenParam = query.invoice || query.invoiceToken;
    if (invoiceTokenParam) {
      const token = String(invoiceTokenParam).trim();
      const { data: inv, error: invErr } = await supabase
        .from('invoices')
        .select('*')
        .eq('public_token', token)
        .maybeSingle();

      if (invErr || !inv) {
        return jsonResponse(404, { error: 'Invoice not found.' });
      }

      const [{ data: items }, { data: ord }, { data: rec }] = await Promise.all([
        supabase
          .from('invoice_items')
          .select('*')
          .eq('invoice_id', inv.id)
          .order('sort_order', { ascending: true }),
        inv.order_id
          ? supabase.from('orders').select('order_number').eq('id', inv.order_id).maybeSingle()
          : Promise.resolve({ data: null }),
        supabase
          .from('receipts')
          .select('public_token, receipt_number')
          .eq('invoice_id', inv.id)
          .order('issued_at', { ascending: false })
          .limit(1)
          .maybeSingle(),
      ]);

      const totalKes = Number(inv.total_kes ?? inv.total_amount ?? 0);
      const paidKes = Number(inv.paid_kes ?? inv.amount_paid ?? 0);

      return jsonResponse(200, {
        invoice: {
          invoiceNumber: inv.invoice_number,
          orderNumber: ord?.order_number || null,
          customerName: inv.customer_name,
          customerPhoneMasked: maskPhone(inv.customer_phone),
          items: (items || []).map((it: any) => ({
            id: it.id,
            description: it.description,
            quantity: Number(it.quantity ?? 1),
            unitPriceKes: Number(it.unit_price_kes ?? it.unit_price ?? 0),
            lineTotalKes: Number(it.line_total_kes ?? it.line_total ?? 0),
          })),
          subtotalKes: Number(inv.subtotal_kes ?? inv.subtotal ?? totalKes),
          discountKes: Number(inv.discount_kes ?? inv.discount ?? 0),
          totalKes,
          paidKes,
          balanceKes: Math.max(0, totalKes - paidKes),
          status: inv.status,
          dueDate: inv.due_date || null,
          notes: inv.notes || null,
          publicToken: inv.public_token,
          receiptToken: rec?.public_token || null,
          receiptNumber: rec?.receipt_number || null,
          createdAt: inv.created_at,
        },
      });
    }

    // 3. Public receipt view by unguessable public_token
    const receiptTokenParam = query.receipt || query.receiptToken;
    if (receiptTokenParam) {
      const token = String(receiptTokenParam).trim();
      const { data: rec, error: recErr } = await supabase
        .from('receipts')
        .select('*')
        .eq('public_token', token)
        .maybeSingle();

      if (recErr || !rec) {
        return jsonResponse(404, { error: 'Receipt not found.' });
      }

      return jsonResponse(200, {
        receipt: {
          receiptNumber: rec.receipt_number,
          orderNumber: rec.order_number || 'DIRECT',
          customerName: rec.customer_name,
          customerPhoneMasked: maskPhone(rec.customer_phone),
          serviceDescription: rec.service_description,
          amountKes: Number(rec.amount_kes ?? rec.amount ?? 0),
          paymentMethod: rec.payment_method || rec.method || 'M-Pesa',
          mpesaReceiptCode: rec.mpesa_receipt_code || rec.mpesa_receipt_number || null,
          balanceAfterKes: Number(rec.balance_after_kes ?? rec.balance_after ?? 0),
          publicToken: rec.public_token,
          issuedAt: rec.issued_at || rec.created_at,
        },
      });
    }

    // 4. Order tracking by order_number (MV-XXXX), ticket_number (TKT-YYYY-XXXX), or tracking_token
    const rawOrder = (query.order || query.orderNumber || query.ticket || '').trim().toUpperCase();
    const rawToken = (query.token || '').trim();

    if (!rawOrder && !rawToken) {
      return jsonResponse(400, {
        error: 'Please enter an order number (e.g. MV-4821) or ticket number (e.g. TKT-2026-8942).',
      });
    }

    let order: any = null;

    if (rawToken) {
      const { data } = await supabase
        .from('orders')
        .select('*')
        .eq('tracking_token', rawToken)
        .maybeSingle();
      order = data;
    } else if (rawOrder.startsWith('TKT-')) {
      const { data: byTicket, error: tktErr } = await supabase
        .from('orders')
        .select('*')
        .eq('ticket_number', rawOrder)
        .maybeSingle();

      if (!tktErr && byTicket) {
        order = byTicket;
      } else {
        const derivedMv = deriveOrderNumberFromTicket(rawOrder);
        if (derivedMv) {
          const { data: byDerived } = await supabase
            .from('orders')
            .select('*')
            .eq('order_number', derivedMv)
            .maybeSingle();
          order = byDerived;
        }
      }
    } else {
      const { data } = await supabase
        .from('orders')
        .select('*')
        .eq('order_number', rawOrder)
        .maybeSingle();
      order = data;
    }

    if (!order) {
      return jsonResponse(404, {
        error: 'Order or ticket not found. Please check your MV- order number or TKT- ticket number and try again.',
      });
    }

    const [{ data: files }, { data: payments }, { data: receipts }, { data: invoice }] =
      await Promise.all([
        supabase
          .from('order_files')
          .select('*')
          .eq('order_id', order.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('payments')
          .select('*')
          .eq('order_id', order.id)
          .eq('status', 'SUCCESS')
          .order('created_at', { ascending: false }),
        supabase
          .from('receipts')
          .select('*')
          .eq('order_id', order.id)
          .order('issued_at', { ascending: false }),
        supabase
          .from('invoices')
          .select('public_token, invoice_number')
          .eq('order_id', order.id)
          .maybeSingle(),
      ]);

    const latestPayment = (payments || [])[0] || null;
    const latestReceipt = (receipts || [])[0] || null;
    const deliverableRecord = (files || []).find((f: any) => f.file_kind === 'deliverable');

    let deliverableDownloadUrl = order.deliverable_file_url || null;
    let deliverableFileName =
      order.deliverable_file_name || deliverableRecord?.file_name || null;

    if (deliverableRecord && deliverableRecord.storage_path) {
      if (deliverableRecord.storage_path.startsWith('data:')) {
        deliverableDownloadUrl = deliverableRecord.storage_path;
      } else {
        const { data: signed } = await supabase.storage
          .from(BUCKETS.ORDER_FILES)
          .createSignedUrl(deliverableRecord.storage_path, 3600);
        if (signed?.signedUrl) {
          deliverableDownloadUrl = signed.signedUrl;
        }
      }
    } else if (
      deliverableDownloadUrl &&
      !deliverableDownloadUrl.startsWith('http') &&
      !deliverableDownloadUrl.startsWith('data:')
    ) {
      const { data: signed } = await supabase.storage
        .from(BUCKETS.ORDER_FILES)
        .createSignedUrl(deliverableDownloadUrl, 3600);
      if (signed?.signedUrl) {
        deliverableDownloadUrl = signed.signedUrl;
      }
    }

    const priceKes = Number(order.price_kes ?? order.total_amount ?? 0);
    const paidKes = Number(order.paid_kes ?? order.amount_paid ?? 0);
    const ticketNumber = deriveTicketNumber(order);
    const ticketStatus = deriveTicketStatus(order);

    const origin =
      event.headers?.origin ||
      (event.headers?.host ? `https://${event.headers.host}` : process.env.APP_URL) ||
      'https://mannuvisuals.netlify.app';
    const baseOrigin = String(origin).replace(/\/$/, '');
    const verifyUrl = `${baseOrigin}/verify-ticket?ticket=${encodeURIComponent(ticketNumber)}`;

    let qrCodeData = order.qr_code_data || '';
    if (!qrCodeData) {
      try {
        qrCodeData = await QRCode.toDataURL(verifyUrl, {
          width: 240,
          margin: 1,
          color: {
            dark: '#0F172A',
            light: '#FFFFFF',
          },
        });
      } catch {
        qrCodeData = verifyUrl;
      }
    }

    return jsonResponse(200, {
      order: {
        orderNumber: order.order_number,
        ticketNumber,
        ticketStatus,
        qrCodeData,
        verifyUrl,
        customerName: order.customer_name,
        customerPhoneMasked: maskPhone(order.customer_phone),
        customerEmailMasked: maskEmail(order.customer_email),
        serviceCategory: order.service_category,
        serviceName: order.service_name,
        deliveryMethod: order.delivery_method,
        deadline: order.deadline || null,
        status: order.status,
        paymentStatus: order.payment_status,
        priceKes,
        paidKes,
        balanceKes: Math.max(0, priceKes - paidKes),
        mpesaReceiptCode:
          latestPayment?.mpesa_receipt_number ||
          latestPayment?.mpesa_receipt_code ||
          latestReceipt?.mpesa_receipt_code ||
          null,
        receiptToken: latestReceipt?.public_token || null,
        receiptNumber: latestReceipt?.receipt_number || null,
        invoiceToken: invoice?.public_token || null,
        invoiceNumber: invoice?.invoice_number || null,
        deliverableAvailable: Boolean(deliverableDownloadUrl && deliverableFileName),
        deliverableFileName,
        deliverableFileUrl: deliverableDownloadUrl,
        createdAt: order.created_at,
        updatedAt: order.updated_at,
      },
    });
  } catch (err: any) {
    return jsonResponse(500, {
      error: err.message || 'Could not load order status from database.',
    });
  }
};
