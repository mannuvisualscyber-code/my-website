import {
  DEFAULT_PORTFOLIO_CATEGORIES,
  getSupabase,
  isSupabaseConfigured,
  jsonResponse,
  loadPortfolioCategoriesFromDb,
} from './_supabase.js';

export async function loadPortfolioWithImages(supabase: any, includeHidden = false) {
  const categories = await loadPortfolioCategoriesFromDb(supabase);
  const categoryById = new Map<string, any>();
  for (const c of categories) {
    categoryById.set(c.id, c);
  }

  const { data: itemRows } = await supabase
    .from('portfolio_items')
    .select('*')
    .order('featured', { ascending: false })
    .order('sort_order', { ascending: true })
    .order('created_at', { ascending: false });

  const { data: imageRows } = await supabase
    .from('portfolio_images')
    .select('*')
    .order('is_cover', { ascending: false })
    .order('sort_order', { ascending: true });

  const imagesByItemId = new Map<string, any[]>();
  for (const img of imageRows || []) {
    const itemId = img.item_id || img.portfolio_item_id;
    if (!imagesByItemId.has(itemId)) {
      imagesByItemId.set(itemId, []);
    }
    imagesByItemId.get(itemId)!.push(img);
  }

  const mappedItems = (itemRows || [])
    .filter((row: any) => {
      const isVis =
        row.visible !== undefined
          ? Boolean(row.visible)
          : row.published !== undefined
          ? Boolean(row.published)
          : true;
      return includeHidden || isVis;
    })
    .map((row: any) => {
      const cat = categoryById.get(row.category_id) || categories[0] || {
        id: row.category_id,
        name: 'Graphic design',
        slug: 'graphic-design',
      };
      const rawImgs = imagesByItemId.get(row.id) || [];

      const images = rawImgs.map((img: any, idx: number) => {
        const base: any = {
          id: img.id,
          itemId: row.id,
          thumbUrl: img.thumb_url || img.public_url,
          mediumUrl: img.medium_url || img.public_url,
          publicUrl: img.public_url || img.medium_url || img.thumb_url,
          width: Number(img.width || 800),
          height: Number(img.height || 600),
          altText: img.alt_text || row.title,
          sortOrder: Number(img.sort_order ?? idx + 1),
          isCover: Boolean(img.is_cover ?? idx === 0),
          createdAt: img.created_at,
        };
        if (includeHidden) {
          base.originalPath = img.original_path || '';
        }
        return base;
      });

      const coverImage = images.find((i: any) => i.isCover) || images[0] || null;
      const isVisible =
        row.visible !== undefined
          ? Boolean(row.visible)
          : row.published !== undefined
          ? Boolean(row.published)
          : true;

      return {
        id: row.id,
        slug: row.slug,
        title: row.title,
        description: row.description || '',
        categoryId: row.category_id,
        categoryName: cat.name,
        categorySlug: cat.slug,
        tags: Array.isArray(row.tags) ? row.tags : [],
        clientLabel: row.client_label || null,
        projectDate: row.project_date || (row.created_at ? row.created_at.slice(0, 10) : ''),
        isSample: row.is_sample !== undefined ? Boolean(row.is_sample) : true,
        watermark: row.watermark !== undefined ? Boolean(row.watermark) : true,
        featured: Boolean(row.featured),
        visible: isVisible,
        sortOrder: Number(row.sort_order ?? 0),
        coverImage,
        images,
        createdAt: row.created_at,
        updatedAt: row.updated_at || row.created_at,
      };
    });

  return { categories, items: mappedItems };
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'GET') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const query = event.queryStringParameters || {};

    if (!isSupabaseConfigured()) {
      return jsonResponse(200, {
        categories: DEFAULT_PORTFOLIO_CATEGORIES.map((c, idx) => ({
          id: `cat-${idx + 1}`,
          name: c.name,
          slug: c.slug,
          sortOrder: c.sort_order,
        })),
        items: [],
        total: 0,
      });
    }

    const supabase = getSupabase();
    const { categories, items } = await loadPortfolioWithImages(supabase, false);

    if (query.slug) {
      const targetSlug = String(query.slug).trim().toLowerCase();
      const found = items.find((i: any) => i.slug.toLowerCase() === targetSlug);
      if (!found) {
        return jsonResponse(404, { error: 'Portfolio project not found.' });
      }
      return jsonResponse(200, { item: found, linkedItem: found, categories, items });
    }

    let filtered = items;
    if (query.category && query.category !== 'all') {
      const catSlug = String(query.category).trim().toLowerCase();
      filtered = filtered.filter(
        (i: any) =>
          i.categorySlug.toLowerCase() === catSlug ||
          i.categoryName.toLowerCase() === catSlug
      );
    }

    if (query.featured === 'true') {
      filtered = filtered.filter((i: any) => i.featured);
    }

    return jsonResponse(200, {
      categories,
      items: filtered,
      total: filtered.length,
    });
  } catch (err: any) {
    return jsonResponse(500, {
      error: err.message || 'Could not load portfolio items from database.',
    });
  }
};
