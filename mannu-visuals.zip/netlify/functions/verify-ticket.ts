import QRCode from 'qrcode';
import {
  deriveOrderNumberFromTicket,
  deriveTicketNumber,
  deriveTicketStatus,
  getSupabase,
  jsonResponse,
  loadSettingsFromDb,
  maskEmail,
  maskPhone,
} from './_supabase.js';

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'GET' && event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const query = event.queryStringParameters || {};
    const body =
      event.httpMethod === 'POST' && event.body ? JSON.parse(event.body) : {};

    const rawInput = String(
      query.ticket ||
        query.ticketNumber ||
        query.order ||
        body.ticket ||
        body.ticketNumber ||
        ''
    )
      .trim()
      .toUpperCase();

    if (!rawInput) {
      return jsonResponse(400, {
        valid: false,
        error: 'Please provide a ticket number (for example TKT-2026-8942).',
      });
    }

    const supabase = getSupabase();
    let order: any = null;

    if (rawInput.startsWith('MV-')) {
      const { data } = await supabase
        .from('orders')
        .select('*')
        .eq('order_number', rawInput)
        .maybeSingle();
      order = data;
    } else {
      // 1. Try direct lookup on orders.ticket_number
      const { data: byTicket, error: ticketColErr } = await supabase
        .from('orders')
        .select('*')
        .eq('ticket_number', rawInput)
        .maybeSingle();

      if (!ticketColErr && byTicket) {
        order = byTicket;
      } else {
        // 2. Fallback: derive MV-XXXX order number if ticket_number was derived
        const derivedOrderNum = deriveOrderNumberFromTicket(rawInput);
        if (derivedOrderNum) {
          const { data: byDerived } = await supabase
            .from('orders')
            .select('*')
            .eq('order_number', derivedOrderNum)
            .maybeSingle();
          order = byDerived;
        }
      }
    }

    if (!order) {
      return jsonResponse(404, {
        valid: false,
        error: `Ticket "${rawInput}" was not found. Please check the ticket number and try again.`,
      });
    }

    const [{ data: payments }, { data: receipts }, settings] = await Promise.all([
      supabase
        .from('payments')
        .select('*')
        .eq('order_id', order.id)
        .eq('status', 'SUCCESS')
        .order('created_at', { ascending: false }),
      supabase
        .from('receipts')
        .select('*')
        .eq('order_id', order.id)
        .order('issued_at', { ascending: false }),
      loadSettingsFromDb(supabase),
    ]);

    const latestPayment = (payments || [])[0] || null;
    const latestReceipt = (receipts || [])[0] || null;

    const ticketNumber = deriveTicketNumber(order);
    const ticketStatus = deriveTicketStatus(order);

    const origin =
      event.headers?.origin ||
      (event.headers?.host ? `https://${event.headers.host}` : process.env.APP_URL) ||
      'https://mannuvisuals.netlify.app';
    const baseOrigin = String(origin).replace(/\/$/, '');
    const verifyUrl = `${baseOrigin}/verify-ticket?ticket=${encodeURIComponent(ticketNumber)}`;

    let qrCodeData = order.qr_code_data || '';
    if (!qrCodeData) {
      try {
        qrCodeData = await QRCode.toDataURL(verifyUrl, {
          width: 240,
          margin: 1,
          color: {
            dark: '#0F172A',
            light: '#FFFFFF',
          },
        });
      } catch {
        qrCodeData = verifyUrl;
      }
    }

    const priceKes = Number(order.price_kes ?? order.total_amount ?? 0);
    const paidKes = Number(order.paid_kes ?? order.amount_paid ?? 0);

    return jsonResponse(200, {
      valid: ticketStatus !== 'CANCELLED',
      verifiedAt: new Date().toISOString(),
      businessName: settings.businessName,
      ticket: {
        ticketNumber,
        orderNumber: order.order_number,
        ticketStatus,
        orderStatus: order.status,
        paymentStatus: order.payment_status,
        customerName: order.customer_name,
        customerPhoneMasked: maskPhone(order.customer_phone),
        customerEmailMasked: maskEmail(order.customer_email),
        serviceCategory: order.service_category,
        serviceName: order.service_name,
        deliveryMethod: order.delivery_method,
        deadline: order.deadline || null,
        priceKes,
        paidKes,
        balanceKes: Math.max(0, priceKes - paidKes),
        mpesaReceiptCode:
          latestPayment?.mpesa_receipt_number ||
          latestPayment?.mpesa_receipt_code ||
          latestReceipt?.mpesa_receipt_code ||
          null,
        receiptNumber: latestReceipt?.receipt_number || null,
        receiptToken: latestReceipt?.public_token || null,
        verifyUrl,
        qrCodeData,
        issuedAt: order.created_at,
        updatedAt: order.updated_at || order.created_at,
      },
    });
  } catch (err: any) {
    return jsonResponse(500, {
      valid: false,
      error: err.message || 'Could not verify ticket.',
    });
  }
};
