import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';

let supabaseInstance = null;

export const BUCKETS = {
  PORTFOLIO_PUBLIC: 'portfolio-public',
  PORTFOLIO_PRIVATE: 'portfolio-private',
  ORDER_FILES: 'order-files',
};

export const DEFAULT_SETTINGS = {
  businessName: 'Mannu Visuals',
  description: 'Online cyber and graphic design services. All work is done online.',
  whatsappDisplay: '0796 431 953',
  whatsappWaMe: '254796431953',
  facebookLink: 'Mannu Visuals KE (TikTok, Facebook, Instagram and YouTube)',
  email: 'mannuvisualscyber@gmail.com',
  workingHours: '[add hours here]',
  mpesaTillOrPaybill: 'M-Pesa [Till/Paybill number to be added]',
  mpesaTransactionType: process.env.DARAJA_TXN_TYPE || 'CustomerPayBillOnline',
  logoUrl: '/logo.svg',
};

export const DEFAULT_PORTFOLIO_CATEGORIES = [
  { name: 'Wedding cards', slug: 'wedding-cards', sort_order: 1 },
  { name: 'Funeral programs', slug: 'funeral-programs', sort_order: 2 },
  { name: 'Posters and flyers', slug: 'posters-and-flyers', sort_order: 3 },
  { name: 'Logos', slug: 'logos', sort_order: 4 },
  { name: 'Birthday cards', slug: 'birthday-cards', sort_order: 5 },
  { name: 'Church posters', slug: 'church-posters', sort_order: 6 },
  { name: 'Company profiles', slug: 'company-profiles', sort_order: 7 },
  { name: 'Social media banners', slug: 'social-media-banners', sort_order: 8 },
];

export const DEFAULT_SERVICES = [
  {
    category: 'government',
    name: 'eCitizen Services',
    partner_label: 'eCitizen',
    items: [
      'Account support and account creation',
      'Password reset and login issues',
      'Tracking application status',
      'Good conduct / police clearance',
      'Business registration online process',
      'Work permit online process',
      'Passport online application steps',
    ],
    description: 'Guided assistance with online steps on the eCitizen portal.',
    active: true,
    sort_order: 1,
  },
  {
    category: 'government',
    name: 'KRA iTax Services',
    partner_label: 'KRA',
    items: [
      'PIN registration',
      'PIN retrieval',
      'iTax login support',
      'Tax returns filing',
      'Updating details',
    ],
    description: 'Support with KRA PIN and iTax portal online steps.',
    active: true,
    sort_order: 2,
  },
  {
    category: 'government',
    name: 'KUCCPS Placement Support',
    partner_label: 'KUCCPS',
    items: [
      'Course application',
      'Revision of choices',
      'Portal help',
      'Tracking placement status',
    ],
    description: 'Online support for students applying or revising courses on KUCCPS.',
    active: true,
    sort_order: 3,
  },
  {
    category: 'government',
    name: 'HELB, TIMS, SHA, NHIF and NSSF Support',
    partner_label: 'HELB · TIMS · SHA · NHIF · NSSF',
    items: [
      'HELB loan and portal assistance',
      'TIMS NTSA online account support',
      'SHA and NHIF registration and updates',
      'NSSF member portal assistance',
    ],
    description: 'Help completing online steps across statutory and student portals.',
    active: true,
    sort_order: 4,
  },
  {
    category: 'graphic_design',
    name: 'Wedding cards',
    items: ['Custom invitation layout', 'Print-ready PDF and WhatsApp image formats'],
    description: 'Clean invitation cards prepared to your event details and colours.',
    active: true,
    sort_order: 5,
  },
  {
    category: 'graphic_design',
    name: 'Eulogies and funeral programs',
    items: ['Multi-page funeral booklet layout', 'Photo retouching and cover layout'],
    description: 'Respectful, well-arranged funeral programs and eulogy booklets.',
    active: true,
    sort_order: 6,
  },
  {
    category: 'graphic_design',
    name: 'Posters and flyers',
    items: ['Business promotional flyers', 'Print and digital posters'],
    description: 'Clear layout for announcements, products and services.',
    active: true,
    sort_order: 7,
  },
  {
    category: 'graphic_design',
    name: 'Birthday cards',
    items: ['Custom birthday invitations', 'Digital shareable cards'],
    description: 'Personalised birthday cards for print or sharing online.',
    active: true,
    sort_order: 8,
  },
  {
    category: 'graphic_design',
    name: 'Business logos',
    items: ['New logo marks', 'Clean vector and high-resolution PNG files'],
    description: 'Simple, distinctive identity marks for businesses and organisations.',
    active: true,
    sort_order: 9,
  },
  {
    category: 'graphic_design',
    name: 'Event posters',
    items: ['Community, concert and workshop posters', 'Social media and A3/A4 sizes'],
    description: 'Readable event posters designed for digital sharing or printing.',
    active: true,
    sort_order: 10,
  },
  {
    category: 'graphic_design',
    name: 'Church posters',
    items: ['Sunday service, crusade and conference posters', 'WhatsApp status and banner sizes'],
    description: 'Calm, clear church event and ministry announcements.',
    active: true,
    sort_order: 11,
  },
  {
    category: 'graphic_design',
    name: 'Company profiles',
    items: ['Multi-page business profile layout', 'PDF for email and print'],
    description: 'Structured document layout presenting your company background and services.',
    active: true,
    sort_order: 12,
  },
  {
    category: 'graphic_design',
    name: 'Social media banners',
    items: ['Facebook, Instagram, TikTok and YouTube graphics', 'Profile covers and post templates'],
    description: 'Properly sized graphics for social media pages and posts.',
    active: true,
    sort_order: 13,
  },
  {
    category: 'other',
    name: 'Typing',
    items: ['Handwritten or scanned notes to Word/PDF', 'Clean document formatting'],
    description: 'Accurate document typing and formatting delivered online.',
    active: true,
    sort_order: 14,
  },
  {
    category: 'other',
    name: 'CV writing',
    items: ['Modern CV layout', 'Cover letters and updating existing CVs'],
    description: 'Clear, well-structured CVs tailored to your work history and education.',
    active: true,
    sort_order: 15,
  },
  {
    category: 'other',
    name: 'Letters',
    items: ['Application letters', 'Official business and formal correspondence'],
    description: 'Drafting and formatting of formal letters.',
    active: true,
    sort_order: 16,
  },
  {
    category: 'other',
    name: 'PDF conversions',
    items: ['Word to PDF', 'Merging, splitting and compressing PDF documents'],
    description: 'Quick file format conversion and document preparation for uploads.',
    active: true,
    sort_order: 17,
  },
  {
    category: 'other',
    name: 'Email creation',
    items: ['New email account setup', 'Account recovery guidance'],
    description: 'Assistance setting up a working email address for portals and work.',
    active: true,
    sort_order: 18,
  },
  {
    category: 'other',
    name: 'Online form filling',
    items: ['Job applications', 'Registration and institutional online forms'],
    description: 'Careful completion of online application and registration forms.',
    active: true,
    sort_order: 19,
  },
  {
    category: 'other',
    name: 'NEMIS / TSC / KMTC support',
    items: ['NEMIS learner and school steps', 'TSC online portal help', 'KMTC application support'],
    description: 'Online portal assistance for NEMIS, TSC and KMTC applicants.',
    active: true,
    sort_order: 20,
  },
];

export function isSupabaseConfigured() {
  const url = (process.env.SUPABASE_URL || '').trim();
  const key = (
    process.env.SUPABASE_SERVICE_KEY ||
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    ''
  ).trim();
  return Boolean(
    url &&
      key &&
      !url.includes('your-project-ref') &&
      !key.includes('your-supabase') &&
      !key.includes('placeholder')
  );
}

export function getSupabase() {
  if (supabaseInstance) return supabaseInstance;

  const supabaseUrl = (process.env.SUPABASE_URL || '').trim();
  const supabaseKey = (
    process.env.SUPABASE_SERVICE_KEY ||
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    ''
  ).trim();

  if (!supabaseUrl || !supabaseKey || !isSupabaseConfigured()) {
    throw new Error(
      'Database connection is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_KEY in your Netlify environment variables.'
    );
  }

  supabaseInstance = createClient(supabaseUrl, supabaseKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
  });

  return supabaseInstance;
}

export function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    },
    body: JSON.stringify(body),
  };
}

export function normalizeKenyanPhone(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const digits = raw.replace(/\s+/g, '').replace(/^\+/, '');
  if (/^07\d{8}$/.test(digits)) return '254' + digits.slice(1);
  if (/^01\d{8}$/.test(digits)) return '254' + digits.slice(1);
  if (/^7\d{8}$/.test(digits)) return '254' + digits;
  if (/^1\d{8}$/.test(digits)) return '254' + digits;
  if (/^254[71]\d{8}$/.test(digits)) return digits;
  return null;
}

export function maskPhone(phone) {
  if (!phone || phone.length < 8) return '2547****00';
  return `${phone.slice(0, 4)}****${phone.slice(-3)}`;
}

export function maskEmail(email) {
  if (!email || typeof email !== 'string' || !email.includes('@')) return null;
  const [user, domain] = email.split('@');
  if (!user || !domain) return null;
  const visible = user.slice(0, Math.min(2, user.length));
  return `${visible}***@${domain}`;
}

export const TICKET_STATUSES = [
  'PENDING_PAYMENT',
  'CONFIRMED',
  'PROCESSING',
  'READY',
  'COMPLETED',
  'CANCELLED',
];

export function deriveTicketNumber(orderRow) {
  if (!orderRow) return 'TKT-2026-8942';
  if (orderRow.ticket_number && String(orderRow.ticket_number).trim()) {
    return String(orderRow.ticket_number).trim().toUpperCase();
  }
  const createdYear = orderRow.created_at
    ? new Date(orderRow.created_at).getFullYear()
    : new Date().getFullYear();
  const year = Number.isNaN(createdYear) ? new Date().getFullYear() : createdYear;
  const orderNumStr = String(orderRow.order_number || '');
  const match = orderNumStr.match(/(\d+)$/);
  if (match) {
    const seq = parseInt(match[1], 10) + 4121;
    return `TKT-${year}-${seq}`;
  }
  const fallbackHash = String(orderRow.id || '8942')
    .replace(/\D/g, '')
    .slice(0, 4)
    .padStart(4, '8');
  return `TKT-${year}-${fallbackHash}`;
}

export function deriveOrderNumberFromTicket(ticketNumber) {
  if (!ticketNumber || typeof ticketNumber !== 'string') return null;
  const clean = ticketNumber.trim().toUpperCase();
  const match = clean.match(/^TKT-\d{4}-(\d+)$/);
  if (!match) return null;
  const seq = parseInt(match[1], 10) - 4121;
  if (seq > 0) {
    return `MV-${seq}`;
  }
  return null;
}

export function deriveTicketStatus(orderRow) {
  if (!orderRow) return 'PENDING_PAYMENT';
  const explicit = String(orderRow.ticket_status || '').trim().toUpperCase();
  if (TICKET_STATUSES.includes(explicit)) {
    // Still upgrade PENDING_PAYMENT if order has already progressed or been paid
    if (explicit === 'PENDING_PAYMENT') {
      if (orderRow.status === 'Delivered') return 'COMPLETED';
      if (orderRow.status === 'Ready') return 'READY';
      if (orderRow.status === 'In progress') return 'PROCESSING';
      if (
        orderRow.payment_status === 'PAID' ||
        orderRow.status === 'Paid' ||
        orderRow.status === 'Price confirmed'
      ) {
        return 'CONFIRMED';
      }
    }
    return explicit;
  }
  if (orderRow.status === 'Delivered') return 'COMPLETED';
  if (orderRow.status === 'Ready') return 'READY';
  if (orderRow.status === 'In progress') return 'PROCESSING';
  if (
    orderRow.payment_status === 'PAID' ||
    orderRow.status === 'Paid' ||
    orderRow.status === 'Price confirmed'
  ) {
    return 'CONFIRMED';
  }
  return 'PENDING_PAYMENT';
}

export function syncTicketStatusWithOrder(orderStatus, paymentStatus, currentTicketStatus) {
  if (currentTicketStatus === 'CANCELLED') return 'CANCELLED';
  if (orderStatus === 'Delivered') return 'COMPLETED';
  if (orderStatus === 'Ready') return 'READY';
  if (orderStatus === 'In progress') return 'PROCESSING';
  if (
    paymentStatus === 'PAID' ||
    orderStatus === 'Paid' ||
    orderStatus === 'Price confirmed'
  ) {
    return 'CONFIRMED';
  }
  if (currentTicketStatus && TICKET_STATUSES.includes(currentTicketStatus)) {
    return currentTicketStatus;
  }
  return 'PENDING_PAYMENT';
}

const SENSITIVE_PATTERNS = [
  /\bkra\s*pin\s*[:=-]?\s*[A-Z]\d{9}[A-Z]\b/i,
  /\bpassword\s*[:=]\s*\S+/i,
  /\bitax\s*password\b/i,
  /\becitizen\s*password\b/i,
];

export function containsSensitiveCredentials(text) {
  if (!text) return false;
  return SENSITIVE_PATTERNS.some((pattern) => pattern.test(text));
}

export function hashPassword(password, saltHex) {
  const salt = saltHex || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password, storedHash) {
  if (!storedHash || ! storedHash.includes(':')) return false;
  const [salt, originalHash] = storedHash.split(':');
  if (!salt || !originalHash) return false;
  const candidate = crypto.scryptSync(password, salt, 64).toString('hex');
  try {
    return crypto.timingSafeEqual(
      Buffer.from(originalHash, 'hex'),
      Buffer.from(candidate, 'hex')
    );
  } catch {
    return false;
  }
}

function getSessionSecret() {
  return (
    process.env.SESSION_SECRET ||
    process.env.ADMIN_SESSION_SECRET ||
    'mannu-visuals-fallback-session-secret-change-in-netlify'
  );
}

export function signAdminToken(user) {
  const now = Date.now();
  const payload = {
    userId: user.id,
    username: user.username,
    role: user.role,
    iat: now,
    exp: now + 30 * 60 * 1000, // 30 minutes
  };
  const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf-8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(payloadB64)
    .digest('base64url');
  return `${payloadB64}.${sig}`;
}

export function verifyAdminToken(authHeader) {
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  if (!token || !token.includes('.')) return null;
  const [payloadB64, sig] = token.split('.');
  if (!payloadB64 || !sig) return null;

  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(payloadB64)
    .digest('base64url');

  try {
    const valid = crypto.timingSafeEqual(
      Buffer.from(sig, 'utf-8'),
      Buffer.from(expectedSig, 'utf-8')
    );
    if (!valid) return null;
    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf-8'));
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

// Column alias fallback map in case schema column names differ slightly
const COLUMN_ALIASES = {
  failed_attempts: 'failed_login_attempts',
  failed_login_attempts: 'failed_attempts',
  amount_kes: 'amount',
  amount: 'amount_kes',
  phone: 'payer_phone',
  payer_phone: 'phone',
  mpesa_receipt_number: 'mpesa_receipt_code',
  mpesa_receipt_code: 'mpesa_receipt_number',
  visible: 'published',
  published: 'visible',
};

function adjustPayloadForMissingColumn(payload, errorMsg) {
  const match =
    errorMsg &&
    errorMsg.match(/Could not find the '([^']+)' column of '([^']+)'/i);
  if (!match) return null;
  const missingCol = match[1];
  if (!(missingCol in payload)) return null;
  const next = { ...payload };
  const val = next[missingCol];
  delete next[missingCol];
  const alias = COLUMN_ALIASES[missingCol];
  if (alias && !(alias in next)) {
    next[alias] = val;
  }
  return next;
}

export async function safeInsertSingle(supabase, table, payload) {
  let currentPayload = { ...payload };
  for (let attempt = 0; attempt < 6; attempt++) {
    const { data, error } = await supabase
      .from(table)
      .insert(currentPayload)
      .select('*')
      .single();
    if (!error) return { data, error: null };
    const adjusted = adjustPayloadForMissingColumn(currentPayload, error.message);
    if (adjusted) {
      currentPayload = adjusted;
      continue;
    }
    return { data: null, error };
  }
  return { data: null, error: new Error(`Failed to insert into ${table}`) };
}

export async function safeUpdateById(supabase, table, id, payload) {
  let currentPayload = { ...payload };
  for (let attempt = 0; attempt < 6; attempt++) {
    const { data, error } = await supabase
      .from(table)
      .update(currentPayload)
      .eq('id', id)
      .select('*')
      .single();
    if (!error) return { data, error: null };
    const adjusted = adjustPayloadForMissingColumn(currentPayload, error.message);
    if (adjusted) {
      currentPayload = adjusted;
      continue;
    }
    return { data: null, error };
  }
  return { data: null, error: new Error(`Failed to update ${table}`) };
}

export async function writeAuditLog(
  supabase,
  { actorUsername, actorRole, action, targetType, targetId, details, ipAddress = null }
) {
  try {
    await safeInsertSingle(supabase, 'audit_log', {
      actor_username: actorUsername || 'system',
      actor_role: actorRole || 'SYSTEM',
      action,
      target_type: targetType || 'system',
      target_id: String(targetId || ''),
      details: details || '',
      ip_address: ipAddress,
    });
  } catch {
    // Non-fatal if audit log fails
  }
}

export async function ensureInitialOwner(supabase) {
  const { count, error } = await supabase
    .from('admin_users')
    .select('*', { count: 'exact', head: true });

  if (error) return;
  if ((count || 0) > 0) return;

  const ownerUser = (
    process.env.ADMIN_OWNER_USER ||
    process.env.INITIAL_OWNER_USERNAME ||
    ''
  ).trim();
  const ownerPassword = process.env.ADMIN_OWNER_PASSWORD || '';

  if (!ownerUser || !ownerPassword) return;

  const passwordHash = hashPassword(ownerPassword);
  const { data: created } = await safeInsertSingle(supabase, 'admin_users', {
    username: ownerUser.toLowerCase(),
    password_hash: passwordHash,
    role: 'OWNER',
    active: true,
    failed_attempts: 0,
    locked_until: null,
  });

  if (created) {
    await writeAuditLog(supabase, {
      actorUsername: created.username,
      actorRole: 'OWNER',
      action: 'BOOTSTRAP_OWNER',
      targetType: 'admin_user',
      targetId: created.id,
      details: 'Created initial OWNER account from environment variables.',
    });
  }
}

export async function loadSettingsFromDb(supabase) {
  const { data: rows, error } = await supabase.from('settings').select('*');
  if (error || !rows || rows.length === 0) {
    // Seed default row if single-row table
    const { data: inserted } = await safeInsertSingle(supabase, 'settings', {
      id: 1,
      business_name: DEFAULT_SETTINGS.businessName,
      description: DEFAULT_SETTINGS.description,
      whatsapp_display: DEFAULT_SETTINGS.whatsappDisplay,
      whatsapp_wa_me: DEFAULT_SETTINGS.whatsappWaMe,
      facebook_link: DEFAULT_SETTINGS.facebookLink,
      email: DEFAULT_SETTINGS.email,
      working_hours: DEFAULT_SETTINGS.workingHours,
      mpesa_till_or_paybill: DEFAULT_SETTINGS.mpesaTillOrPaybill,
      mpesa_transaction_type: DEFAULT_SETTINGS.mpesaTransactionType,
      logo_url: DEFAULT_SETTINGS.logoUrl,
    });
    if (inserted) return mapSettingsRowToClient(inserted);
    return { ...DEFAULT_SETTINGS };
  }

  // Support both single-row settings table and key-value settings table
  if (rows[0] && 'key' in rows[0] && 'value' in rows[0]) {
    const kv = {};
    for (const r of rows) {
      kv[r.key] = typeof r.value === 'string' ? r.value : JSON.stringify(r.value);
    }
    return {
      businessName: kv.business_name || kv.businessName || DEFAULT_SETTINGS.businessName,
      description: kv.description || DEFAULT_SETTINGS.description,
      whatsappDisplay: kv.whatsapp_display || kv.whatsappDisplay || DEFAULT_SETTINGS.whatsappDisplay,
      whatsappWaMe: kv.whatsapp_wa_me || kv.whatsappWaMe || DEFAULT_SETTINGS.whatsappWaMe,
      facebookLink: kv.facebook_link || kv.facebookLink || DEFAULT_SETTINGS.facebookLink,
      email: kv.email || DEFAULT_SETTINGS.email,
      workingHours: kv.working_hours || kv.workingHours || DEFAULT_SETTINGS.workingHours,
      mpesaTillOrPaybill:
        kv.mpesa_till_or_paybill || kv.mpesaTillOrPaybill || DEFAULT_SETTINGS.mpesaTillOrPaybill,
      mpesaTransactionType:
        kv.mpesa_transaction_type ||
        kv.mpesaTransactionType ||
        DEFAULT_SETTINGS.mpesaTransactionType,
      logoUrl: kv.logo_url || kv.logoUrl || DEFAULT_SETTINGS.logoUrl,
    };
  }

  return mapSettingsRowToClient(rows[0]);
}

export function mapSettingsRowToClient(row) {
  if (!row) return { ...DEFAULT_SETTINGS };
  const email =
    !row.email || row.email === '[add email here]'
      ? DEFAULT_SETTINGS.email
      : row.email;
  const facebookLink =
    !row.facebook_link || row.facebook_link === '[add link here]'
      ? DEFAULT_SETTINGS.facebookLink
      : row.facebook_link;

  return {
    businessName: row.business_name || DEFAULT_SETTINGS.businessName,
    description: row.description || DEFAULT_SETTINGS.description,
    whatsappDisplay: row.whatsapp_display || DEFAULT_SETTINGS.whatsappDisplay,
    whatsappWaMe: row.whatsapp_wa_me || DEFAULT_SETTINGS.whatsappWaMe,
    facebookLink,
    email,
    workingHours: row.working_hours || DEFAULT_SETTINGS.workingHours,
    mpesaTillOrPaybill: row.mpesa_till_or_paybill || DEFAULT_SETTINGS.mpesaTillOrPaybill,
    mpesaTransactionType:
      row.mpesa_transaction_type || DEFAULT_SETTINGS.mpesaTransactionType,
    logoUrl: row.logo_url || DEFAULT_SETTINGS.logoUrl,
    updatedAt: row.updated_at || new Date().toISOString(),
  };
}

export async function loadServicesFromDb(supabase, includeInactive = false) {
  let query = supabase
    .from('services')
    .select('*')
    .order('sort_order', { ascending: true });

  const { data: rows, error } = await query;
  if (!error && (!rows || rows.length === 0)) {
    // Seed initial Mannu Visuals services into Supabase on first run
    await supabase.from('services').insert(DEFAULT_SERVICES);
    const { data: seeded } = await supabase
      .from('services')
      .select('*')
      .order('sort_order', { ascending: true });
    return (seeded || []).map(mapServiceRowToClient).filter((s) => includeInactive || s.active);
  }

  const list = (rows || []).map(mapServiceRowToClient);
  return includeInactive ? list : list.filter((s) => s.active);
}

export function mapServiceRowToClient(row) {
  return {
    id: row.id,
    category: row.category || 'other',
    name: row.name || row.title || '',
    partnerLabel: row.partner_label || undefined,
    items: Array.isArray(row.items) ? row.items : [],
    description: row.description || '',
    active: row.active !== undefined ? Boolean(row.active) : Boolean(row.is_active ?? true),
    sortOrder: Number(row.sort_order ?? 0),
  };
}

export async function loadPortfolioCategoriesFromDb(supabase) {
  const { data: rows, error } = await supabase
    .from('portfolio_categories')
    .select('*')
    .order('sort_order', { ascending: true });

  if (!error && (!rows || rows.length === 0)) {
    await supabase
      .from('portfolio_categories')
      .upsert(DEFAULT_PORTFOLIO_CATEGORIES, { onConflict: 'slug' });
    const { data: seeded } = await supabase
      .from('portfolio_categories')
      .select('*')
      .order('sort_order', { ascending: true });
    return (seeded || []).map(mapCategoryRowToClient);
  }

  return (rows || []).map(mapCategoryRowToClient);
}

export function mapCategoryRowToClient(row) {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    sortOrder: Number(row.sort_order ?? 0),
    createdAt: row.created_at || new Date().toISOString(),
  };
}

export async function findOrCreateCustomerByPhone(
  supabase,
  { name, phone, email, incrementOrders = 0, addBilledKes = 0, addPaidKes = 0 }
) {
  const cleanPhone = normalizeKenyanPhone(phone) || phone;
  const { data: existing } = await supabase
    .from('customers')
    .select('*')
    .eq('phone', cleanPhone)
    .maybeSingle();

  if (existing) {
    const updates = {
      name: name ? name.trim() : existing.name,
      email: email ? email.trim() : existing.email,
      total_orders: Number(existing.total_orders || 0) + incrementOrders,
      total_billed_kes: Number(existing.total_billed_kes || 0) + addBilledKes,
      total_paid_kes: Number(existing.total_paid_kes || 0) + addPaidKes,
      updated_at: new Date().toISOString(),
    };
    const { data: updated } = await safeUpdateById(supabase, 'customers', existing.id, updates);
    return updated || existing;
  }

  const { data: created } = await safeInsertSingle(supabase, 'customers', {
    name: (name || 'Customer').trim(),
    phone: cleanPhone,
    email: email ? email.trim() : null,
    total_orders: Math.max(0, incrementOrders),
    total_billed_kes: Math.max(0, addBilledKes),
    total_paid_kes: Math.max(0, addPaidKes),
  });
  return created;
}
