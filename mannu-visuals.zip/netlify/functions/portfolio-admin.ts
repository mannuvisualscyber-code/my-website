import {
  BUCKETS,
  getSupabase,
  jsonResponse,
  loadPortfolioCategoriesFromDb,
  safeInsertSingle,
  safeUpdateById,
  verifyAdminToken,
  writeAuditLog,
} from './_supabase.js';
import { buildDashboardSnapshot } from './admin-api.ts';
import { loadPortfolioWithImages } from './portfolio-list.ts';

function slugifyText(input: string): string {
  const base = (input || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return base || `work-${Date.now()}`;
}

async function uploadDataUrlIfNeeded(
  supabase: any,
  bucket: string,
  storagePath: string,
  urlOrDataUrl: string
): Promise<string> {
  if (!urlOrDataUrl || !urlOrDataUrl.startsWith('data:image/')) {
    return urlOrDataUrl;
  }
  const commaIdx = urlOrDataUrl.indexOf(',');
  if (commaIdx < 0) return urlOrDataUrl;
  const header = urlOrDataUrl.slice(5, commaIdx);
  const mimeType = header.split(';')[0] || 'image/webp';
  const base64 = urlOrDataUrl.slice(commaIdx + 1);
  const buffer = Buffer.from(base64, 'base64');

  const { error } = await supabase.storage.from(bucket).upload(storagePath, buffer, {
    contentType: mimeType,
    upsert: true,
  });

  if (error) return urlOrDataUrl;
  const { data: pub } = supabase.storage.from(bucket).getPublicUrl(storagePath);
  return pub?.publicUrl || urlOrDataUrl;
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const authHeader = event.headers?.authorization || event.headers?.Authorization;
    const session = verifyAdminToken(authHeader);
    if (!session) {
      return jsonResponse(401, {
        error: 'Authentication required. Please sign in to the Admin Panel.',
      });
    }

    const body = event.body ? JSON.parse(event.body) : {};
    const action = String(body.action || body.subAction || '');
    const supabase = getSupabase();

    const { data: adminUser } = await supabase
      .from('admin_users')
      .select('id, username, role, active')
      .eq('id', session.userId)
      .maybeSingle();

    if (adminUser && adminUser.active === false) {
      return jsonResponse(403, { error: 'Your admin account has been deactivated.' });
    }

    const actorUsername = adminUser?.username || session.username;
    const actorRole = (adminUser?.role || session.role) as 'OWNER' | 'STAFF';

    // 1. List all portfolio items and categories for Admin
    if (action === 'list') {
      const { categories, items } = await loadPortfolioWithImages(supabase, true);
      return jsonResponse(200, { categories, items });
    }

    // 2. Create Category (OWNER only)
    if (action === 'create-category') {
      if (actorRole !== 'OWNER') {
        return jsonResponse(403, {
          error: 'Only OWNER accounts can create new portfolio categories.',
        });
      }
      const name = String(body.name || '').trim();
      if (!name || name.length < 2) {
        return jsonResponse(400, { error: 'Please enter a valid category name.' });
      }
      const slug = slugifyText(name);
      const existingCats = await loadPortfolioCategoriesFromDb(supabase);
      if (
        existingCats.some(
          (c: any) =>
            c.slug.toLowerCase() === slug || c.name.toLowerCase() === name.toLowerCase()
        )
      ) {
        return jsonResponse(400, { error: 'A category with that name already exists.' });
      }

      const { data: created, error } = await safeInsertSingle(
        supabase,
        'portfolio_categories',
        {
          name,
          slug,
          sort_order: existingCats.length + 1,
        }
      );

      if (error || !created) {
        return jsonResponse(400, {
          error: error?.message || 'Could not create portfolio category.',
        });
      }

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'CREATE_PORTFOLIO_CATEGORY',
        targetType: 'portfolio_category',
        targetId: created.id,
        details: `Created portfolio category "${name}" (${slug}).`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(201, {
        category: created,
        categories: dashboard.portfolioCategories,
        dashboard,
      });
    }

    // Helper to save a single portfolio item + its portfolio_images
    const saveSinglePortfolioItem = async (itemInput: any) => {
      const itemId = itemInput.itemId || itemInput.id ? String(itemInput.itemId || itemInput.id).trim() : null;

      let existingRow: any = null;
      if (itemId) {
        const { data: found } = await supabase
          .from('portfolio_items')
          .select('*')
          .eq('id', itemId)
          .maybeSingle();
        existingRow = found;
      }

      // Quick toggle update (e.g. featured or visible only)
      if (
        existingRow &&
        itemInput.title === undefined &&
        (itemInput.featured !== undefined || itemInput.visible !== undefined)
      ) {
        const quickUpdates: Record<string, any> = {
          updated_at: new Date().toISOString(),
        };
        if (itemInput.featured !== undefined) quickUpdates.featured = Boolean(itemInput.featured);
        if (itemInput.visible !== undefined) quickUpdates.visible = Boolean(itemInput.visible);

        const { data: updated } = await safeUpdateById(
          supabase,
          'portfolio_items',
          existingRow.id,
          quickUpdates
        );
        return updated || existingRow;
      }

      const title = String(itemInput.title || existingRow?.title || '').trim();
      if (!title) {
        throw new Error('Project title is required.');
      }

      const categories = await loadPortfolioCategoriesFromDb(supabase);
      const categoryInput = String(
        itemInput.categoryId ||
          itemInput.categorySlug ||
          itemInput.categoryName ||
          itemInput.category ||
          existingRow?.category_id ||
          ''
      ).trim();

      const matchedCat =
        categories.find(
          (c: any) =>
            c.id === categoryInput ||
            c.slug.toLowerCase() === categoryInput.toLowerCase() ||
            c.name.toLowerCase() === categoryInput.toLowerCase()
        ) || categories[0];

      const rawImages = Array.isArray(itemInput.images) ? itemInput.images : [];
      if (rawImages.length === 0 && itemInput.imageUrl) {
        rawImages.push({
          thumbUrl: itemInput.thumbUrl || itemInput.imageUrl,
          mediumUrl: itemInput.mediumUrl || itemInput.imageUrl,
          publicUrl: itemInput.imageUrl,
          originalPath: itemInput.originalPath || `${BUCKETS.PORTFOLIO_PRIVATE}/sample`,
          width: Number(itemInput.width) || 800,
          height: Number(itemInput.height) || 600,
          altText: String(itemInput.altText || title).trim(),
          isCover: true,
        });
      }

      if (!existingRow && rawImages.length === 0) {
        throw new Error('At least one project image is required.');
      }

      const tags: string[] = Array.isArray(itemInput.tags)
        ? itemInput.tags.map((t: any) => String(t).trim()).filter(Boolean)
        : typeof itemInput.tags === 'string'
        ? itemInput.tags
            .split(',')
            .map((t: string) => t.trim())
            .filter(Boolean)
        : existingRow?.tags || [];

      const desiredSlugBase = slugifyText(itemInput.slug || title);
      let finalSlug = desiredSlugBase;

      const { data: slugCollisions } = await supabase
        .from('portfolio_items')
        .select('id, slug')
        .ilike('slug', `${desiredSlugBase}%`);

      const taken = new Set(
        (slugCollisions || [])
          .filter((r: any) => r.id !== itemId)
          .map((r: any) => String(r.slug).toLowerCase())
      );
      let suffix = 2;
      while (taken.has(finalSlug.toLowerCase())) {
        finalSlug = `${desiredSlugBase}-${suffix++}`;
      }

      const itemPayload: Record<string, any> = {
        slug: finalSlug,
        title,
        description: String(itemInput.description ?? existingRow?.description ?? '').trim(),
        category_id: matchedCat.id,
        tags,
        client_label:
          itemInput.clientLabel !== undefined
            ? itemInput.clientLabel
              ? String(itemInput.clientLabel).trim()
              : null
            : existingRow?.client_label || null,
        project_date: itemInput.projectDate
          ? String(itemInput.projectDate).slice(0, 10)
          : existingRow?.project_date || new Date().toISOString().slice(0, 10),
        is_sample:
          itemInput.isSample !== undefined
            ? Boolean(itemInput.isSample)
            : existingRow?.is_sample ?? true,
        watermark:
          itemInput.watermark !== undefined
            ? Boolean(itemInput.watermark)
            : existingRow?.watermark ?? true,
        featured:
          itemInput.featured !== undefined
            ? Boolean(itemInput.featured)
            : Boolean(existingRow?.featured),
        visible:
          itemInput.visible !== undefined
            ? Boolean(itemInput.visible)
            : existingRow?.visible ?? true,
        sort_order: Number(itemInput.sortOrder ?? existingRow?.sort_order ?? 1),
        updated_at: new Date().toISOString(),
      };

      let savedItemRow: any = null;
      if (existingRow) {
        const { data: updated, error: updErr } = await safeUpdateById(
          supabase,
          'portfolio_items',
          existingRow.id,
          itemPayload
        );
        if (updErr || !updated) {
          throw new Error(updErr?.message || 'Could not update portfolio item.');
        }
        savedItemRow = updated;
        if (rawImages.length > 0) {
          await supabase.from('portfolio_images').delete().eq('item_id', existingRow.id);
        }
      } else {
        const { data: created, error: createErr } = await safeInsertSingle(
          supabase,
          'portfolio_items',
          itemPayload
        );
        if (createErr || !created) {
          throw new Error(createErr?.message || 'Could not create portfolio item.');
        }
        savedItemRow = created;
      }

      if (rawImages.length > 0) {
        const hasExplicitCover = rawImages.some((img: any) => Boolean(img.isCover));
        for (let idx = 0; idx < rawImages.length; idx++) {
          const img = rawImages[idx];
          const prefix = `${savedItemRow.slug}-${idx + 1}-${Date.now()}`;

          const rawPub = String(img.publicUrl || img.mediumUrl || img.thumbUrl || '').trim();
          const rawThumb = String(img.thumbUrl || rawPub).trim();
          const rawMed = String(img.mediumUrl || rawPub).trim();

          const [uploadedThumb, uploadedMed, uploadedPub] = await Promise.all([
            uploadDataUrlIfNeeded(
              supabase,
              BUCKETS.PORTFOLIO_PUBLIC,
              `thumbs/${prefix}-480w.webp`,
              rawThumb
            ),
            uploadDataUrlIfNeeded(
              supabase,
              BUCKETS.PORTFOLIO_PUBLIC,
              `medium/${prefix}-1200w.webp`,
              rawMed
            ),
            uploadDataUrlIfNeeded(
              supabase,
              BUCKETS.PORTFOLIO_PUBLIC,
              `public/${prefix}-1200w.webp`,
              rawPub
            ),
          ]);

          await safeInsertSingle(supabase, 'portfolio_images', {
            item_id: savedItemRow.id,
            thumb_url: uploadedThumb,
            medium_url: uploadedMed,
            public_url: uploadedPub,
            original_path: String(
              img.originalPath || `${BUCKETS.PORTFOLIO_PRIVATE}/${savedItemRow.id}-${idx + 1}.webp`
            ),
            width: Math.max(100, Number(img.width) || 800),
            height: Math.max(100, Number(img.height) || 600),
            alt_text: String(img.altText || title).trim(),
            sort_order: Number(img.sortOrder ?? idx + 1),
            is_cover: hasExplicitCover ? Boolean(img.isCover) : idx === 0,
          });
        }
      }

      return savedItemRow;
    };

    // 3. Create or Update Single Portfolio Item
    if (
      action === 'save-item' ||
      action === 'create-item' ||
      action === 'update-item' ||
      action === 'create' ||
      action === 'update'
    ) {
      const savedItemRow = await saveSinglePortfolioItem(body);

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: body.id || body.itemId ? 'UPDATE_PORTFOLIO_ITEM' : 'CREATE_PORTFOLIO_ITEM',
        targetType: 'portfolio',
        targetId: savedItemRow.slug || savedItemRow.id,
        details: `Saved portfolio item "${savedItemRow.title}".`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      const savedFull =
        dashboard.portfolioItems.find((i: any) => i.id === savedItemRow.id) || savedItemRow;

      return jsonResponse(body.id || body.itemId ? 200 : 201, {
        item: savedFull,
        items: dashboard.portfolioItems,
        categories: dashboard.portfolioCategories,
        dashboard,
      });
    }

    // 4. Bulk Create Portfolio Items
    if (action === 'bulk-create') {
      const incoming = Array.isArray(body.items) ? body.items : [];
      for (const itemInput of incoming) {
        await saveSinglePortfolioItem(itemInput);
      }

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'BULK_CREATE_PORTFOLIO_ITEMS',
        targetType: 'portfolio',
        targetId: 'bulk',
        details: `Bulk uploaded ${incoming.length} portfolio items.`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(201, {
        ok: true,
        items: dashboard.portfolioItems,
        categories: dashboard.portfolioCategories,
        dashboard,
      });
    }

    // 5. Delete Portfolio Item
    if (action === 'delete-item' || action === 'delete') {
      const itemId = String(body.itemId || body.id || '').trim();
      const { data: existing } = await supabase
        .from('portfolio_items')
        .select('*')
        .eq('id', itemId)
        .maybeSingle();

      if (!existing) {
        return jsonResponse(404, { error: 'Portfolio item not found.' });
      }

      await supabase.from('portfolio_images').delete().eq('item_id', itemId);
      await supabase.from('portfolio_items').delete().eq('id', itemId);

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'DELETE_PORTFOLIO_ITEM',
        targetType: 'portfolio',
        targetId: existing.slug || itemId,
        details: `Deleted portfolio item "${existing.title}".`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, {
        ok: true,
        items: dashboard.portfolioItems,
        categories: dashboard.portfolioCategories,
        dashboard,
      });
    }

    // 6. Reorder Portfolio Items (orderedIds array OR single item up/down)
    if (action === 'reorder-items' || action === 'reorder') {
      let orderedIds: string[] = Array.isArray(body.orderedIds) ? body.orderedIds : [];

      if (orderedIds.length === 0 && body.id && body.direction) {
        const { data: rows } = await supabase
          .from('portfolio_items')
          .select('id')
          .order('sort_order', { ascending: true })
          .order('created_at', { ascending: false });
        const ids = (rows || []).map((r: any) => r.id);
        const idx = ids.indexOf(body.id);
        if (idx >= 0) {
          const swapIdx = body.direction === 'up' ? idx - 1 : idx + 1;
          if (swapIdx >= 0 && swapIdx < ids.length) {
            const temp = ids[idx];
            ids[idx] = ids[swapIdx];
            ids[swapIdx] = temp;
          }
        }
        orderedIds = ids;
      }

      for (let i = 0; i < orderedIds.length; i++) {
        await safeUpdateById(supabase, 'portfolio_items', orderedIds[i], {
          sort_order: i + 1,
          updated_at: new Date().toISOString(),
        });
      }

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'REORDER_PORTFOLIO_ITEMS',
        targetType: 'portfolio',
        targetId: 'all',
        details: `Reordered portfolio items.`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, {
        ok: true,
        items: dashboard.portfolioItems,
        categories: dashboard.portfolioCategories,
        dashboard,
      });
    }

    return jsonResponse(400, { error: `Unknown portfolio-admin action: ${action}` });
  } catch (err: any) {
    return jsonResponse(400, {
      error: err.message || 'Portfolio admin request error.',
    });
  }
};
