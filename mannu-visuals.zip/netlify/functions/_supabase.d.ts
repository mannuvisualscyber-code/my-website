import { SupabaseClient } from '@supabase/supabase-js';

export const BUCKETS: {
  PORTFOLIO_PUBLIC: string;
  PORTFOLIO_PRIVATE: string;
  ORDER_FILES: string;
};

export const DEFAULT_SETTINGS: {
  businessName: string;
  description: string;
  whatsappDisplay: string;
  whatsappWaMe: string;
  facebookLink: string;
  email: string;
  workingHours: string;
  mpesaTillOrPaybill: string;
  mpesaTransactionType: string;
  logoUrl: string;
};

export const DEFAULT_PORTFOLIO_CATEGORIES: {
  name: string;
  slug: string;
  sort_order: number;
}[];

export const DEFAULT_SERVICES: any[];

export function isSupabaseConfigured(): boolean;
export function getSupabase(): SupabaseClient;
export function jsonResponse(statusCode: number, body: any): {
  statusCode: number;
  headers: Record<string, string>;
  body: string;
};
export function normalizeKenyanPhone(raw: string): string | null;
export function maskPhone(phone: string): string;
export function maskEmail(email?: string | null): string | null;
export const TICKET_STATUSES: string[];
export function deriveTicketNumber(orderRow: any): string;
export function deriveOrderNumberFromTicket(ticketNumber: string): string | null;
export function deriveTicketStatus(orderRow: any): string;
export function syncTicketStatusWithOrder(
  orderStatus?: string,
  paymentStatus?: string,
  currentTicketStatus?: string
): string;
export function containsSensitiveCredentials(text?: string | null): boolean;
export function hashPassword(password: string, saltHex?: string): string;
export function verifyPassword(password: string, storedHash: string): boolean;
export function signAdminToken(user: {
  id: string;
  username: string;
  role: 'OWNER' | 'STAFF';
}): string;
export function verifyAdminToken(authHeader?: string): {
  userId: string;
  username: string;
  role: 'OWNER' | 'STAFF';
  iat: number;
  exp: number;
} | null;
export function safeInsertSingle(
  supabase: SupabaseClient,
  table: string,
  payload: Record<string, any>
): Promise<{ data: any; error: any }>;
export function safeUpdateById(
  supabase: SupabaseClient,
  table: string,
  id: string | number,
  payload: Record<string, any>
): Promise<{ data: any; error: any }>;
export function writeAuditLog(
  supabase: SupabaseClient,
  entry: {
    actorUsername: string;
    actorRole: string;
    action: string;
    targetType: string;
    targetId: string;
    details: string;
    ipAddress?: string | null;
  }
): Promise<void>;
export function ensureInitialOwner(supabase: SupabaseClient): Promise<void>;
export function loadSettingsFromDb(supabase: SupabaseClient): Promise<any>;
export function mapSettingsRowToClient(row: any): any;
export function loadServicesFromDb(
  supabase: SupabaseClient,
  includeInactive?: boolean
): Promise<any[]>;
export function mapServiceRowToClient(row: any): any;
export function loadPortfolioCategoriesFromDb(supabase: SupabaseClient): Promise<any[]>;
export function mapCategoryRowToClient(row: any): any;
export function findOrCreateCustomerByPhone(
  supabase: SupabaseClient,
  params: {
    name?: string;
    phone: string;
    email?: string;
    incrementOrders?: number;
    addBilledKes?: number;
    addPaidKes?: number;
  }
): Promise<any>;
