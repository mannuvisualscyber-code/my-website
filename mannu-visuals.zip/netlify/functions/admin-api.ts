import QRCode from 'qrcode';
import {
  BUCKETS,
  deriveOrderNumberFromTicket,
  deriveTicketNumber,
  deriveTicketStatus,
  ensureInitialOwner,
  findOrCreateCustomerByPhone,
  getSupabase,
  hashPassword,
  jsonResponse,
  loadPortfolioCategoriesFromDb,
  loadServicesFromDb,
  loadSettingsFromDb,
  normalizeKenyanPhone,
  safeInsertSingle,
  safeUpdateById,
  signAdminToken,
  syncTicketStatusWithOrder,
  TICKET_STATUSES,
  verifyAdminToken,
  verifyPassword,
  writeAuditLog,
} from './_supabase.js';
import { callRecordMpesaFailure, callRecordMpesaPayment } from './mpesa-callback.ts';
import { loadPortfolioWithImages } from './portfolio-list.ts';

const OWNER_ONLY_ACTIONS = new Set([
  'save-service',
  'delete-service',
  'update-settings',
  'create-admin-user',
  'update-admin-user',
]);

function mapOrderRowToClient(
  row: any,
  files: any[],
  latestPayment?: any,
  latestReceipt?: any
) {
  const ticketNumber = deriveTicketNumber(row);
  const ticketStatus = deriveTicketStatus(row);
  return {
    id: row.id,
    orderNumber: row.order_number,
    ticketNumber,
    ticketStatus,
    qrCodeData: row.qr_code_data || undefined,
    customerId: row.customer_id,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    customerEmail: row.customer_email || undefined,
    serviceCategory: row.service_category,
    serviceName: row.service_name,
    details: row.details || '',
    deadline: row.deadline || undefined,
    deliveryMethod: row.delivery_method,
    portalName: row.portal_name || undefined,
    helpNeeded: row.help_needed || undefined,
    designType: row.design_type || undefined,
    exactText: row.exact_text || undefined,
    eventDetails: row.event_details || undefined,
    colourPreferences: row.colour_preferences || undefined,
    sizeOrFormat: row.size_or_format || undefined,
    hasExtraWhatsappFiles: Boolean(row.has_extra_whatsapp_files),
    documentType: row.document_type || undefined,
    pageCount: row.page_count || undefined,
    documentLanguage: row.document_language || undefined,
    status: row.status,
    paymentStatus: row.payment_status,
    paymentPreference: row.payment_preference || 'mpesa_stk',
    priceKes: Number(row.price_kes ?? row.total_amount ?? 0),
    paidKes: Number(row.paid_kes ?? row.amount_paid ?? 0),
    mpesaReceiptCode:
      latestPayment?.mpesa_receipt_number ||
      latestPayment?.mpesa_receipt_code ||
      latestReceipt?.mpesa_receipt_code ||
      undefined,
    receiptNumber: latestReceipt?.receipt_number || undefined,
    receiptToken: latestReceipt?.public_token || undefined,
    deliverableFileName: row.deliverable_file_name || undefined,
    deliverableFileUrl: row.deliverable_file_url || undefined,
    trackingToken: row.tracking_token,
    createdAt: row.created_at,
    updatedAt: row.updated_at || row.created_at,
    files,
  };
}

export async function buildDashboardSnapshot(supabase: any, role: 'OWNER' | 'STAFF') {
  const [
    settings,
    services,
    portfolioData,
    { data: ordersRows },
    { data: orderFilesRows },
    { data: invoicesRows },
    { data: invoiceItemsRows },
    { data: paymentsRows },
    { data: receiptsRows },
    { data: customersRows },
    { data: adminUsersRows },
    { data: auditRows },
  ] = await Promise.all([
    loadSettingsFromDb(supabase),
    loadServicesFromDb(supabase, true),
    loadPortfolioWithImages(supabase, true),
    supabase.from('orders').select('*').order('created_at', { ascending: false }),
    supabase.from('order_files').select('*').order('created_at', { ascending: false }),
    supabase.from('invoices').select('*').order('created_at', { ascending: false }),
    supabase.from('invoice_items').select('*').order('sort_order', { ascending: true }),
    supabase.from('payments').select('*').order('created_at', { ascending: false }),
    supabase.from('receipts').select('*').order('issued_at', { ascending: false }),
    supabase.from('customers').select('*').order('updated_at', { ascending: false }),
    role === 'OWNER'
      ? supabase.from('admin_users').select('*').order('created_at', { ascending: true })
      : Promise.resolve({ data: [] }),
    supabase
      .from('audit_log')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(150),
  ]);

  // Group order files and generate signed URLs from order-files bucket
  const filesByOrderId = new Map<string, any[]>();
  for (const f of orderFilesRows || []) {
    let downloadUrl = f.storage_path || '';
    if (downloadUrl && !downloadUrl.startsWith('http') && !downloadUrl.startsWith('data:')) {
      const { data: signed } = await supabase.storage
        .from(BUCKETS.ORDER_FILES)
        .createSignedUrl(downloadUrl, 3600);
      if (signed?.signedUrl) {
        downloadUrl = signed.signedUrl;
      }
    }
    const mappedFile = {
      id: f.id,
      orderId: f.order_id,
      fileName: f.file_name,
      mimeType: f.mime_type,
      sizeBytes: Number(f.size_bytes || 0),
      dataUrl: downloadUrl,
      storagePath: f.storage_path,
      fileKind: f.file_kind || 'customer_upload',
      createdAt: f.created_at,
    };
    if (!filesByOrderId.has(f.order_id)) {
      filesByOrderId.set(f.order_id, []);
    }
    filesByOrderId.get(f.order_id)!.push(mappedFile);
  }

  const latestPaymentByOrderId = new Map<string, any>();
  for (const p of paymentsRows || []) {
    if (p.order_id && p.status === 'SUCCESS' && !latestPaymentByOrderId.has(p.order_id)) {
      latestPaymentByOrderId.set(p.order_id, p);
    }
  }

  const latestReceiptByOrderId = new Map<string, any>();
  for (const r of receiptsRows || []) {
    if (r.order_id && !latestReceiptByOrderId.has(r.order_id)) {
      latestReceiptByOrderId.set(r.order_id, r);
    }
  }

  const orders = (ordersRows || []).map((o: any) =>
    mapOrderRowToClient(
      o,
      filesByOrderId.get(o.id) || [],
      latestPaymentByOrderId.get(o.id),
      latestReceiptByOrderId.get(o.id)
    )
  );

  const itemsByInvoiceId = new Map<string, any[]>();
  for (const it of invoiceItemsRows || []) {
    if (!itemsByInvoiceId.has(it.invoice_id)) {
      itemsByInvoiceId.set(it.invoice_id, []);
    }
    itemsByInvoiceId.get(it.invoice_id)!.push({
      id: it.id,
      description: it.description,
      quantity: Number(it.quantity ?? 1),
      unitPriceKes: Number(it.unit_price_kes ?? it.unit_price ?? 0),
      lineTotalKes: Number(it.line_total_kes ?? it.line_total ?? 0),
    });
  }

  const orderNumberById = new Map<string, string>();
  for (const o of ordersRows || []) {
    orderNumberById.set(o.id, o.order_number);
  }

  const invoices = (invoicesRows || []).map((inv: any) => ({
    id: inv.id,
    invoiceNumber: inv.invoice_number,
    orderId: inv.order_id || undefined,
    orderNumber: inv.order_id ? orderNumberById.get(inv.order_id) : undefined,
    customerId: inv.customer_id || undefined,
    customerName: inv.customer_name,
    customerPhone: inv.customer_phone,
    customerEmail: inv.customer_email || undefined,
    items: itemsByInvoiceId.get(inv.id) || [],
    subtotalKes: Number(inv.subtotal_kes ?? inv.subtotal ?? 0),
    discountKes: Number(inv.discount_kes ?? inv.discount ?? 0),
    totalKes: Number(inv.total_kes ?? inv.total_amount ?? 0),
    paidKes: Number(inv.paid_kes ?? inv.amount_paid ?? 0),
    status: inv.status,
    dueDate: inv.due_date || undefined,
    notes: inv.notes || undefined,
    publicToken: inv.public_token,
    createdAt: inv.created_at,
    updatedAt: inv.updated_at || inv.created_at,
  }));

  const payments = (paymentsRows || []).map((p: any) => ({
    id: p.id,
    orderId: p.order_id || undefined,
    invoiceId: p.invoice_id || undefined,
    orderNumber:
      p.order_number || (p.order_id ? orderNumberById.get(p.order_id) : 'DIRECT') || 'DIRECT',
    phone: p.phone || p.payer_phone || '',
    amountKes: Number(p.amount_kes ?? p.amount ?? 0),
    method: p.method || 'MPESA',
    transactionType: p.transaction_type || 'CustomerPayBillOnline',
    merchantRequestId: p.merchant_request_id || undefined,
    checkoutRequestId: p.checkout_request_id || undefined,
    mpesaReceiptCode: p.mpesa_receipt_number || p.mpesa_receipt_code || undefined,
    status: p.status,
    resultCode: p.result_code ?? undefined,
    resultDesc: p.result_desc || undefined,
    recordedBy: p.recorded_by || undefined,
    createdAt: p.created_at,
    updatedAt: p.updated_at || p.created_at,
  }));

  const receipts = (receiptsRows || []).map((r: any) => ({
    id: r.id,
    receiptNumber: r.receipt_number,
    paymentId: r.payment_id,
    orderId: r.order_id || undefined,
    invoiceId: r.invoice_id || undefined,
    orderNumber: r.order_number || 'DIRECT',
    customerName: r.customer_name,
    customerPhone: r.customer_phone,
    serviceDescription: r.service_description,
    amountKes: Number(r.amount_kes ?? r.amount ?? 0),
    paymentMethod: r.payment_method || r.method || 'M-Pesa',
    mpesaReceiptCode: r.mpesa_receipt_code || r.mpesa_receipt_number || undefined,
    balanceAfterKes: Number(r.balance_after_kes ?? r.balance_after ?? 0),
    publicToken: r.public_token,
    issuedAt: r.issued_at || r.created_at,
  }));

  const customers = (customersRows || []).map((c: any) => ({
    id: c.id,
    name: c.name,
    phone: c.phone,
    email: c.email || undefined,
    totalOrders: Number(c.total_orders ?? 0),
    totalBilledKes: Number(c.total_billed_kes ?? 0),
    totalPaidKes: Number(c.total_paid_kes ?? 0),
    createdAt: c.created_at,
    updatedAt: c.updated_at || c.created_at,
  }));

  const adminUsers = (adminUsersRows || []).map((u: any) => ({
    id: u.id,
    username: u.username,
    role: u.role,
    active: u.active !== undefined ? Boolean(u.active) : true,
    failedLoginAttempts: Number(u.failed_attempts ?? u.failed_login_attempts ?? 0),
    lockedUntil: u.locked_until || null,
    lastLoginAt: u.last_login_at || null,
    createdAt: u.created_at,
  }));

  const auditLog = (auditRows || []).map((a: any) => ({
    id: a.id,
    actorUsername: a.actor_username || 'system',
    actorRole: a.actor_role || 'SYSTEM',
    action: a.action,
    targetType: a.target_type || '',
    targetId: a.target_id || '',
    details: a.details || '',
    createdAt: a.created_at,
  }));

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const monthPrefix = now.toISOString().slice(0, 7);

  const newOrdersCount = orders.filter((o: any) => o.status === 'Received').length;
  const unpaidOrdersCount = orders.filter((o: any) => o.paymentStatus !== 'PAID').length;

  let paidTodayKes = 0;
  let paidMonthKes = 0;
  for (const p of payments) {
    if (p.status === 'SUCCESS') {
      const d = String(p.createdAt || '').slice(0, 10);
      if (d === todayStr) paidTodayKes += p.amountKes;
      if (d.startsWith(monthPrefix)) paidMonthKes += p.amountKes;
    }
  }

  const sevenDayChart: {
    date: string;
    label: string;
    ordersCount: number;
    paidKes: number;
  }[] = [];
  for (let i = 6; i >= 0; i--) {
    const dt = new Date(now.getTime() - i * 86400000);
    const dateKey = dt.toISOString().slice(0, 10);
    const dayName = dt.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric' });
    const ordersCount = orders.filter(
      (o: any) => String(o.createdAt || '').slice(0, 10) === dateKey
    ).length;
    const paidKes = payments
      .filter(
        (p: any) =>
          p.status === 'SUCCESS' && String(p.createdAt || '').slice(0, 10) === dateKey
      )
      .reduce((sum: number, p: any) => sum + p.amountKes, 0);
    sevenDayChart.push({ date: dateKey, label: dayName, ordersCount, paidKes });
  }

  const byCategory = {
    government: orders.filter((o: any) => o.serviceCategory === 'government').length,
    graphic_design: orders.filter((o: any) => o.serviceCategory === 'graphic_design').length,
    other: orders.filter((o: any) => o.serviceCategory === 'other').length,
  };

  return {
    metrics: {
      newOrdersCount,
      unpaidOrdersCount,
      paidTodayKes,
      paidMonthKes,
      sevenDayChart,
      byCategory,
    },
    settings,
    services,
    orders,
    invoices,
    payments,
    receipts,
    customers,
    portfolioCategories: portfolioData.categories,
    portfolioItems: portfolioData.items,
    adminUsers,
    auditLog,
  };
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return jsonResponse(204, '');
  }

  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const action = String(body.action || '');
    const authHeader = event.headers?.authorization || event.headers?.Authorization;
    const supabase = getSupabase();

    // Ensure first OWNER is seeded from ADMIN_OWNER_USER and ADMIN_OWNER_PASSWORD if table is empty
    await ensureInitialOwner(supabase);

    // 1. Auth Status Check
    if (action === 'auth-status') {
      const { count } = await supabase
        .from('admin_users')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'OWNER');

      const hasOwner = (count || 0) > 0;
      const session = verifyAdminToken(authHeader);
      const userObj = session
        ? {
            id: session.userId,
            username: session.username,
            role: session.role,
            expiresAt: session.exp,
          }
        : null;

      return jsonResponse(200, {
        hasOwner,
        hasOwnerAccount: hasOwner,
        authenticated: Boolean(session),
        user: userObj,
        session: userObj,
      });
    }

    // 2. First-run OWNER bootstrap (only when admin_users has no OWNER yet)
    if (action === 'bootstrap-owner') {
      const { count } = await supabase
        .from('admin_users')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'OWNER');

      if ((count || 0) > 0) {
        return jsonResponse(403, {
          error: 'An OWNER account already exists. Please sign in.',
        });
      }

      const username = String(body.username || '')
        .trim()
        .toLowerCase();
      const password = String(body.password || '');

      if (!username || username.length < 3) {
        return jsonResponse(400, { error: 'Username must be at least 3 characters.' });
      }
      if (!password || password.length < 8) {
        return jsonResponse(400, { error: 'Password must be at least 8 characters.' });
      }

      const { data: newOwner, error } = await safeInsertSingle(supabase, 'admin_users', {
        username,
        password_hash: hashPassword(password),
        role: 'OWNER',
        active: true,
        failed_attempts: 0,
        locked_until: null,
        last_login_at: new Date().toISOString(),
      });

      if (error || !newOwner) {
        return jsonResponse(500, {
          error: error?.message || 'Could not create OWNER account in database.',
        });
      }

      await writeAuditLog(supabase, {
        actorUsername: newOwner.username,
        actorRole: 'OWNER',
        action: 'BOOTSTRAP_OWNER',
        targetType: 'admin_user',
        targetId: newOwner.id,
        details: 'Initial OWNER account created in admin_users.',
      });

      const token = signAdminToken(newOwner);
      return jsonResponse(201, {
        token,
        user: {
          id: newOwner.id,
          username: newOwner.username,
          role: newOwner.role,
        },
      });
    }

    // 3. Login with Password (using admin_users.failed_attempts and locked_until)
    if (action === 'login') {
      const username = String(body.username || '')
        .trim()
        .toLowerCase();
      const password = String(body.password || '');

      const { data: user } = await supabase
        .from('admin_users')
        .select('*')
        .eq('username', username)
        .maybeSingle();

      if (!user || user.active === false) {
        await writeAuditLog(supabase, {
          actorUsername: username || 'unknown',
          actorRole: 'UNAUTHENTICATED',
          action: 'LOGIN_FAILED',
          targetType: 'auth',
          targetId: username || 'unknown',
          details: 'Login failed: user not found or inactive.',
        });
        return jsonResponse(401, { error: 'Invalid username or password.' });
      }

      // Check lockout (locked_until)
      if (user.locked_until && new Date(user.locked_until).getTime() > Date.now()) {
        const remainingMinutes = Math.ceil(
          (new Date(user.locked_until).getTime() - Date.now()) / 60000
        );
        await writeAuditLog(supabase, {
          actorUsername: user.username,
          actorRole: user.role,
          action: 'LOGIN_BLOCKED_LOCKOUT',
          targetType: 'auth',
          targetId: user.id,
          details: `Login blocked while account is locked (${remainingMinutes} min remaining).`,
        });
        return jsonResponse(429, {
          error: `Account is temporarily locked after repeated failed attempts. Try again in ${remainingMinutes} minute(s).`,
        });
      }

      if (!verifyPassword(password, user.password_hash)) {
        const currentFailed = Number(
          user.failed_attempts ?? user.failed_login_attempts ?? 0
        );
        const nextFailed = currentFailed + 1;
        const lockedUntil =
          nextFailed >= 5
            ? new Date(Date.now() + 15 * 60 * 1000).toISOString()
            : null;

        await safeUpdateById(supabase, 'admin_users', user.id, {
          failed_attempts: nextFailed,
          locked_until: lockedUntil,
          updated_at: new Date().toISOString(),
        });

        await writeAuditLog(supabase, {
          actorUsername: user.username,
          actorRole: user.role,
          action: 'LOGIN_FAILED',
          targetType: 'auth',
          targetId: user.id,
          details: `Wrong password attempt #${nextFailed}${
            lockedUntil ? ' — account locked for 15 minutes.' : '.'
          }`,
        });

        if (lockedUntil) {
          return jsonResponse(429, {
            error:
              'Too many failed login attempts. This account is locked for 15 minutes.',
          });
        }

        return jsonResponse(401, { error: 'Invalid username or password.' });
      }

      // Valid password — reset failed_attempts and locked_until
      await safeUpdateById(supabase, 'admin_users', user.id, {
        failed_attempts: 0,
        locked_until: null,
        last_login_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

      const token = signAdminToken(user);
      await writeAuditLog(supabase, {
        actorUsername: user.username,
        actorRole: user.role,
        action: 'LOGIN_SUCCESS',
        targetType: 'auth',
        targetId: user.id,
        details: 'Admin signed in successfully.',
      });

      return jsonResponse(200, {
        token,
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
        },
      });
    }

    // 4. Logout
    if (action === 'logout') {
      const session = verifyAdminToken(authHeader);
      if (session) {
        await writeAuditLog(supabase, {
          actorUsername: session.username,
          actorRole: session.role,
          action: 'LOGOUT',
          targetType: 'auth',
          targetId: session.userId,
          details: 'Admin signed out.',
        });
      }
      return jsonResponse(200, { ok: true });
    }

    // All actions below require a valid SESSION_SECRET signed token
    const session = verifyAdminToken(authHeader);
    if (!session) {
      return jsonResponse(401, {
        error: 'Session expired or unauthorized. Please sign in again.',
      });
    }

    const { data: activeUser } = await supabase
      .from('admin_users')
      .select('id, username, role, active')
      .eq('id', session.userId)
      .maybeSingle();

    if (activeUser && activeUser.active === false) {
      return jsonResponse(403, { error: 'Your admin account has been deactivated.' });
    }

    const actorUsername = activeUser?.username || session.username;
    const actorRole = (activeUser?.role || session.role) as 'OWNER' | 'STAFF';

    if (OWNER_ONLY_ACTIONS.has(action) && actorRole !== 'OWNER') {
      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'FORBIDDEN_ACTION_BLOCKED',
        targetType: 'security',
        targetId: action,
        details: `STAFF user "${actorUsername}" was blocked from OWNER-only action "${action}".`,
      });
      return jsonResponse(403, {
        error: 'Access denied. Only OWNER accounts can perform this action.',
      });
    }

    // 5. Dashboard Snapshot
    if (action === 'dashboard' || action === 'get-dashboard') {
      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, {
        user: {
          id: session.userId,
          username: actorUsername,
          role: actorRole,
        },
        dashboard,
        ...dashboard,
      });
    }

    // 6. Update Order (price, status, deadline, details, or deliverable upload to order-files)
    if (action === 'update-order') {
      const orderId = body.orderId ? String(body.orderId).trim() : '';
      const orderNumber = String(body.orderNumber || '')
        .trim()
        .toUpperCase();

      let orderQuery = supabase.from('orders').select('*');
      if (orderId) {
        orderQuery = orderQuery.eq('id', orderId);
      } else {
        orderQuery = orderQuery.eq('order_number', orderNumber);
      }
      const { data: order } = await orderQuery.maybeSingle();

      if (!order) {
        return jsonResponse(404, { error: 'Order not found.' });
      }

      const updates: Record<string, any> = {
        updated_at: new Date().toISOString(),
      };

      const oldPrice = Number(order.price_kes ?? 0);
      const paidKes = Number(order.paid_kes ?? 0);
      let newPrice = oldPrice;

      if (body.priceKes !== undefined) {
        const parsedPrice = Number(body.priceKes);
        if (!Number.isInteger(parsedPrice) || parsedPrice < 0) {
          return jsonResponse(400, { error: 'Price must be a whole number in KES.' });
        }
        newPrice = parsedPrice;
        updates.price_kes = newPrice;

        if (order.customer_id && newPrice !== oldPrice) {
          const { data: cust } = await supabase
            .from('customers')
            .select('*')
            .eq('id', order.customer_id)
            .maybeSingle();
          if (cust) {
            await safeUpdateById(supabase, 'customers', cust.id, {
              total_billed_kes: Math.max(
                0,
                Number(cust.total_billed_kes || 0) + (newPrice - oldPrice)
              ),
              updated_at: new Date().toISOString(),
            });
          }
        }

        if (order.status === 'Received' && newPrice > 0 && !body.status) {
          updates.status = 'Price confirmed';
        }
      }

      if (newPrice <= 0) {
        updates.payment_status = paidKes > 0 ? 'PARTIAL' : 'UNPAID';
      } else if (paidKes >= newPrice) {
        updates.payment_status = 'PAID';
      } else if (paidKes > 0) {
        updates.payment_status = 'PARTIAL';
      } else {
        updates.payment_status = 'UNPAID';
      }

      // If deliverable file is attached in update-order, upload to order-files bucket & record in order_files
      if (body.deliverableFileName && body.deliverableFileUrl) {
        const fileName = String(body.deliverableFileName).trim();
        const dataUrl = String(body.deliverableFileUrl).trim();
        let finalStoragePath = dataUrl;
        let mimeType = String(body.deliverableMimeType || 'application/octet-stream');
        let sizeBytes = Number(body.deliverableSizeBytes || 1024);

        if (dataUrl.startsWith('data:')) {
          const commaIdx = dataUrl.indexOf(',');
          const header = dataUrl.slice(5, commaIdx);
          mimeType = header.split(';')[0] || mimeType;
          const base64Data = dataUrl.slice(commaIdx + 1);
          const buffer = Buffer.from(base64Data, 'base64');
          sizeBytes = Math.max(1, buffer.length);

          const safeFileName = fileName
            .replace(/[^a-zA-Z0-9._-]/g, '_')
            .slice(0, 80);
          const storagePath = `deliverables/${order.id}/${Date.now()}-${safeFileName}`;

          const { error: uploadErr } = await supabase.storage
            .from(BUCKETS.ORDER_FILES)
            .upload(storagePath, buffer, {
              contentType: mimeType,
              upsert: true,
            });

          if (!uploadErr) {
            finalStoragePath = storagePath;
          }
        }

        await safeInsertSingle(supabase, 'order_files', {
          order_id: order.id,
          file_name: fileName,
          mime_type: mimeType,
          size_bytes: sizeBytes,
          storage_path: finalStoragePath,
          file_kind: 'deliverable',
        });

        updates.deliverable_file_name = fileName;
        updates.deliverable_file_url = finalStoragePath;
      }

      const validStatuses = [
        'Received',
        'Price confirmed',
        'Paid',
        'In progress',
        'Ready',
        'Delivered',
      ];
      if (body.status && validStatuses.includes(body.status)) {
        updates.status = body.status;
      }
      if (body.ticketStatus && TICKET_STATUSES.includes(String(body.ticketStatus).toUpperCase())) {
        updates.ticket_status = String(body.ticketStatus).toUpperCase();
      } else {
        updates.ticket_status = syncTicketStatusWithOrder(
          updates.status || order.status,
          updates.payment_status || order.payment_status,
          order.ticket_status
        );
      }
      if (body.details !== undefined) {
        updates.details = String(body.details);
      }
      if (body.deadline !== undefined) {
        updates.deadline = body.deadline ? String(body.deadline) : null;
      }

      await safeUpdateById(supabase, 'orders', order.id, updates);

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'UPDATE_ORDER',
        targetType: 'order',
        targetId: order.order_number,
        details: `Updated ${order.order_number}: status="${
          updates.status || order.status
        }", price=KES ${newPrice}, paid=KES ${paidKes}.`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, { dashboard });
    }

    // 7. Upload Finished Deliverable to order-files bucket & save in order_files
    if (action === 'upload-deliverable') {
      const orderNumber = String(body.orderNumber || '')
        .trim()
        .toUpperCase();
      const { data: order } = await supabase
        .from('orders')
        .select('*')
        .eq('order_number', orderNumber)
        .maybeSingle();

      if (!order) {
        return jsonResponse(404, { error: 'Order not found.' });
      }

      const fileName = String(body.fileName || '').trim();
      const dataUrl = String(body.dataUrl || '').trim();
      if (!fileName || !dataUrl.startsWith('data:')) {
        return jsonResponse(400, { error: 'Valid deliverable file is required.' });
      }

      const commaIdx = dataUrl.indexOf(',');
      const header = dataUrl.slice(5, commaIdx);
      const mimeType = header.split(';')[0] || 'application/octet-stream';
      const base64Data = dataUrl.slice(commaIdx + 1);
      const buffer = Buffer.from(base64Data, 'base64');

      const safeFileName = fileName
        .replace(/[^a-zA-Z0-9._-]/g, '_')
        .slice(0, 80);
      const storagePath = `deliverables/${order.id}/${Date.now()}-${safeFileName}`;

      const { error: uploadErr } = await supabase.storage
        .from(BUCKETS.ORDER_FILES)
        .upload(storagePath, buffer, {
          contentType: mimeType,
          upsert: true,
        });

      const finalStoragePath = uploadErr ? dataUrl : storagePath;

      await safeInsertSingle(supabase, 'order_files', {
        order_id: order.id,
        file_name: fileName,
        mime_type: mimeType,
        size_bytes: Math.max(1, buffer.length),
        storage_path: finalStoragePath,
        file_kind: 'deliverable',
      });

      const nextStatus = ['Received', 'Price confirmed', 'Paid', 'In progress'].includes(
        order.status
      )
        ? 'Ready'
        : order.status;

      await safeUpdateById(supabase, 'orders', order.id, {
        deliverable_file_name: fileName,
        deliverable_file_url: finalStoragePath,
        status: nextStatus,
        ticket_status: nextStatus === 'Delivered' ? 'COMPLETED' : 'READY',
        updated_at: new Date().toISOString(),
      });

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'UPLOAD_DELIVERABLE',
        targetType: 'order',
        targetId: order.order_number,
        details: `Uploaded deliverable "${fileName}" to order-files for ${order.order_number}.`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, { dashboard });
    }

    // 8. Record Manual Payment (M-Pesa manual code, cash, or other)
    if (action === 'record-manual-payment') {
      const orderId = body.orderId ? String(body.orderId).trim() : '';
      const orderNumber = String(body.orderNumber || '')
        .trim()
        .toUpperCase();
      const amountKes = Number(body.amountKes);
      const methodInput = String(body.method || 'MPESA');
      const mpesaReceiptCode = body.mpesaReceiptCode
        ? String(body.mpesaReceiptCode).trim().toUpperCase()
        : null;

      let orderQuery = supabase.from('orders').select('*');
      if (orderId) {
        orderQuery = orderQuery.eq('id', orderId);
      } else {
        orderQuery = orderQuery.eq('order_number', orderNumber);
      }
      const { data: order } = await orderQuery.maybeSingle();

      if (!order) {
        return jsonResponse(404, { error: 'Order not found.' });
      }
      if (!Number.isInteger(amountKes) || amountKes <= 0) {
        return jsonResponse(400, { error: 'Amount must be a positive whole number in KES.' });
      }

      if (mpesaReceiptCode) {
        const { data: dup } = await supabase
          .from('payments')
          .select('id')
          .or(`mpesa_receipt_code.eq.${mpesaReceiptCode},mpesa_receipt_number.eq.${mpesaReceiptCode}`)
          .maybeSingle();

        if (dup) {
          return jsonResponse(400, {
            error: `M-Pesa receipt code ${mpesaReceiptCode} has already been recorded.`,
          });
        }
      }

      const settings = await loadSettingsFromDb(supabase);
      let { data: payment, error: payErr } = await safeInsertSingle(supabase, 'payments', {
        order_id: order.id,
        order_number: order.order_number,
        phone: order.customer_phone,
        amount_kes: amountKes,
        method: methodInput === 'MPESA_MANUAL' ? 'MPESA' : methodInput,
        transaction_type: settings.mpesaTransactionType || 'CustomerPayBillOnline',
        mpesa_receipt_number: mpesaReceiptCode,
        mpesa_receipt_code: mpesaReceiptCode,
        status: 'SUCCESS',
        result_code: 0,
        result_desc: `Recorded manually by ${actorUsername}`,
        recorded_by: actorUsername,
      });

      if (payErr && /method/i.test(payErr.message || '')) {
        const retry = await safeInsertSingle(supabase, 'payments', {
          order_id: order.id,
          order_number: order.order_number,
          phone: order.customer_phone,
          amount_kes: amountKes,
          method: methodInput === 'MPESA' ? 'MPESA_MANUAL' : methodInput,
          transaction_type: settings.mpesaTransactionType || 'CustomerPayBillOnline',
          mpesa_receipt_number: mpesaReceiptCode,
          mpesa_receipt_code: mpesaReceiptCode,
          status: 'SUCCESS',
          result_code: 0,
          result_desc: `Recorded manually by ${actorUsername}`,
          recorded_by: actorUsername,
        });
        payment = retry.data;
        payErr = retry.error;
      }

      if (payErr || !payment) {
        return jsonResponse(500, {
          error: payErr?.message || 'Could not record payment.',
        });
      }

      const oldPaid = Number(order.paid_kes ?? 0);
      const priceKes = Number(order.price_kes ?? 0);
      const newPaid = oldPaid + amountKes;
      const newPaymentStatus =
        priceKes > 0 && newPaid >= priceKes ? 'PAID' : newPaid > 0 ? 'PARTIAL' : 'UNPAID';
      const newOrderStatus =
        newPaymentStatus === 'PAID' && ['Received', 'Price confirmed'].includes(order.status)
          ? 'Paid'
          : order.status;

      const nextTicketStatus =
        !order.ticket_status || order.ticket_status === 'PENDING_PAYMENT'
          ? 'CONFIRMED'
          : order.ticket_status;

      await safeUpdateById(supabase, 'orders', order.id, {
        paid_kes: newPaid,
        payment_status: newPaymentStatus,
        status: newOrderStatus,
        ticket_status: nextTicketStatus,
        updated_at: new Date().toISOString(),
      });

      if (order.customer_id) {
        const { data: cust } = await supabase
          .from('customers')
          .select('*')
          .eq('id', order.customer_id)
          .maybeSingle();
        if (cust) {
          await safeUpdateById(supabase, 'customers', cust.id, {
            total_paid_kes: Number(cust.total_paid_kes || 0) + amountKes,
            updated_at: new Date().toISOString(),
          });
        }
      }

      const balanceAfterKes = Math.max(0, priceKes - newPaid);

      // Receipt number and public_token are generated by database defaults
      const { data: receipt } = await safeInsertSingle(supabase, 'receipts', {
        payment_id: payment.id,
        order_id: order.id,
        order_number: order.order_number,
        customer_name: order.customer_name,
        customer_phone: order.customer_phone,
        service_description: order.service_name,
        amount_kes: amountKes,
        payment_method: methodInput,
        mpesa_receipt_code: mpesaReceiptCode,
        balance_after_kes: balanceAfterKes,
      });

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'RECORD_MANUAL_PAYMENT',
        targetType: 'order',
        targetId: order.order_number,
        details: `Recorded manual payment of KES ${amountKes} for ${order.order_number} (${
          receipt?.receipt_number || 'receipt generated'
        }).`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, { receipt, dashboard });
    }

    // 9. Create Invoice (invoice_number and public_token generated by database defaults)
    if (action === 'create-invoice') {
      const customerName = String(body.customerName || '').trim();
      const cleanPhone =
        normalizeKenyanPhone(String(body.customerPhone || '')) ||
        String(body.customerPhone || '').trim();
      const rawItems = Array.isArray(body.items) ? body.items : [];
      const discountKes = Math.max(0, Math.round(Number(body.discountKes || 0)));

      if (!customerName || !cleanPhone || rawItems.length === 0) {
        return jsonResponse(400, {
          error: 'Customer name, phone and at least one line item are required.',
        });
      }

      const computedItems = rawItems.map((it: any, idx: number) => {
        const qty = Math.max(1, Math.round(Number(it.quantity || 1)));
        const unit = Math.max(0, Math.round(Number(it.unitPriceKes || 0)));
        return {
          description: String(it.description || 'Service item').trim(),
          quantity: qty,
          unit_price_kes: unit,
          line_total_kes: qty * unit,
          sort_order: idx + 1,
        };
      });

      const subtotalKes = computedItems.reduce(
        (sum: number, i: any) => sum + i.line_total_kes,
        0
      );
      const totalKes = Math.max(0, subtotalKes - discountKes);

      let linkedOrder: any = null;
      if (body.orderNumber) {
        const { data: ord } = await supabase
          .from('orders')
          .select('*')
          .eq('order_number', String(body.orderNumber).trim().toUpperCase())
          .maybeSingle();
        linkedOrder = ord;
      }

      const customer = await findOrCreateCustomerByPhone(supabase, {
        name: customerName,
        phone: cleanPhone,
        email: body.customerEmail ? String(body.customerEmail).trim() : undefined,
        addBilledKes: linkedOrder ? 0 : totalKes,
      });

      const paidKes = linkedOrder ? Number(linkedOrder.paid_kes ?? 0) : 0;
      const status =
        paidKes >= totalKes && totalKes > 0
          ? 'PAID'
          : paidKes > 0
          ? 'PARTIAL'
          : 'UNPAID';

      // Insert into invoices without invoice_number or public_token so DB defaults generate them
      const { data: invoice, error: invErr } = await safeInsertSingle(supabase, 'invoices', {
        order_id: linkedOrder?.id || null,
        customer_id: customer?.id || null,
        customer_name: customerName,
        customer_phone: cleanPhone,
        customer_email: body.customerEmail ? String(body.customerEmail).trim() : null,
        subtotal_kes: subtotalKes,
        discount_kes: discountKes,
        total_kes: totalKes,
        paid_kes: paidKes,
        status,
        due_date: body.dueDate ? String(body.dueDate) : null,
        notes: body.notes ? String(body.notes).trim() : null,
      });

      if (invErr || !invoice) {
        return jsonResponse(500, {
          error: invErr?.message || 'Could not create invoice in database.',
        });
      }

      for (const item of computedItems) {
        await safeInsertSingle(supabase, 'invoice_items', {
          invoice_id: invoice.id,
          ...item,
        });
      }

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'CREATE_INVOICE',
        targetType: 'invoice',
        targetId: invoice.invoice_number,
        details: `Created invoice ${invoice.invoice_number} for ${customerName} (KES ${totalKes}).`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(201, { invoice, dashboard });
    }

    // 10. Save Service (OWNER only)
    if (action === 'save-service') {
      const id = body.id ? String(body.id) : '';
      const name = String(body.name || '').trim();
      const category = body.category;
      const description = String(body.description || '').trim();
      const items = Array.isArray(body.items)
        ? body.items.map((x: any) => String(x).trim()).filter(Boolean)
        : [];

      if (!name || !['government', 'graphic_design', 'other'].includes(category)) {
        return jsonResponse(400, { error: 'Service name and valid category are required.' });
      }

      if (id) {
        await safeUpdateById(supabase, 'services', id, {
          name,
          category,
          partner_label: body.partnerLabel ? String(body.partnerLabel).trim() : null,
          description,
          items,
          active: body.active !== undefined ? Boolean(body.active) : true,
          sort_order: Number(body.sortOrder ?? 1),
          updated_at: new Date().toISOString(),
        });
      } else {
        await safeInsertSingle(supabase, 'services', {
          name,
          category,
          partner_label: body.partnerLabel ? String(body.partnerLabel).trim() : null,
          description,
          items,
          active: body.active !== undefined ? Boolean(body.active) : true,
          sort_order: Number(body.sortOrder ?? 99),
        });
      }

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'SAVE_SERVICE',
        targetType: 'service',
        targetId: name,
        details: `Saved service "${name}" in ${category}.`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, { dashboard });
    }

    // 11. Update Settings (OWNER only)
    if (action === 'update-settings') {
      const current = await loadSettingsFromDb(supabase);
      const updates: Record<string, any> = {
        business_name:
          body.businessName !== undefined
            ? String(body.businessName).trim()
            : current.businessName,
        description:
          body.description !== undefined
            ? String(body.description).trim()
            : current.description,
        whatsapp_display:
          body.whatsappDisplay !== undefined
            ? String(body.whatsappDisplay).trim()
            : current.whatsappDisplay,
        whatsapp_wa_me:
          body.whatsappWaMe !== undefined
            ? normalizeKenyanPhone(String(body.whatsappWaMe)) ||
              String(body.whatsappWaMe).trim()
            : current.whatsappWaMe,
        facebook_link:
          body.facebookLink !== undefined
            ? String(body.facebookLink).trim()
            : current.facebookLink,
        email: body.email !== undefined ? String(body.email).trim() : current.email,
        working_hours:
          body.workingHours !== undefined
            ? String(body.workingHours).trim()
            : current.workingHours,
        mpesa_till_or_paybill:
          body.mpesaTillOrPaybill !== undefined
            ? String(body.mpesaTillOrPaybill).trim()
            : current.mpesaTillOrPaybill,
        mpesa_transaction_type:
          body.mpesaTransactionType === 'CustomerBuyGoodsOnline'
            ? 'CustomerBuyGoodsOnline'
            : 'CustomerPayBillOnline',
        logo_url:
          body.logoUrl !== undefined ? String(body.logoUrl).trim() : current.logoUrl,
        updated_at: new Date().toISOString(),
      };

      const { data: existingRows } = await supabase.from('settings').select('*');
      if (existingRows && existingRows[0] && 'key' in existingRows[0]) {
        // Key-value settings table support
        for (const [k, v] of Object.entries(updates)) {
          if (k !== 'updated_at') {
            await supabase.from('settings').upsert({ key: k, value: v });
          }
        }
      } else {
        await safeUpdateById(supabase, 'settings', 1, updates);
      }

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'UPDATE_SETTINGS',
        targetType: 'settings',
        targetId: '1',
        details: 'Updated business settings in Supabase.',
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, { dashboard });
    }

    // 12. Create Admin User (OWNER only)
    if (action === 'create-admin-user') {
      const username = String(body.username || '')
        .trim()
        .toLowerCase();
      const password = String(body.password || '');
      const role = body.role === 'OWNER' ? 'OWNER' : 'STAFF';

      if (!username || username.length < 3) {
        return jsonResponse(400, { error: 'Username must be at least 3 characters.' });
      }
      if (!password || password.length < 8) {
        return jsonResponse(400, { error: 'Password must be at least 8 characters.' });
      }

      const { data: existing } = await supabase
        .from('admin_users')
        .select('id')
        .eq('username', username)
        .maybeSingle();

      if (existing) {
        return jsonResponse(400, { error: 'Username already exists.' });
      }

      const { data: newUser, error } = await safeInsertSingle(supabase, 'admin_users', {
        username,
        password_hash: hashPassword(password),
        role,
        active: true,
        failed_attempts: 0,
        locked_until: null,
      });

      if (error || !newUser) {
        return jsonResponse(500, {
          error: error?.message || 'Could not create admin user.',
        });
      }

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'CREATE_ADMIN_USER',
        targetType: 'admin_user',
        targetId: newUser.id,
        details: `Created ${role} user "${username}".`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(201, { dashboard });
    }

    // 13. Update / Unlock Admin User (OWNER only)
    if (action === 'update-admin-user') {
      const userId = String(body.userId || '');
      const { data: target } = await supabase
        .from('admin_users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (!target) {
        return jsonResponse(404, { error: 'User not found.' });
      }

      const updates: Record<string, any> = {
        updated_at: new Date().toISOString(),
      };
      if (body.active !== undefined) updates.active = Boolean(body.active);
      if (body.role === 'OWNER' || body.role === 'STAFF') updates.role = body.role;
      if (body.unlockAccount) {
        updates.failed_attempts = 0;
        updates.locked_until = null;
      }
      if (body.newPassword && String(body.newPassword).length >= 8) {
        updates.password_hash = hashPassword(String(body.newPassword));
      }

      await safeUpdateById(supabase, 'admin_users', target.id, updates);

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'UPDATE_ADMIN_USER',
        targetType: 'admin_user',
        targetId: target.id,
        details: `Updated user "${target.username}".`,
      });

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, { dashboard });
    }

    // 14. Admin Ticket Verification Lookup (/admin/verify)
    if (action === 'verify-ticket-lookup') {
      const rawTicket = String(body.ticketNumber || body.ticket || body.orderNumber || '')
        .trim()
        .toUpperCase();

      if (!rawTicket) {
        return jsonResponse(400, {
          error: 'Please enter a Ticket Number (e.g. TKT-2026-8942) or Order Number (e.g. MV-4821).',
        });
      }

      let order: any = null;
      if (rawTicket.startsWith('MV-')) {
        const { data } = await supabase
          .from('orders')
          .select('*')
          .eq('order_number', rawTicket)
          .maybeSingle();
        order = data;
      } else {
        const { data: byTicket, error: tktErr } = await supabase
          .from('orders')
          .select('*')
          .eq('ticket_number', rawTicket)
          .maybeSingle();

        if (!tktErr && byTicket) {
          order = byTicket;
        } else {
          const derivedMv = deriveOrderNumberFromTicket(rawTicket);
          if (derivedMv) {
            const { data: byDerived } = await supabase
              .from('orders')
              .select('*')
              .eq('order_number', derivedMv)
              .maybeSingle();
            order = byDerived;
          }
        }
      }

      if (!order) {
        return jsonResponse(404, {
          error: `No ticket or order found matching "${rawTicket}".`,
        });
      }

      const [{ data: files }, { data: payments }, { data: receipts }] = await Promise.all([
        supabase
          .from('order_files')
          .select('*')
          .eq('order_id', order.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('payments')
          .select('*')
          .eq('order_id', order.id)
          .eq('status', 'SUCCESS')
          .order('created_at', { ascending: false }),
        supabase
          .from('receipts')
          .select('*')
          .eq('order_id', order.id)
          .order('issued_at', { ascending: false }),
      ]);

      const mappedOrder = mapOrderRowToClient(
        order,
        files || [],
        (payments || [])[0],
        (receipts || [])[0]
      );

      const origin =
        event.headers?.origin ||
        (event.headers?.host ? `https://${event.headers.host}` : process.env.APP_URL) ||
        'https://mannuvisuals.netlify.app';
      const baseOrigin = String(origin).replace(/\/$/, '');
      const verifyUrl = `${baseOrigin}/verify-ticket?ticket=${encodeURIComponent(
        mappedOrder.ticketNumber
      )}`;

      if (!mappedOrder.qrCodeData) {
        try {
          mappedOrder.qrCodeData = await QRCode.toDataURL(verifyUrl, {
            width: 240,
            margin: 1,
            color: { dark: '#0F172A', light: '#FFFFFF' },
          });
        } catch {
          mappedOrder.qrCodeData = verifyUrl;
        }
      }

      return jsonResponse(200, {
        order: {
          ...mappedOrder,
          verifyUrl,
        },
      });
    }

    // 15. Admin Ticket Status Update (/admin/verify & Orders tab) — Mark READY, FULFILLED/COMPLETED, etc.
    if (action === 'update-ticket-status') {
      const orderId = body.orderId ? String(body.orderId).trim() : '';
      const rawTicket = String(body.ticketNumber || body.orderNumber || '')
        .trim()
        .toUpperCase();
      const requestedStatusRaw = String(body.ticketStatus || body.status || '')
        .trim()
        .toUpperCase();

      // Map 'FULFILLED' alias to 'COMPLETED'
      const targetTicketStatus =
        requestedStatusRaw === 'FULFILLED' ? 'COMPLETED' : requestedStatusRaw;

      if (!TICKET_STATUSES.includes(targetTicketStatus)) {
        return jsonResponse(400, {
          error: `Invalid ticket status "${requestedStatusRaw}". Allowed: ${TICKET_STATUSES.join(', ')}.`,
        });
      }

      let order: any = null;
      if (orderId) {
        const { data } = await supabase
          .from('orders')
          .select('*')
          .eq('id', orderId)
          .maybeSingle();
        order = data;
      } else if (rawTicket.startsWith('MV-')) {
        const { data } = await supabase
          .from('orders')
          .select('*')
          .eq('order_number', rawTicket)
          .maybeSingle();
        order = data;
      } else if (rawTicket) {
        const { data: byTicket, error: tktErr } = await supabase
          .from('orders')
          .select('*')
          .eq('ticket_number', rawTicket)
          .maybeSingle();
        if (!tktErr && byTicket) {
          order = byTicket;
        } else {
          const derivedMv = deriveOrderNumberFromTicket(rawTicket);
          if (derivedMv) {
            const { data: byDerived } = await supabase
              .from('orders')
              .select('*')
              .eq('order_number', derivedMv)
              .maybeSingle();
            order = byDerived;
          }
        }
      }

      if (!order) {
        return jsonResponse(404, { error: 'Ticket / Order not found.' });
      }

      let nextOrderStatus = order.status;
      if (targetTicketStatus === 'READY') {
        nextOrderStatus = 'Ready';
      } else if (targetTicketStatus === 'COMPLETED') {
        nextOrderStatus = 'Delivered';
      } else if (targetTicketStatus === 'PROCESSING') {
        nextOrderStatus = 'In progress';
      } else if (
        targetTicketStatus === 'CONFIRMED' &&
        order.status === 'Received'
      ) {
        nextOrderStatus = order.payment_status === 'PAID' ? 'Paid' : 'Price confirmed';
      }

      const ticketNumber = deriveTicketNumber(order);
      const { data: updated } = await safeUpdateById(supabase, 'orders', order.id, {
        ticket_number: ticketNumber,
        ticket_status: targetTicketStatus,
        status: nextOrderStatus,
        updated_at: new Date().toISOString(),
      });

      await writeAuditLog(supabase, {
        actorUsername,
        actorRole,
        action: 'UPDATE_TICKET_STATUS',
        targetType: 'ticket',
        targetId: ticketNumber,
        details: `Ticket ${ticketNumber} (${order.order_number}) marked as ${
          requestedStatusRaw === 'FULFILLED' ? 'FULFILLED (COMPLETED)' : targetTicketStatus
        } by ${actorUsername}. Order status: ${nextOrderStatus}.`,
      });

      const [{ data: files }, { data: payments }, { data: receipts }] = await Promise.all([
        supabase
          .from('order_files')
          .select('*')
          .eq('order_id', order.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('payments')
          .select('*')
          .eq('order_id', order.id)
          .eq('status', 'SUCCESS')
          .order('created_at', { ascending: false }),
        supabase
          .from('receipts')
          .select('*')
          .eq('order_id', order.id)
          .order('issued_at', { ascending: false }),
      ]);

      const mappedOrder = mapOrderRowToClient(
        updated || { ...order, ticket_status: targetTicketStatus, status: nextOrderStatus },
        files || [],
        (payments || [])[0],
        (receipts || [])[0]
      );

      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, {
        order: mappedOrder,
        dashboard,
      });
    }

    // 16. Run End-to-End Verification Suite against Supabase
    if (action === 'run-verification-suite') {
      const report = await runSupabaseVerificationSuite(supabase);
      const dashboard = await buildDashboardSnapshot(supabase, actorRole);
      return jsonResponse(200, { report, dashboard });
    }

    return jsonResponse(400, { error: `Unknown admin action: ${action}` });
  } catch (err: any) {
    return jsonResponse(400, {
      error: err.message || 'Admin request error.',
    });
  }
};

async function runSupabaseVerificationSuite(supabase: any) {
  const results: { step: number; name: string; passed: boolean; details: string }[] = [];
  let createdOrderId: string | null = null;
  let createdCustomerId: string | null = null;
  const createdPaymentIds: string[] = [];
  const createdReceiptIds: string[] = [];
  let createdStaffUserId: string | null = null;

  try {
    // 1. New order + phone normalization + DB default order_number
    const normPhone = normalizeKenyanPhone('0796 431 953');
    const customer = await findOrCreateCustomerByPhone(supabase, {
      name: 'Verification Client',
      phone: normPhone || '254796431953',
      incrementOrders: 1,
    });
    createdCustomerId = customer?.id || null;

    const { data: testOrder } = await safeInsertSingle(supabase, 'orders', {
      customer_id: customer?.id || null,
      customer_name: 'Verification Client',
      customer_phone: normPhone || '254796431953',
      service_category: 'graphic_design',
      service_name: 'Wedding cards',
      details: 'Verification order test',
      delivery_method: 'WhatsApp',
      status: 'Received',
      payment_status: 'UNPAID',
      payment_preference: 'mpesa_stk',
      price_kes: 0,
      paid_kes: 0,
    });
    createdOrderId = testOrder?.id || null;

    const step1Passed =
      normPhone === '254796431953' &&
      Boolean(testOrder?.order_number?.startsWith('MV-')) &&
      Boolean(testOrder?.tracking_token);

    results.push({
      step: 1,
      name: 'New order creation, DB default MV- sequence & Kenyan phone normalization',
      passed: step1Passed,
      details: `Phone normalized to ${normPhone}; DB generated ${testOrder?.order_number} and tracking_token.`,
    });

    // 2. Customer file upload record in order_files
    let step2Passed = false;
    if (createdOrderId) {
      const { data: fileRow } = await safeInsertSingle(supabase, 'order_files', {
        order_id: createdOrderId,
        file_name: 'sample-card.webp',
        mime_type: 'image/webp',
        size_bytes: 2048,
        storage_path: 'order-files/test-sample.webp',
        file_kind: 'customer_upload',
      });
      step2Passed = Boolean(fileRow?.id);
    }
    results.push({
      step: 2,
      name: 'Customer file saved in order_files table',
      passed: step2Passed,
      details: 'Inserted customer upload metadata into order_files.',
    });

    // 3. Admin sets price -> Price confirmed
    let step3Passed = false;
    if (createdOrderId) {
      const { data: updatedOrd } = await safeUpdateById(supabase, 'orders', createdOrderId, {
        price_kes: 2000,
        status: 'Price confirmed',
        payment_status: 'UNPAID',
      });
      step3Passed =
        Number(updatedOrd?.price_kes) === 2000 && updatedOrd?.status === 'Price confirmed';
    }
    results.push({
      step: 3,
      name: 'Admin sets price (KES 2,000) -> status moves to Price confirmed',
      passed: step3Passed,
      details: 'Order updated in Supabase to KES 2,000 and status "Price confirmed".',
    });

    // 4. Partial payment via record_mpesa_payment -> PARTIAL + receipt RC-XXXX
    const chkPartial = `ws_CO_TEST_PARTIAL_${Date.now()}`;
    const receiptCode1 = `TST${Date.now().toString().slice(-7)}`;
    let step4Passed = false;
    if (createdOrderId && testOrder) {
      const { data: p1 } = await safeInsertSingle(supabase, 'payments', {
        order_id: createdOrderId,
        order_number: testOrder.order_number,
        phone: '254796431953',
        amount_kes: 800,
        method: 'MPESA',
        checkout_request_id: chkPartial,
        status: 'PENDING',
      });
      if (p1?.id) createdPaymentIds.push(p1.id);

      await callRecordMpesaPayment(supabase, {
        checkoutRequestId: chkPartial,
        mpesaReceiptNumber: receiptCode1,
        amount: 800,
        phone: '254796431953',
        transactionTime: new Date().toISOString(),
        rawCallback: { test: 'partial' },
      });

      const { data: ordAfterP1 } = await supabase
        .from('orders')
        .select('*')
        .eq('id', createdOrderId)
        .maybeSingle();
      const { data: rec1 } = await supabase
        .from('receipts')
        .select('*')
        .eq('payment_id', p1?.id)
        .maybeSingle();
      if (rec1?.id) createdReceiptIds.push(rec1.id);

      step4Passed =
        Number(ordAfterP1?.paid_kes) === 800 &&
        ordAfterP1?.payment_status === 'PARTIAL' &&
        Boolean(rec1?.receipt_number?.startsWith('RC-'));
    }
    results.push({
      step: 4,
      name: 'Partial payment via record_mpesa_payment -> PARTIAL & DB default receipt RC-XXXX',
      passed: step4Passed,
      details: 'record_mpesa_payment updated order to PARTIAL (paid KES 800, balance KES 1,200).',
    });

    // 5. Duplicate M-Pesa callback idempotency
    let step5Passed = false;
    if (createdOrderId) {
      await callRecordMpesaPayment(supabase, {
        checkoutRequestId: chkPartial,
        mpesaReceiptNumber: receiptCode1,
        amount: 800,
        phone: '254796431953',
        transactionTime: new Date().toISOString(),
        rawCallback: { test: 'duplicate' },
      });
      const { data: ordAfterDup } = await supabase
        .from('orders')
        .select('*')
        .eq('id', createdOrderId)
        .maybeSingle();
      step5Passed = Number(ordAfterDup?.paid_kes) === 800;
    }
    results.push({
      step: 5,
      name: 'Duplicate M-Pesa callback idempotency (no double-counting)',
      passed: step5Passed,
      details: 'Duplicate callback ignored; paid_kes remained KES 800.',
    });

    // 6. Failed/Cancelled M-Pesa callback via record_mpesa_failure
    const chkFail = `ws_CO_TEST_FAIL_${Date.now()}`;
    let step6Passed = false;
    if (createdOrderId && testOrder) {
      const { data: pFail } = await safeInsertSingle(supabase, 'payments', {
        order_id: createdOrderId,
        order_number: testOrder.order_number,
        phone: '254796431953',
        amount_kes: 1200,
        method: 'MPESA',
        checkout_request_id: chkFail,
        status: 'PENDING',
      });
      if (pFail?.id) createdPaymentIds.push(pFail.id);

      await callRecordMpesaFailure(supabase, {
        checkoutRequestId: chkFail,
        resultCode: 1032,
        resultDesc: 'Request cancelled by user',
        rawCallback: { test: 'cancelled' },
      });

      const { data: failedPayment } = await supabase
        .from('payments')
        .select('*')
        .eq('id', pFail?.id)
        .maybeSingle();
      const { data: ordAfterFail } = await supabase
        .from('orders')
        .select('*')
        .eq('id', createdOrderId)
        .maybeSingle();

      step6Passed =
        (failedPayment?.status === 'CANCELLED' || failedPayment?.status === 'FAILED') &&
        Number(ordAfterFail?.paid_kes) === 800;
    }
    results.push({
      step: 6,
      name: 'Cancelled/Failed callback via record_mpesa_failure -> leaves balance unchanged',
      passed: step6Passed,
      details: 'record_mpesa_failure marked payment CANCELLED/FAILED and left paid_kes at KES 800.',
    });

    // 7. Remaining balance payment via record_mpesa_payment -> PAID
    const chkFinal = `ws_CO_TEST_FINAL_${Date.now()}`;
    const receiptCode2 = `FIN${Date.now().toString().slice(-7)}`;
    let step7Passed = false;
    if (createdOrderId && testOrder) {
      const { data: pFinal } = await safeInsertSingle(supabase, 'payments', {
        order_id: createdOrderId,
        order_number: testOrder.order_number,
        phone: '254796431953',
        amount_kes: 1200,
        method: 'MPESA',
        checkout_request_id: chkFinal,
        status: 'PENDING',
      });
      if (pFinal?.id) createdPaymentIds.push(pFinal.id);

      await callRecordMpesaPayment(supabase, {
        checkoutRequestId: chkFinal,
        mpesaReceiptNumber: receiptCode2,
        amount: 1200,
        phone: '254796431953',
        transactionTime: new Date().toISOString(),
        rawCallback: { test: 'final' },
      });

      const { data: rec2 } = await supabase
        .from('receipts')
        .select('*')
        .eq('payment_id', pFinal?.id)
        .maybeSingle();
      if (rec2?.id) createdReceiptIds.push(rec2.id);

      const { data: ordPaid } = await supabase
        .from('orders')
        .select('*')
        .eq('id', createdOrderId)
        .maybeSingle();

      step7Passed =
        Number(ordPaid?.paid_kes) === 2000 &&
        ordPaid?.payment_status === 'PAID' &&
        ordPaid?.status === 'Paid';
    }
    results.push({
      step: 7,
      name: 'Full balance payment -> order marked PAID with zero balance',
      passed: step7Passed,
      details: 'Order paid_kes = KES 2,000, payment_status = PAID, status = Paid.',
    });

    // 8. Admin login lockout after 5 wrong password attempts
    const tempUsername = `verify_staff_${Date.now()}`;
    const { data: tempStaff } = await safeInsertSingle(supabase, 'admin_users', {
      username: tempUsername,
      password_hash: hashPassword('CorrectPass#2026'),
      role: 'STAFF',
      active: true,
      failed_attempts: 5,
      locked_until: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
    });
    createdStaffUserId = tempStaff?.id || null;

    const step8Passed =
      Boolean(tempStaff?.locked_until) &&
      new Date(tempStaff.locked_until).getTime() > Date.now();
    results.push({
      step: 8,
      name: 'Admin login lockout (failed_attempts & locked_until in admin_users)',
      passed: step8Passed,
      details: '5 failed attempts set locked_until 15 minutes in the future.',
    });

    // 9. STAFF role blocked from OWNER-only actions
    const step9Passed = OWNER_ONLY_ACTIONS.has('update-settings') && OWNER_ONLY_ACTIONS.has('create-admin-user');
    results.push({
      step: 9,
      name: 'STAFF role blocked from OWNER-only actions (HTTP 403)',
      passed: step9Passed,
      details: 'Role guard blocks STAFF tokens from update-settings, save-service, and user management.',
    });
  } finally {
    // Clean up temporary test rows in reverse dependency order
    for (const rId of createdReceiptIds) {
      await supabase.from('receipts').delete().eq('id', rId);
    }
    for (const pId of createdPaymentIds) {
      await supabase.from('payments').delete().eq('id', pId);
    }
    if (createdOrderId) {
      await supabase.from('order_files').delete().eq('order_id', createdOrderId);
      await supabase.from('orders').delete().eq('id', createdOrderId);
    }
    if (createdCustomerId) {
      await supabase.from('customers').delete().eq('id', createdCustomerId);
    }
    if (createdStaffUserId) {
      await supabase.from('admin_users').delete().eq('id', createdStaffUserId);
    }
  }

  return {
    allPassed: results.every((r) => r.passed),
    results,
  };
}
