import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  LayoutDashboard,
  ClipboardList,
  FileText,
  Users,
  Image as ImageIcon,
  Layers,
  BarChart3,
  Settings as SettingsIcon,
  ShieldCheck,
  LogOut,
  ArrowLeft,
  Search,
  Upload,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Download,
  Lock,
  Unlock,
  Play,
  Printer,
  Copy,
  QrCode,
  Mail,
  MessageSquare,
} from 'lucide-react';
import { Logo } from './Logo.tsx';
import { TicketCard, TicketStatusType } from './TicketCard.tsx';
import {
  PublicDocumentModal,
  PublicInvoiceView,
  PublicReceiptView,
} from './PublicDocumentModal.tsx';

interface AdminPanelProps {
  onBackToSite: () => void;
  onPublicDataChanged: () => void;
}

type AdminTab =
  | 'dashboard'
  | 'orders'
  | 'verify-ticket'
  | 'invoices'
  | 'customers'
  | 'portfolio'
  | 'services'
  | 'reports'
  | 'settings'
  | 'users'
  | 'verification';

const ORDER_STATUSES = [
  'Received',
  'Price confirmed',
  'Paid',
  'In progress',
  'Ready',
  'Delivered',
] as const;

const TICKET_STATUS_OPTIONS: TicketStatusType[] = [
  'PENDING_PAYMENT',
  'CONFIRMED',
  'PROCESSING',
  'READY',
  'COMPLETED',
  'CANCELLED',
];

const DEFAULT_PORTFOLIO_CATEGORIES = [
  'Wedding cards',
  'Funeral programs',
  'Posters and flyers',
  'Logos',
  'Birthday cards',
  'Church posters',
  'Company profiles',
  'Social media banners',
] as const;

interface DraftPortfolioImage {
  id: string;
  thumbUrl: string;
  mediumUrl: string;
  publicUrl: string;
  originalPath: string;
  width: number;
  height: number;
  altText: string;
  isCover: boolean;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  onBackToSite,
  onPublicDataChanged,
}) => {
  const [token, setToken] = useState<string | null>(() =>
    sessionStorage.getItem('mv_admin_token')
  );
  const [currentUser, setCurrentUser] = useState<{
    username: string;
    role: 'OWNER' | 'STAFF';
  } | null>(null);
  const [hasOwnerAccount, setHasOwnerAccount] = useState<boolean>(true);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  const [activeTab, setActiveTab] = useState<AdminTab>(() =>
    window.location.pathname.startsWith('/admin/verify') ? 'verify-ticket' : 'dashboard'
  );
  const [dashboard, setDashboard] = useState<any | null>(null);
  const [loadingData, setLoadingData] = useState(false);
  const [actionNotice, setActionNotice] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Order filters & selected order
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('ALL');
  const [orderCategoryFilter, setOrderCategoryFilter] = useState<string>('ALL');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [editPriceKes, setEditPriceKes] = useState<string>('');
  const [editOrderStatus, setEditOrderStatus] = useState<string>('Received');
  const [editTicketStatus, setEditTicketStatus] = useState<string>('PENDING_PAYMENT');
  const [stkPhoneInput, setStkPhoneInput] = useState<string>('');
  const [stkAmountInput, setStkAmountInput] = useState<string>('');
  const [lastCheckoutId, setLastCheckoutId] = useState<string | null>(null);
  const [manualPayAmount, setManualPayAmount] = useState<string>('');
  const [manualPayMethod, setManualPayMethod] = useState<string>('MPESA_MANUAL');
  const [manualPayRef, setManualPayRef] = useState<string>('');

  // Admin Ticket Verification (/admin/verify) state
  const [verifyTicketInput, setVerifyTicketInput] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    return (params.get('ticket') || '').trim().toUpperCase();
  });
  const [verifiedOrderResult, setVerifiedOrderResult] = useState<any | null>(null);
  const [verifyTicketLoading, setVerifyTicketLoading] = useState<boolean>(false);

  // Invoice creation form
  const [invCustomerName, setInvCustomerName] = useState('');
  const [invCustomerPhone, setInvCustomerPhone] = useState('');
  const [invDiscountKes, setInvDiscountKes] = useState('0');
  const [invDueDate, setInvDueDate] = useState('');
  const [invNotes, setInvNotes] = useState('');
  const [invItems, setInvItems] = useState<
    { description: string; quantity: number; unitPriceKes: number }[]
  >([{ description: 'Graphic design / online service', quantity: 1, unitPriceKes: 1000 }]);

  // Document preview modal
  const [docModal, setDocModal] = useState<{
    type: 'invoice' | 'receipt';
    invoice?: PublicInvoiceView;
    receipt?: PublicReceiptView;
  } | null>(null);

  // Portfolio form & manager state
  const [editingPortfolioId, setEditingPortfolioId] = useState<string | null>(null);
  const [portTitle, setPortTitle] = useState('');
  const [portCategory, setPortCategory] = useState<string>('Wedding cards');
  const [portDesc, setPortDesc] = useState('');
  const [portDate, setPortDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [portTags, setPortTags] = useState('');
  const [portClientLabel, setPortClientLabel] = useState('');
  const [portIsSample, setPortIsSample] = useState(true);
  const [portWatermark, setPortWatermark] = useState(true);
  const [portFeatured, setPortFeatured] = useState(false);
  const [portVisible, setPortVisible] = useState(true);
  const [portImages, setPortImages] = useState<DraftPortfolioImage[]>([]);
  const [portUploading, setPortUploading] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [draggedPortfolioId, setDraggedPortfolioId] = useState<string | null>(null);
  const [adminPortfolioFilter, setAdminPortfolioFilter] = useState<string>('ALL');

  // Users creation form
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<'OWNER' | 'STAFF'>('STAFF');

  // Verification suite report
  const [verificationReport, setVerificationReport] = useState<any | null>(null);
  const [runningVerification, setRunningVerification] = useState(false);

  const inactivityTimerRef = useRef<number | null>(null);

  // Manage <meta name="robots" content="noindex, nofollow" /> for /admin
  useEffect(() => {
    let meta = document.querySelector('meta[name="robots"]') as HTMLMetaElement | null;
    const created = !meta;
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'robots';
      document.head.appendChild(meta);
    }
    meta.content = 'noindex, nofollow';
    return () => {
      if (created && meta && meta.parentNode) {
        meta.parentNode.removeChild(meta);
      }
    };
  }, []);

  const showNotice = (type: 'success' | 'error', text: string) => {
    setActionNotice({ type, text });
    setTimeout(() => {
      setActionNotice((prev) => (prev?.text === text ? null : prev));
    }, 5000);
  };

  const callAdminApi = useCallback(
    async (payload: Record<string, any>, customToken?: string | null) => {
      const activeToken = customToken !== undefined ? customToken : token;
      const res = await fetch('/.netlify/functions/admin-api', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(activeToken ? { Authorization: `Bearer ${activeToken}` } : {}),
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) {
          sessionStorage.removeItem('mv_admin_token');
          setToken(null);
          setCurrentUser(null);
        }
        throw new Error(data.error || 'Request could not be completed.');
      }
      return data;
    },
    [token]
  );

  const handleLogout = useCallback(async () => {
    try {
      if (token) {
        await fetch('/.netlify/functions/admin-api', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ action: 'logout' }),
        });
      }
    } catch {
      // Ignore logout network errors
    } finally {
      sessionStorage.removeItem('mv_admin_token');
      setToken(null);
      setCurrentUser(null);
      setDashboard(null);
    }
  }, [token]);

  // 30-minute inactivity auto-logout
  useEffect(() => {
    if (!currentUser) return;
    const resetTimer = () => {
      if (inactivityTimerRef.current) {
        window.clearTimeout(inactivityTimerRef.current);
      }
      inactivityTimerRef.current = window.setTimeout(() => {
        handleLogout();
      }, 30 * 60 * 1000);
    };
    resetTimer();
    const events = ['mousedown', 'keydown', 'touchstart', 'scroll'];
    events.forEach((ev) => window.addEventListener(ev, resetTimer, { passive: true }));
    return () => {
      if (inactivityTimerRef.current) window.clearTimeout(inactivityTimerRef.current);
      events.forEach((ev) => window.removeEventListener(ev, resetTimer));
    };
  }, [currentUser, handleLogout]);

  const loadDashboard = useCallback(
    async (overrideToken?: string) => {
      setLoadingData(true);
      try {
        const data = await callAdminApi({ action: 'get-dashboard' }, overrideToken);
        setDashboard(data);
      } catch (err: any) {
        showNotice('error', err.message || 'Could not load dashboard.');
      } finally {
        setLoadingData(false);
      }
    },
    [callAdminApi]
  );

  useEffect(() => {
    (async () => {
      setAuthLoading(true);
      try {
        const statusData = await callAdminApi({ action: 'auth-status' }, token);
        setHasOwnerAccount(Boolean(statusData.hasOwnerAccount));
        if (statusData.session) {
          setCurrentUser(statusData.session);
          await loadDashboard(token || undefined);
        } else {
          setToken(null);
          setCurrentUser(null);
        }
      } catch {
        setToken(null);
        setCurrentUser(null);
      } finally {
        setAuthLoading(false);
      }
    })();
  }, []);

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthLoading(true);
    try {
      const action = hasOwnerAccount ? 'login' : 'bootstrap-owner';
      const data = await callAdminApi(
        {
          action,
          username: loginUsername,
          password: loginPassword,
        },
        null
      );
      sessionStorage.setItem('mv_admin_token', data.token);
      setToken(data.token);
      setCurrentUser(data.user);
      setHasOwnerAccount(true);
      setLoginPassword('');
      await loadDashboard(data.token);
    } catch (err: any) {
      setAuthError(err.message || 'Could not sign in.');
    } finally {
      setAuthLoading(false);
    }
  };

  const selectedOrder = dashboard?.orders?.find((o: any) => o.id === selectedOrderId) || null;

  useEffect(() => {
    if (selectedOrder) {
      setEditPriceKes(String(selectedOrder.priceKes || 0));
      setEditOrderStatus(selectedOrder.status);
      setEditTicketStatus(selectedOrder.ticketStatus || 'PENDING_PAYMENT');
      setStkPhoneInput(selectedOrder.customerPhone);
      const balance = Math.max(0, (selectedOrder.priceKes || 0) - (selectedOrder.paidKes || 0));
      setStkAmountInput(String(balance > 0 ? balance : selectedOrder.priceKes || 0));
      setManualPayAmount(String(balance > 0 ? balance : 500));
    }
  }, [
    selectedOrderId,
    selectedOrder?.priceKes,
    selectedOrder?.paidKes,
    selectedOrder?.status,
    selectedOrder?.ticketStatus,
  ]);

  const handleVerifyTicketLookup = useCallback(
    async (e?: React.FormEvent, overrideTicket?: string) => {
      if (e) e.preventDefault();
      const target = (overrideTicket ?? verifyTicketInput).trim().toUpperCase();
      if (!target) return;
      setVerifyTicketLoading(true);
      try {
        const res = await callAdminApi({
          action: 'verify-ticket-lookup',
          ticketNumber: target,
        });
        setVerifiedOrderResult(res.order);
        showNotice(
          'success',
          `Verified ticket ${res.order.ticketNumber} (Order ${res.order.orderNumber}).`
        );
      } catch (err: any) {
        setVerifiedOrderResult(null);
        showNotice('error', err.message || 'Ticket not found.');
      } finally {
        setVerifyTicketLoading(false);
      }
    },
    [callAdminApi, verifyTicketInput]
  );

  // Auto-lookup ticket if staff navigated to /admin/verify?ticket=TKT-...
  useEffect(() => {
    if (currentUser && verifyTicketInput && !verifiedOrderResult) {
      handleVerifyTicketLookup(undefined, verifyTicketInput);
    }
  }, [currentUser]);

  const handleQuickMarkTicketStatus = async (
    orderToUpdate: any,
    newStatus: 'READY' | 'FULFILLED' | 'CONFIRMED' | 'PROCESSING' | 'CANCELLED'
  ) => {
    if (!orderToUpdate) return;
    try {
      const res = await callAdminApi({
        action: 'update-ticket-status',
        orderId: orderToUpdate.id,
        ticketNumber: orderToUpdate.ticketNumber,
        ticketStatus: newStatus,
      });
      if (res.dashboard) setDashboard(res.dashboard);
      if (res.order) setVerifiedOrderResult(res.order);
      showNotice(
        'success',
        `Ticket ${orderToUpdate.ticketNumber} marked as ${newStatus}.`
      );
    } catch (err: any) {
      showNotice('error', err.message || 'Could not update ticket status.');
    }
  };

  const handleSaveOrderChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;
    try {
      const res = await callAdminApi({
        action: 'update-order',
        orderId: selectedOrder.id,
        priceKes: Number(editPriceKes || 0),
        status: editOrderStatus,
        ticketStatus: editTicketStatus,
      });
      setDashboard(res.dashboard);
      showNotice(
        'success',
        `Saved changes for ${selectedOrder.orderNumber} (${selectedOrder.ticketNumber || 'Ticket updated'}).`
      );
    } catch (err: any) {
      showNotice('error', err.message);
    }
  };

  const handleUploadDeliverable = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedOrder) return;
    if (file.size > 10 * 1024 * 1024) {
      showNotice('error', 'File exceeds the 10 MB limit.');
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const res = await callAdminApi({
          action: 'update-order',
          orderId: selectedOrder.id,
          deliverableFileName: file.name,
          deliverableFileUrl: String(reader.result),
          deliverableMimeType: file.type,
          deliverableSizeBytes: file.size,
          status: selectedOrder.status === 'Delivered' ? 'Delivered' : 'Ready',
        });
        setDashboard(res.dashboard);
        showNotice('success', `Attached finished work "${file.name}" to ${selectedOrder.orderNumber}.`);
      } catch (err: any) {
        showNotice('error', err.message);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSendOrderStkPush = async () => {
    if (!selectedOrder) return;
    try {
      const res = await fetch('/.netlify/functions/stkpush', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderNumber: selectedOrder.orderNumber,
          phone: stkPhoneInput || selectedOrder.customerPhone,
          amountKes: Number(stkAmountInput || 0),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not send STK push.');
      setLastCheckoutId(data.checkoutRequestId);
      await loadDashboard();
      showNotice(
        'success',
        `STK Push sent (${data.checkoutRequestId}) for KES ${data.amountKes}.`
      );
    } catch (err: any) {
      showNotice('error', err.message);
    }
  };

  const handleSimulateCallback = async (
    mode: 'full' | 'partial' | 'duplicate' | 'failed'
  ) => {
    if (!selectedOrder) return;
    try {
      let checkoutId = lastCheckoutId;
      const balance = Math.max(0, selectedOrder.priceKes - selectedOrder.paidKes);
      const targetAmount =
        mode === 'partial'
          ? Math.max(100, Math.floor((balance || 1000) / 2))
          : balance > 0
          ? balance
          : Number(stkAmountInput || 500);

      // If no pending checkout ID exists yet (or if not testing duplicate), initiate an STK request first
      if (!checkoutId || mode !== 'duplicate') {
        const stkRes = await fetch('/.netlify/functions/stkpush', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderNumber: selectedOrder.orderNumber,
            phone: selectedOrder.customerPhone,
            amountKes: targetAmount,
          }),
        });
        const stkData = await stkRes.json();
        if (!stkRes.ok) throw new Error(stkData.error || 'Set an order price first before testing payment.');
        checkoutId = stkData.checkoutRequestId;
        setLastCheckoutId(checkoutId);
      }

      const payload =
        mode === 'failed'
          ? {
              checkoutRequestId: checkoutId,
              resultCode: 1032,
              resultDesc: 'Request cancelled by user.',
            }
          : {
              checkoutRequestId: checkoutId,
              resultCode: 0,
              resultDesc: 'The service request is processed successfully.',
              amountKes: targetAmount,
              mpesaReceiptCode:
                mode === 'duplicate'
                  ? selectedOrder.payments?.[0]?.mpesaReceiptCode || 'DUP123456'
                  : `MP${Date.now().toString().slice(-7)}`,
              phone: selectedOrder.customerPhone,
            };

      const cbRes = await fetch('/.netlify/functions/mpesa-callback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const cbData = await cbRes.json();
      if (!cbRes.ok) throw new Error(cbData.error || 'Callback simulation failed.');
      await loadDashboard();
      showNotice(
        'success',
        mode === 'duplicate'
          ? 'Duplicate callback verified: ignored idempotently without double-counting.'
          : `${cbData.ResultDesc || 'Callback processed.'}`
      );
    } catch (err: any) {
      showNotice('error', err.message);
    }
  };

  const handleRecordManualPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;
    try {
      const res = await callAdminApi({
        action: 'record-manual-payment',
        orderId: selectedOrder.id,
        amountKes: Number(manualPayAmount || 0),
        method: manualPayMethod,
        mpesaReceiptCode: manualPayRef,
      });
      setDashboard(res.dashboard);
      setManualPayRef('');
      showNotice(
        'success',
        `Recorded payment and issued receipt ${res.receipt?.receiptNumber || ''}.`
      );
    } catch (err: any) {
      showNotice('error', err.message);
    }
  };

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await callAdminApi({
        action: 'create-invoice',
        customerName: invCustomerName,
        customerPhone: invCustomerPhone,
        discountKes: Number(invDiscountKes || 0),
        dueDate: invDueDate || undefined,
        notes: invNotes || undefined,
        items: invItems,
      });
      setDashboard(res.dashboard);
      setInvCustomerName('');
      setInvCustomerPhone('');
      setInvDiscountKes('0');
      setInvNotes('');
      showNotice('success', `Created invoice ${res.invoice.invoiceNumber}.`);
    } catch (err: any) {
      showNotice('error', err.message);
    }
  };

  const callPortfolioAdminApi = useCallback(
    async (payload: Record<string, any>) => {
      const res = await fetch('/.netlify/functions/portfolio-admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Portfolio operation could not be completed.');
      }
      return data;
    },
    [token]
  );

  const resetPortfolioForm = () => {
    setEditingPortfolioId(null);
    setPortTitle('');
    setPortCategory(
      dashboard?.portfolioCategories?.[0]?.name || DEFAULT_PORTFOLIO_CATEGORIES[0]
    );
    setPortDesc('');
    setPortDate(new Date().toISOString().slice(0, 10));
    setPortTags('');
    setPortClientLabel('');
    setPortIsSample(true);
    setPortWatermark(true);
    setPortFeatured(false);
    setPortVisible(true);
    setPortImages([]);
  };

  // Client-side WebP resizing (~480px thumb, ~1200px medium, ~1200px watermarked public)
  const processImageFileToWebpVariants = (
    file: File,
    applyWatermark: boolean,
    defaultAlt: string,
    originalPath: string,
    isCover: boolean
  ): Promise<DraftPortfolioImage> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error(`Could not read ${file.name}`));
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error(`Invalid image file ${file.name}`));
        img.onload = () => {
          const naturalW = img.naturalWidth || 800;
          const naturalH = img.naturalHeight || 600;

          const renderVariant = (maxDim: number, watermarkText?: string) => {
            const scale = Math.min(1, maxDim / Math.max(naturalW, naturalH));
            const w = Math.max(1, Math.round(naturalW * scale));
            const h = Math.max(1, Math.round(naturalH * scale));
            const canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext('2d');
            if (!ctx) return String(reader.result);
            ctx.drawImage(img, 0, 0, w, h);

            if (watermarkText) {
              const fontSize = Math.max(12, Math.round(w * 0.024));
              ctx.save();
              ctx.font = `600 ${fontSize}px "Plus Jakarta Sans", sans-serif`;
              const textMetrics = ctx.measureText(watermarkText);
              const padX = Math.round(fontSize * 0.7);
              const padY = Math.round(fontSize * 0.45);
              const boxW = textMetrics.width + padX * 2;
              const boxH = fontSize + padY * 2;
              const boxX = w - boxW - Math.round(w * 0.025);
              const boxY = h - boxH - Math.round(h * 0.025);

              ctx.fillStyle = 'rgba(15, 23, 42, 0.58)';
              ctx.beginPath();
              ctx.roundRect(boxX, boxY, boxW, boxH, 6);
              ctx.fill();

              ctx.fillStyle = 'rgba(255, 255, 255, 0.92)';
              ctx.fillText(watermarkText, boxX + padX, boxY + padY + fontSize * 0.82);
              ctx.restore();
            }

            const webp = canvas.toDataURL('image/webp', 0.84);
            return webp.startsWith('data:image/webp')
              ? webp
              : canvas.toDataURL('image/jpeg', 0.84);
          };

          const scale1200 = Math.min(1, 1200 / Math.max(naturalW, naturalH));
          const finalW = Math.max(1, Math.round(naturalW * scale1200));
          const finalH = Math.max(1, Math.round(naturalH * scale1200));

          const thumbUrl = renderVariant(480);
          const mediumUrl = renderVariant(1200);
          const publicUrl = applyWatermark
            ? renderVariant(1200, 'Mannu Visuals')
            : mediumUrl;

          resolve({
            id: `img-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            thumbUrl,
            mediumUrl,
            publicUrl,
            originalPath,
            width: finalW,
            height: finalH,
            altText: defaultAlt,
            isCover,
          });
        };
        img.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
  };

  const handlePortfolioImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const files: File[] = Array.from(fileList);

    for (const f of files) {
      if (f.size > 8 * 1024 * 1024) {
        showNotice('error', `File "${f.name}" exceeds the 8 MB limit.`);
        return;
      }
    }

    setPortUploading(true);
    try {
      // Request signed upload slots from Netlify Function /.netlify/functions/portfolio-upload-url
      const signedRes = await fetch('/.netlify/functions/portfolio-upload-url', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          files: files.map((f) => ({
            fileName: f.name,
            mimeType: f.type || 'image/webp',
            sizeBytes: f.size,
          })),
        }),
      });
      const signedData = await signedRes.json();
      if (!signedRes.ok) {
        throw new Error(signedData.error || 'Could not obtain signed upload URL.');
      }

      const slots = signedData.slots || [];
      const processed: DraftPortfolioImage[] = [];
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const baseName = f.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' ');
        const defaultAlt = portTitle
          ? `${portTitle} (${i + 1})`
          : baseName || 'Design sample';
        const slotPath =
          slots[i]?.originalPath || `portfolio-private/${Date.now()}-${f.name}`;
        const hasCoverAlready = portImages.some((img) => img.isCover) || i > 0;
        const variant = await processImageFileToWebpVariants(
          f,
          portWatermark,
          defaultAlt,
          slotPath,
          !hasCoverAlready && i === 0
        );
        processed.push(variant);
      }

      setPortImages((prev) => [...prev, ...processed]);
      if (!portTitle && files.length === 1) {
        const inferred = files[0].name
          .replace(/\.[^.]+$/, '')
          .replace(/[-_]+/g, ' ')
          .replace(/\b\w/g, (c) => c.toUpperCase());
        setPortTitle(inferred);
      }
      showNotice(
        'success',
        `Processed ${processed.length} image(s) into WebP thumbnail and viewer sizes.`
      );
    } catch (err: any) {
      showNotice('error', err.message || 'Image processing failed.');
    } finally {
      setPortUploading(false);
      e.target.value = '';
    }
  };

  const handleBulkPortfolioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const files: File[] = Array.from(fileList);

    setPortUploading(true);
    try {
      const signedRes = await fetch('/.netlify/functions/portfolio-upload-url', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          files: files.map((f) => ({
            fileName: f.name,
            mimeType: f.type || 'image/webp',
            sizeBytes: f.size,
          })),
        }),
      });
      const signedData = await signedRes.json();
      if (!signedRes.ok) {
        throw new Error(signedData.error || 'Could not obtain signed upload URLs.');
      }
      const slots = signedData.slots || [];

      const itemsPayload = [];
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const cleanTitle =
          f.name
            .replace(/\.[^.]+$/, '')
            .replace(/[-_]+/g, ' ')
            .replace(/\b\w/g, (c) => c.toUpperCase()) || `Design Work ${i + 1}`;
        const slotPath =
          slots[i]?.originalPath || `portfolio-private/${Date.now()}-${f.name}`;
        const imgVariant = await processImageFileToWebpVariants(
          f,
          portWatermark,
          cleanTitle,
          slotPath,
          true
        );
        itemsPayload.push({
          title: cleanTitle,
          category: portCategory,
          description: portDesc || `${portCategory} sample prepared by Mannu Visuals.`,
          projectDate: portDate,
          isSample: portIsSample,
          watermark: portWatermark,
          featured: false,
          visible: true,
          images: [imgVariant],
        });
      }

      const res = await callPortfolioAdminApi({
        subAction: 'bulk-create',
        items: itemsPayload,
      });
      setDashboard(res.dashboard);
      onPublicDataChanged();
      showNotice('success', `Bulk uploaded ${itemsPayload.length} portfolio items.`);
    } catch (err: any) {
      showNotice('error', err.message || 'Bulk upload failed.');
    } finally {
      setPortUploading(false);
      e.target.value = '';
    }
  };

  const handleGenerateSampleSvgImage = (
    category: string,
    title: string,
    includeBackSide = false
  ) => {
    const cleanTitle = title || `${category} Sample`;
    const makeSvg = (subtitle: string, accentHex: string) => {
      const wm = portWatermark
        ? `<g transform="translate(590, 540)"><rect width="170" height="32" rx="6" fill="#0F172A" fill-opacity="0.65"/><text x="85" y="21" text-anchor="middle" font-family="Plus Jakarta Sans, sans-serif" font-size="13" font-weight="600" fill="#FFFFFF">Mannu Visuals</text></g>`
        : '';
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600">
        <rect width="800" height="600" fill="#F8FAFC"/>
        <rect x="40" y="40" width="720" height="520" rx="16" fill="#FFFFFF" stroke="#E2E8F0" stroke-width="2"/>
        <rect x="40" y="40" width="720" height="12" fill="${accentHex}"/>
        <circle cx="105" cy="120" r="24" fill="#0B4DA8"/>
        <text x="145" y="116" font-family="Plus Jakarta Sans, sans-serif" font-size="20" font-weight="700" fill="#0F172A">Mannu Visuals</text>
        <text x="145" y="138" font-family="Inter, sans-serif" font-size="13" fill="#64748B">${category}</text>
        <text x="80" y="265" font-family="Plus Jakarta Sans, sans-serif" font-size="32" font-weight="700" fill="#0F172A">${cleanTitle}</text>
        <text x="80" y="305" font-family="Plus Jakarta Sans, sans-serif" font-size="18" font-weight="600" fill="#0B4DA8">${subtitle}</text>
        <rect x="80" y="330" width="88" height="5" rx="2.5" fill="#E53935"/>
        <text x="80" y="378" font-family="Inter, sans-serif" font-size="16" fill="#475569">Designed online · Print &amp; Digital Layout</text>
        ${wm}
      </svg>`;
      return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
    };

    const frontUrl = makeSvg('Front Cover / Main Layout', '#0B4DA8');
    const nextImages: DraftPortfolioImage[] = [
      {
        id: `sample-front-${Date.now()}`,
        thumbUrl: frontUrl,
        mediumUrl: frontUrl,
        publicUrl: frontUrl,
        originalPath: `portfolio-originals/sample-front-${Date.now()}.svg`,
        width: 800,
        height: 600,
        altText: `${cleanTitle} - Front layout`,
        isCover: true,
      },
    ];

    if (includeBackSide) {
      const backUrl = makeSvg('Inside / Back Programme Layout', '#E53935');
      nextImages.push({
        id: `sample-back-${Date.now() + 1}`,
        thumbUrl: backUrl,
        mediumUrl: backUrl,
        publicUrl: backUrl,
        originalPath: `portfolio-originals/sample-back-${Date.now() + 1}.svg`,
        width: 800,
        height: 600,
        altText: `${cleanTitle} - Back layout`,
        isCover: false,
      });
    }

    setPortImages(nextImages);
    if (!portTitle) setPortTitle(cleanTitle);
  };

  const handleSavePortfolioItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!portTitle.trim()) {
      showNotice('error', 'Please enter a title for the portfolio item.');
      return;
    }
    if (portImages.length === 0) {
      showNotice('error', 'Please upload at least one image or generate a sample layout.');
      return;
    }
    if (portImages.some((img) => !img.altText.trim())) {
      showNotice('error', 'Every image must have descriptive alt text.');
      return;
    }

    try {
      const payload = {
        subAction: editingPortfolioId ? 'update' : 'create',
        id: editingPortfolioId || undefined,
        title: portTitle.trim(),
        category: portCategory,
        description: portDesc.trim(),
        projectDate: portDate,
        tags: portTags
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean),
        clientLabel: portClientLabel.trim() || undefined,
        isSample: portIsSample,
        watermark: portWatermark,
        featured: portFeatured,
        visible: portVisible,
        images: portImages,
      };

      const res = await callPortfolioAdminApi(payload);
      setDashboard(res.dashboard);
      onPublicDataChanged();

      resetPortfolioForm();
      showNotice(
        'success',
        editingPortfolioId
          ? 'Updated portfolio item.'
          : 'Added portfolio item to the #work section.'
      );
    } catch (err: any) {
      showNotice('error', err.message);
    }
  };

  const handleEditPortfolioItemClick = (item: any) => {
    setEditingPortfolioId(item.id);
    setPortTitle(item.title || '');
    setPortCategory(item.categoryName || item.category || DEFAULT_PORTFOLIO_CATEGORIES[0]);
    setPortDesc(item.description || '');
    setPortDate(item.projectDate || new Date().toISOString().slice(0, 10));
    setPortTags(Array.isArray(item.tags) ? item.tags.join(', ') : '');
    setPortClientLabel(item.clientLabel || '');
    setPortIsSample(item.isSample !== undefined ? Boolean(item.isSample) : true);
    setPortWatermark(item.watermark !== undefined ? Boolean(item.watermark) : true);
    setPortFeatured(Boolean(item.featured));
    setPortVisible(item.visible !== undefined ? Boolean(item.visible) : true);
    setPortImages(
      Array.isArray(item.images) && item.images.length > 0
        ? item.images.map((img: any, idx: number) => ({
            id: img.id || `img-${idx}`,
            thumbUrl: img.thumbUrl || img.publicUrl,
            mediumUrl: img.mediumUrl || img.publicUrl,
            publicUrl: img.publicUrl || img.thumbUrl,
            originalPath: img.originalPath || `portfolio-originals/${item.id}-${idx + 1}.webp`,
            width: img.width || 800,
            height: img.height || 600,
            altText: img.altText || item.title,
            isCover: img.isCover !== undefined ? Boolean(img.isCover) : idx === 0,
          }))
        : []
    );
  };

  const handlePortfolioDropReorder = async (targetId: string) => {
    if (!draggedPortfolioId || draggedPortfolioId === targetId || !dashboard) return;
    const list = [...dashboard.portfolioItems];
    const fromIdx = list.findIndex((i: any) => i.id === draggedPortfolioId);
    const toIdx = list.findIndex((i: any) => i.id === targetId);
    if (fromIdx < 0 || toIdx < 0) return;

    const [moved] = list.splice(fromIdx, 1);
    list.splice(toIdx, 0, moved);
    setDraggedPortfolioId(null);

    try {
      const res = await callPortfolioAdminApi({
        subAction: 'reorder',
        orderedIds: list.map((i: any) => i.id),
      });
      setDashboard(res.dashboard);
      onPublicDataChanged();
      showNotice('success', 'Portfolio order updated.');
    } catch (err: any) {
      showNotice('error', err.message);
    }
  };

  const handleExportCsv = (filename: string, rows: Record<string, any>[]) => {
    if (!rows || rows.length === 0) {
      showNotice('error', 'No records available to export.');
      return;
    }
    const headers = Object.keys(rows[0]);
    const csvLines = [
      headers.join(','),
      ...rows.map((r) =>
        headers
          .map((h) => {
            const val = String(r[h] ?? '').replace(/"/g, '""');
            return `"${val}"`;
          })
          .join(',')
      ),
    ];
    const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleRunVerificationSuite = async () => {
    setRunningVerification(true);
    try {
      const res = await callAdminApi({ action: 'run-verification-suite' });
      setVerificationReport(res.report);
      setDashboard(res.dashboard);
      showNotice('success', 'All 9 system verification checks completed.');
    } catch (err: any) {
      showNotice('error', err.message);
    } finally {
      setRunningVerification(false);
    }
  };

  // ===========================================================================
  // LOGIN VIEW
  // ===========================================================================
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[var(--bg-page)] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-between items-center mb-6">
            <Logo size="md" />
            <button
              type="button"
              onClick={onBackToSite}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to public site
            </button>
          </div>

          <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 sm:p-8 shadow-sm">
            <h1 className="text-xl font-heading font-bold text-[var(--text-primary)]">
              {hasOwnerAccount ? 'Admin Sign In' : 'Create First Owner Account'}
            </h1>
            <p className="text-xs text-[var(--text-secondary)] mt-1">
              {hasOwnerAccount
                ? 'Sign in with your admin username and password. Sessions close after 30 minutes of inactivity.'
                : 'No owner account exists yet. Set up your initial OWNER username and password below.'}
            </p>

            {authError && (
              <div className="mt-4 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-start gap-2 text-xs text-red-700 dark:text-red-300">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{authError}</span>
              </div>
            )}

            <form onSubmit={handlePasswordSubmit} className="mt-5 space-y-4">
              <div>
                <label
                  htmlFor="admin-username"
                  className="block text-xs font-medium text-[var(--text-primary)] mb-1"
                >
                  Username
                </label>
                <input
                  id="admin-username"
                  type="text"
                  required
                  autoComplete="username"
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  placeholder={hasOwnerAccount ? 'Enter username' : 'e.g. mannu_owner'}
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)]"
                />
              </div>

              <div>
                <label
                  htmlFor="admin-password"
                  className="block text-xs font-medium text-[var(--text-primary)] mb-1"
                >
                  Password
                </label>
                <input
                  id="admin-password"
                  type="password"
                  required
                  autoComplete={hasOwnerAccount ? 'current-password' : 'new-password'}
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder={hasOwnerAccount ? 'Enter password' : 'Minimum 8 characters'}
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)]"
                />
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-2.5 px-4 text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors disabled:opacity-50"
              >
                {authLoading
                  ? 'Please wait...'
                  : hasOwnerAccount
                  ? 'Sign in'
                  : 'Create OWNER account & sign in'}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  const filteredOrders = (dashboard?.orders || []).filter((o: any) => {
    if (orderStatusFilter !== 'ALL' && o.status !== orderStatusFilter) return false;
    if (orderCategoryFilter !== 'ALL' && o.serviceCategory !== orderCategoryFilter) return false;
    if (orderSearch.trim()) {
      const q = orderSearch.trim().toLowerCase();
      return (
        o.orderNumber.toLowerCase().includes(q) ||
        String(o.ticketNumber || '').toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerPhone.toLowerCase().includes(q) ||
        o.serviceName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // ===========================================================================
  // AUTHENTICATED ADMIN WORKSPACE
  // ===========================================================================
  return (
    <div className="min-h-screen bg-[var(--bg-page)] text-[var(--text-primary)] flex flex-col md:flex-row">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-[var(--bg-surface)] border-b md:border-b-0 md:border-r border-[var(--border-subtle)] shrink-0 flex flex-col justify-between">
        <div>
          <div className="px-5 py-4 border-b border-[var(--border-subtle)] flex items-center justify-between">
            <Logo
              logoUrl={dashboard?.settings?.logoUrl}
              businessName={dashboard?.settings?.businessName || 'Mannu Visuals'}
              size="sm"
            />
          </div>

          <div className="px-5 py-3 bg-[var(--bg-subtle)] border-b border-[var(--border-subtle)] text-xs flex items-center justify-between">
            <span className="font-medium truncate">{currentUser.username}</span>
            <span className="font-mono-tabular text-[var(--brand-blue)] font-semibold">
              {currentUser.role}
            </span>
          </div>

          <nav className="p-3 flex md:flex-col gap-1 overflow-x-auto">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              {
                id: 'orders',
                label: `Orders (${dashboard?.orders?.length || 0})`,
                icon: ClipboardList,
              },
              {
                id: 'verify-ticket',
                label: 'Verify Ticket (/admin/verify)',
                icon: QrCode,
              },
              { id: 'invoices', label: 'Invoices & Receipts', icon: FileText },
              { id: 'customers', label: 'Customers', icon: Users },
              { id: 'portfolio', label: 'Portfolio', icon: ImageIcon },
              { id: 'services', label: 'Services', icon: Layers },
              { id: 'reports', label: 'Reports & CSV', icon: BarChart3 },
              { id: 'settings', label: 'Settings', icon: SettingsIcon },
              { id: 'users', label: 'Users & Audit', icon: ShieldCheck },
              { id: 'verification', label: 'System Tests', icon: Play },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id as AdminTab);
                    if (item.id === 'verify-ticket') {
                      window.history.pushState({}, '', '/admin/verify');
                    } else if (window.location.pathname === '/admin/verify') {
                      window.history.pushState({}, '', '/admin');
                    }
                  }}
                  className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-[var(--brand-blue)] text-white'
                      : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-subtle)]'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-[var(--border-subtle)] space-y-2">
          <button
            type="button"
            onClick={onBackToSite}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-lg hover:bg-[var(--bg-subtle)]"
          >
            <ArrowLeft className="w-4 h-4" />
            Public Website
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg"
          >
            <LogOut className="w-4 h-4" />
            Sign out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Context Header */}
        <header className="px-6 py-4 bg-[var(--bg-surface)] border-b border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-medium text-[var(--text-secondary)]">
            <span>Admin Console</span>
            <span>/</span>
            <span className="text-[var(--text-primary)] font-semibold capitalize">
              {activeTab.replace('-', ' ')}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRunVerificationSuite}
              disabled={runningVerification}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[var(--brand-blue)] hover:bg-[var(--brand-blue-hover)] rounded-lg transition-colors whitespace-nowrap"
            >
              <Play className="w-3.5 h-3.5" />
              {runningVerification ? 'Running 9 Checks...' : 'Run 9-Check Test Suite'}
            </button>
            <button
              type="button"
              onClick={() => loadDashboard()}
              disabled={loadingData}
              className="px-3 py-1.5 text-xs font-medium text-[var(--text-primary)] bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-lg hover:bg-slate-200/60 whitespace-nowrap"
            >
              {loadingData ? 'Refreshing...' : 'Refresh'}
            </button>
          </div>
        </header>

        {/* Action Notice Banner */}
        {actionNotice && (
          <div
            className={`mx-6 mt-4 p-3.5 rounded-[12px] border flex items-center justify-between gap-3 text-xs ${
              actionNotice.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
            }`}
          >
            <span className="flex items-center gap-2">
              {actionNotice.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              {actionNotice.text}
            </span>
            <button
              type="button"
              onClick={() => setActionNotice(null)}
              className="text-xs underline"
            >
              Dismiss
            </button>
          </div>
        )}

        <main className="p-6 space-y-6 overflow-y-auto">
          {/* ================================================================= */}
          {/* TAB 1: DASHBOARD */}
          {/* ================================================================= */}
          {activeTab === 'dashboard' && dashboard && (
            <div className="space-y-6">
              {/* Alert for new orders */}
              {dashboard.metrics.newOrdersCount > 0 && (
                <div className="p-4 rounded-[12px] bg-[var(--bg-surface)] border-l-4 border-l-[var(--brand-red)] border border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-3">
                  <div className="text-sm">
                    <span className="font-semibold text-[var(--text-primary)]">
                      {dashboard.metrics.newOrdersCount} new order(s) waiting for price confirmation
                    </span>
                    <span className="text-[var(--text-secondary)] ml-2 text-xs">
                      Open Orders to confirm prices and message customers on WhatsApp.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setOrderStatusFilter('Received');
                      setActiveTab('orders');
                    }}
                    className="px-3.5 py-2 text-xs font-medium text-white bg-[var(--brand-red)] rounded-lg whitespace-nowrap"
                  >
                    Review New Orders
                  </button>
                </div>
              )}

              {/* 4 KPI Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px]">
                  <p className="text-xs text-[var(--text-secondary)]">New Orders (Received)</p>
                  <p className="text-2xl font-heading font-bold font-mono-tabular mt-1">
                    {dashboard.metrics.newOrdersCount}
                  </p>
                </div>
                <div className="p-5 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px]">
                  <p className="text-xs text-[var(--text-secondary)]">Unpaid / Partial Orders</p>
                  <p className="text-2xl font-heading font-bold font-mono-tabular mt-1">
                    {dashboard.metrics.unpaidOrdersCount}
                  </p>
                </div>
                <div className="p-5 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px]">
                  <p className="text-xs text-[var(--text-secondary)]">Paid Today</p>
                  <p className="text-2xl font-heading font-bold font-mono-tabular text-[var(--brand-blue)] mt-1">
                    KES {dashboard.metrics.paidTodayKes.toLocaleString()}
                  </p>
                </div>
                <div className="p-5 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px]">
                  <p className="text-xs text-[var(--text-secondary)]">Paid This Month</p>
                  <p className="text-2xl font-heading font-bold font-mono-tabular mt-1">
                    KES {dashboard.metrics.paidMonthKes.toLocaleString()}
                  </p>
                </div>
              </div>

              {/* 7-Day Activity Chart & Orders by Service Category */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 p-6 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px]">
                  <h2 className="text-sm font-heading font-semibold text-[var(--text-primary)]">
                    Last 7 Days Collections (KES) & Orders
                  </h2>
                  <div className="mt-5 grid grid-cols-7 gap-2 items-end h-44 pt-4 border-b border-[var(--border-subtle)]">
                    {dashboard.metrics.sevenDayChart.map((d: any) => {
                      const maxKes = Math.max(
                        1000,
                        ...dashboard.metrics.sevenDayChart.map((x: any) => x.paidKes)
                      );
                      const heightPct = Math.max(6, Math.round((d.paidKes / maxKes) * 100));
                      return (
                        <div key={d.date} className="flex flex-col items-center gap-1.5 h-full justify-end">
                          <span className="text-[10px] font-mono-tabular text-[var(--text-muted)]">
                            {d.paidKes > 0 ? `${Math.round(d.paidKes / 1000)}k` : d.ordersCount}
                          </span>
                          <div
                            style={{ height: `${heightPct}%` }}
                            className="w-full max-w-[32px] bg-[var(--brand-blue)] rounded-t-md transition-all"
                            title={`${d.label}: ${d.ordersCount} orders, KES ${d.paidKes.toLocaleString()}`}
                          />
                          <span className="text-[11px] text-[var(--text-secondary)] pb-2 truncate">
                            {d.label.split(' ')[0]}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="p-6 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] space-y-4">
                  <h2 className="text-sm font-heading font-semibold text-[var(--text-primary)]">
                    Orders by Service Group
                  </h2>
                  <div className="space-y-3 text-xs">
                    <div className="flex justify-between py-2 border-b border-[var(--border-subtle)]">
                      <span className="text-[var(--text-secondary)]">Government services</span>
                      <span className="font-mono-tabular font-semibold">
                        {dashboard.metrics.byCategory.government}
                      </span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-[var(--border-subtle)]">
                      <span className="text-[var(--text-secondary)]">Graphic design</span>
                      <span className="font-mono-tabular font-semibold">
                        {dashboard.metrics.byCategory.graphic_design}
                      </span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-[var(--border-subtle)]">
                      <span className="text-[var(--text-secondary)]">Other online services</span>
                      <span className="font-mono-tabular font-semibold">
                        {dashboard.metrics.byCategory.other}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Live Activity */}
              <div className="p-6 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px]">
                <h2 className="text-sm font-heading font-semibold text-[var(--text-primary)] mb-4">
                  Live Activity Log
                </h2>
                {dashboard.auditLog.length === 0 ? (
                  <p className="text-xs text-[var(--text-secondary)]">No activity recorded yet.</p>
                ) : (
                  <div className="divide-y divide-[var(--border-subtle)] text-xs">
                    {dashboard.auditLog.slice(0, 8).map((entry: any) => (
                      <div key={entry.id} className="py-2.5 flex flex-wrap justify-between gap-2">
                        <div>
                          <span className="font-mono-tabular font-semibold text-[var(--brand-blue)]">
                            {entry.action}
                          </span>
                          <span className="mx-2 text-[var(--text-muted)]">·</span>
                          <span className="text-[var(--text-primary)]">{entry.details}</span>
                        </div>
                        <span className="font-mono-tabular text-[var(--text-muted)]">
                          {new Date(entry.createdAt).toLocaleTimeString('en-KE', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 2: ORDERS */}
          {/* ================================================================= */}
          {activeTab === 'orders' && dashboard && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Orders Table Column */}
              <div className="lg:col-span-7 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="w-4 h-4 text-[var(--text-muted)] absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search MV- number, customer, phone..."
                      value={orderSearch}
                      onChange={(e) => setOrderSearch(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <select
                    aria-label="Filter by status"
                    value={orderStatusFilter}
                    onChange={(e) => setOrderStatusFilter(e.target.value)}
                    className="px-3 py-2 text-xs rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                  >
                    <option value="ALL">All statuses</option>
                    {ORDER_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                  <select
                    aria-label="Filter by category"
                    value={orderCategoryFilter}
                    onChange={(e) => setOrderCategoryFilter(e.target.value)}
                    className="px-3 py-2 text-xs rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                  >
                    <option value="ALL">All categories</option>
                    <option value="government">Government services</option>
                    <option value="graphic_design">Graphic design</option>
                    <option value="other">Other services</option>
                  </select>
                </div>

                {filteredOrders.length === 0 ? (
                  <div className="py-12 text-center text-xs text-[var(--text-secondary)]">
                    No matching orders found.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-[var(--border-subtle)] text-[var(--text-secondary)]">
                          <th className="py-2.5 px-2 font-medium">Order / Ticket</th>
                          <th className="py-2.5 px-2 font-medium">Customer</th>
                          <th className="py-2.5 px-2 font-medium">Service</th>
                          <th className="py-2.5 px-2 font-medium">Status / Ticket</th>
                          <th className="py-2.5 px-2 font-medium text-right">Price / Paid</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[var(--border-subtle)]">
                        {filteredOrders.map((o: any) => {
                          const isSelected = o.id === selectedOrderId;
                          return (
                            <tr
                              key={o.id}
                              onClick={() => setSelectedOrderId(o.id)}
                              className={`cursor-pointer transition-colors ${
                                isSelected
                                  ? 'bg-[var(--bg-subtle)]'
                                  : 'hover:bg-[var(--bg-subtle)]/60'
                              }`}
                            >
                              <td className="py-3 px-2 font-mono-tabular">
                                <div className="font-semibold text-[var(--brand-blue)]">
                                  {o.orderNumber}
                                </div>
                                <div className="text-[11px] text-[var(--text-muted)]">
                                  {o.ticketNumber}
                                </div>
                              </td>
                              <td className="py-3 px-2">
                                <div className="font-medium text-[var(--text-primary)]">
                                  {o.customerName}
                                </div>
                                <div className="font-mono-tabular text-[var(--text-muted)]">
                                  {o.customerPhone}
                                </div>
                              </td>
                              <td className="py-3 px-2 max-w-[160px] truncate">{o.serviceName}</td>
                              <td className="py-3 px-2">
                                <div>
                                  <span className="text-[var(--text-primary)]">{o.status}</span>
                                  <span className="mx-1 text-[var(--text-muted)]">·</span>
                                  <span className="font-mono-tabular text-[var(--text-secondary)]">
                                    {o.paymentStatus}
                                  </span>
                                </div>
                                <div className="font-mono-tabular text-[10px] text-[var(--brand-blue)] mt-0.5">
                                  {o.ticketStatus || 'PENDING_PAYMENT'}
                                </div>
                              </td>
                              <td className="py-3 px-2 text-right font-mono-tabular">
                                <div>KES {o.priceKes.toLocaleString()}</div>
                                <div className="text-[var(--text-muted)]">
                                  Paid: {o.paidKes.toLocaleString()}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Selected Order Detail Drawer */}
              <div className="lg:col-span-5 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5">
                {!selectedOrder ? (
                  <div className="py-16 text-center text-xs text-[var(--text-secondary)]">
                    Select an order from the list to view details, set the price in KES, send an M-Pesa STK push, or attach finished files.
                  </div>
                ) : (
                  <div className="space-y-5 text-xs">
                    <div className="flex items-start justify-between border-b border-[var(--border-subtle)] pb-4">
                      <div>
                        <span className="text-base font-heading font-bold font-mono-tabular text-[var(--brand-blue)]">
                          {selectedOrder.orderNumber}
                        </span>
                        <h3 className="text-sm font-semibold text-[var(--text-primary)] mt-0.5">
                          {selectedOrder.serviceName}
                        </h3>
                        <p className="text-[var(--text-secondary)] mt-0.5">
                          {selectedOrder.customerName} · {selectedOrder.customerPhone}
                        </p>
                      </div>

                      <a
                        href={`https://wa.me/${selectedOrder.customerPhone}?text=${encodeURIComponent(
                          `Hello ${selectedOrder.customerName}, regarding your Mannu Visuals order ${selectedOrder.orderNumber} (${selectedOrder.serviceName}). ${
                            selectedOrder.priceKes > 0
                              ? `The confirmed price is KES ${selectedOrder.priceKes.toLocaleString()}. You can track and pay via M-Pesa at: ${window.location.origin}/?order=${selectedOrder.orderNumber}`
                              : 'We are reviewing your order details.'
                          }`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg whitespace-nowrap"
                      >
                        WhatsApp Customer
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>

                    {/* Adaptive Order Fields */}
                    <div className="space-y-1.5 bg-[var(--bg-page)] p-3.5 rounded-lg border border-[var(--border-subtle)]">
                      {selectedOrder.portalName && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Portal:</span>{' '}
                          <span className="font-medium">{selectedOrder.portalName}</span>
                        </p>
                      )}
                      {selectedOrder.helpNeeded && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Help needed:</span>{' '}
                          <span>{selectedOrder.helpNeeded}</span>
                        </p>
                      )}
                      {selectedOrder.designType && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Design type:</span>{' '}
                          <span>{selectedOrder.designType}</span>
                        </p>
                      )}
                      {selectedOrder.exactText && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Text to appear:</span>{' '}
                          <span>{selectedOrder.exactText}</span>
                        </p>
                      )}
                      {selectedOrder.eventDetails && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Event date/venue:</span>{' '}
                          <span>{selectedOrder.eventDetails}</span>
                        </p>
                      )}
                      {selectedOrder.colourPreferences && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Colours:</span>{' '}
                          <span>{selectedOrder.colourPreferences}</span>
                        </p>
                      )}
                      {selectedOrder.sizeOrFormat && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Format:</span>{' '}
                          <span>{selectedOrder.sizeOrFormat}</span>
                        </p>
                      )}
                      {selectedOrder.documentType && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Document type:</span>{' '}
                          <span>{selectedOrder.documentType}</span>
                        </p>
                      )}
                      {selectedOrder.pageCount && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Pages:</span>{' '}
                          <span>{selectedOrder.pageCount}</span>
                        </p>
                      )}
                      {selectedOrder.documentLanguage && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Language:</span>{' '}
                          <span>{selectedOrder.documentLanguage}</span>
                        </p>
                      )}
                      {selectedOrder.details && (
                        <p>
                          <span className="text-[var(--text-secondary)]">Notes:</span>{' '}
                          <span>{selectedOrder.details}</span>
                        </p>
                      )}
                      <p>
                        <span className="text-[var(--text-secondary)]">Delivery method:</span>{' '}
                        <span>{selectedOrder.deliveryMethod}</span>
                        {selectedOrder.deadline && ` · Deadline: ${selectedOrder.deadline}`}
                      </p>
                    </div>

                    {/* Customer Attached Files */}
                    {selectedOrder.files && selectedOrder.files.length > 0 && (
                      <div className="space-y-1.5">
                        <p className="font-semibold text-[var(--text-primary)]">
                          Attached Files ({selectedOrder.files.length})
                        </p>
                        <div className="space-y-1">
                          {selectedOrder.files.map((f: any) => (
                            <div
                              key={f.id}
                              className="flex items-center justify-between p-2 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                            >
                              <span className="truncate max-w-[200px]">
                                {f.fileName} ({f.fileKind === 'deliverable' ? 'Finished work' : 'Customer upload'})
                              </span>
                              <a
                                href={f.dataUrl}
                                download={f.fileName}
                                className="text-[var(--brand-blue)] hover:underline font-medium"
                              >
                                Download
                              </a>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Set Price, Order Status & Ticket Status Form */}
                    <form onSubmit={handleSaveOrderChanges} className="space-y-3 pt-2 border-t border-[var(--border-subtle)]">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block font-medium text-[var(--text-primary)] mb-1">
                            Confirmed Price (KES)
                          </label>
                          <input
                            type="number"
                            min={0}
                            step={1}
                            value={editPriceKes}
                            onChange={(e) => setEditPriceKes(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                          />
                        </div>
                        <div>
                          <label className="block font-medium text-[var(--text-primary)] mb-1">
                            Order Status
                          </label>
                          <select
                            value={editOrderStatus}
                            onChange={(e) => setEditOrderStatus(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                          >
                            {ORDER_STATUSES.map((st) => (
                              <option key={st} value={st}>
                                {st}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block font-medium text-[var(--text-primary)] mb-1">
                            Ticket Status
                          </label>
                          <select
                            value={editTicketStatus}
                            onChange={(e) => setEditTicketStatus(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                          >
                            {TICKET_STATUS_OPTIONS.map((tst) => (
                              <option key={tst} value={tst}>
                                {tst}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2 px-4 font-medium text-white bg-[var(--brand-blue)] hover:bg-[var(--brand-blue-hover)] rounded-lg transition-colors"
                      >
                        Save Price, Order &amp; Ticket Status
                      </button>
                    </form>

                    {/* Admin Ticket Card (View, Print/PDF, Resend to WhatsApp/Email) */}
                    <div className="pt-3 border-t border-[var(--border-subtle)] space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="font-semibold text-[var(--text-primary)]">
                          Service Ticket ({selectedOrder.ticketNumber})
                        </p>
                        <button
                          type="button"
                          onClick={() => {
                            setVerifyTicketInput(selectedOrder.ticketNumber);
                            setVerifiedOrderResult(selectedOrder);
                            setActiveTab('verify-ticket');
                            window.history.pushState(
                              {},
                              '',
                              `/admin/verify?ticket=${encodeURIComponent(
                                selectedOrder.ticketNumber
                              )}`
                            );
                          }}
                          className="text-[11px] font-medium text-[var(--brand-blue)] hover:underline"
                        >
                          Open in /admin/verify →
                        </button>
                      </div>
                      <TicketCard
                        ticket={{
                          ticketNumber:
                            selectedOrder.ticketNumber ||
                            `TKT-${new Date().getFullYear()}-8942`,
                          orderNumber: selectedOrder.orderNumber,
                          ticketStatus: selectedOrder.ticketStatus || 'PENDING_PAYMENT',
                          orderStatus: selectedOrder.status,
                          paymentStatus: selectedOrder.paymentStatus,
                          customerName: selectedOrder.customerName,
                          customerPhone: selectedOrder.customerPhone,
                          customerEmail: selectedOrder.customerEmail,
                          serviceCategory: selectedOrder.serviceCategory,
                          serviceName: selectedOrder.serviceName,
                          createdAt: selectedOrder.createdAt,
                          deadline: selectedOrder.deadline,
                          deliveryMethod: selectedOrder.deliveryMethod,
                          priceKes: selectedOrder.priceKes,
                          paidKes: selectedOrder.paidKes,
                          mpesaReceiptCode: selectedOrder.mpesaReceiptCode,
                          receiptNumber: selectedOrder.receiptNumber,
                          qrCodeData: selectedOrder.qrCodeData,
                        }}
                        settings={dashboard.settings}
                        isAdminView={true}
                      />
                    </div>

                    {/* Upload Finished Work for Customer */}
                    <div className="pt-3 border-t border-[var(--border-subtle)]">
                      <label className="block font-medium text-[var(--text-primary)] mb-1.5">
                        Upload Finished Work for Customer Download
                      </label>
                      <label className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg border border-dashed border-[var(--border-subtle)] bg-[var(--bg-page)] cursor-pointer hover:border-[var(--brand-blue)]">
                        <Upload className="w-4 h-4 text-[var(--brand-blue)]" />
                        <span>
                          {selectedOrder.deliverableFileName
                            ? `Replace "${selectedOrder.deliverableFileName}"`
                            : 'Choose finished file (PDF or image)'}
                        </span>
                        <input
                          type="file"
                          accept="image/*,application/pdf"
                          onChange={handleUploadDeliverable}
                          className="hidden"
                        />
                      </label>
                    </div>

                    {/* M-Pesa STK Push & Callback Test Controls */}
                    <div className="pt-3 border-t border-[var(--border-subtle)] space-y-2.5">
                      <p className="font-semibold text-[var(--text-primary)]">
                        M-Pesa STK Push & Callback Controls
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="tel"
                          placeholder="M-Pesa phone"
                          value={stkPhoneInput}
                          onChange={(e) => setStkPhoneInput(e.target.value)}
                          className="px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                        />
                        <input
                          type="number"
                          placeholder="Amount KES"
                          value={stkAmountInput}
                          onChange={(e) => setStkAmountInput(e.target.value)}
                          className="px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={handleSendOrderStkPush}
                        className="w-full py-2 px-3 font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg flex items-center justify-center gap-1.5"
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        Send M-Pesa STK Push to Customer
                      </button>

                      <div className="grid grid-cols-2 gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => handleSimulateCallback('full')}
                          className="px-2.5 py-1.5 rounded bg-[var(--bg-subtle)] hover:bg-slate-200 dark:hover:bg-slate-800 text-[var(--text-primary)] font-medium"
                        >
                          Simulate Full Payment
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSimulateCallback('partial')}
                          className="px-2.5 py-1.5 rounded bg-[var(--bg-subtle)] hover:bg-slate-200 dark:hover:bg-slate-800 text-[var(--text-primary)] font-medium"
                        >
                          Simulate Partial Payment
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSimulateCallback('duplicate')}
                          className="px-2.5 py-1.5 rounded bg-[var(--bg-subtle)] hover:bg-slate-200 dark:hover:bg-slate-800 text-[var(--text-primary)] font-medium"
                        >
                          Test Duplicate Callback
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSimulateCallback('failed')}
                          className="px-2.5 py-1.5 rounded bg-[var(--bg-subtle)] hover:bg-slate-200 dark:hover:bg-slate-800 text-[var(--text-primary)] font-medium"
                        >
                          Test Failed Payment
                        </button>
                      </div>
                    </div>

                    {/* Record Manual / Cash Payment */}
                    <form
                      onSubmit={handleRecordManualPayment}
                      className="pt-3 border-t border-[var(--border-subtle)] space-y-2"
                    >
                      <p className="font-semibold text-[var(--text-primary)]">
                        Record Manual / Alternative Payment
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        <input
                          type="number"
                          min={1}
                          placeholder="KES"
                          value={manualPayAmount}
                          onChange={(e) => setManualPayAmount(e.target.value)}
                          className="px-2.5 py-1.5 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                        />
                        <select
                          value={manualPayMethod}
                          onChange={(e) => setManualPayMethod(e.target.value)}
                          className="px-2.5 py-1.5 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                        >
                          <option value="MPESA_MANUAL">M-Pesa Till/Paybill</option>
                          <option value="CASH">Cash</option>
                          <option value="OTHER">Other</option>
                        </select>
                        <input
                          type="text"
                          placeholder="Ref code (optional)"
                          value={manualPayRef}
                          onChange={(e) => setManualPayRef(e.target.value)}
                          className="px-2.5 py-1.5 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full py-1.5 px-3 rounded bg-[var(--bg-subtle)] border border-[var(--border-subtle)] font-medium hover:bg-slate-200/70"
                      >
                        Record Payment & Issue Receipt
                      </button>
                    </form>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 2B: TICKET VERIFICATION & FULFILLMENT (/admin/verify)         */}
          {/* ================================================================= */}
          {activeTab === 'verify-ticket' && dashboard && (
            <div className="space-y-6">
              <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 space-y-5">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <h2 className="text-base font-heading font-bold text-[var(--text-primary)]">
                      Scan or Verify Ticket (/admin/verify)
                    </h2>
                    <p className="text-xs text-[var(--text-secondary)] mt-1">
                      Enter or scan a customer Ticket Number (e.g. TKT-2026-8942) or Order Number (e.g. MV-4821) to instantly verify order details, mark status as READY or FULFILLED, or resend the ticket via WhatsApp/Email.
                    </p>
                  </div>
                </div>

                <form
                  onSubmit={(e) => handleVerifyTicketLookup(e)}
                  className="flex flex-col sm:flex-row gap-3"
                >
                  <div className="relative flex-1">
                    <QrCode className="w-4 h-4 text-[var(--text-muted)] absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={verifyTicketInput}
                      onChange={(e) => setVerifyTicketInput(e.target.value.toUpperCase())}
                      placeholder="Scan or enter Ticket Number (e.g. TKT-2026-8942) or Order Number (MV-4821)"
                      className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={verifyTicketLoading}
                    className="px-5 py-2.5 text-xs sm:text-sm font-medium text-white bg-[var(--brand-blue)] hover:bg-[var(--brand-blue-hover)] rounded-lg transition-colors whitespace-nowrap"
                  >
                    {verifyTicketLoading ? 'Verifying...' : 'Look Up Ticket'}
                  </button>
                </form>

                {/* Quick select from recent tickets */}
                {dashboard.orders && dashboard.orders.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                    <span className="text-[var(--text-secondary)]">Recent tickets:</span>
                    {dashboard.orders.slice(0, 6).map((ord: any) => (
                      <button
                        key={ord.id}
                        type="button"
                        onClick={() => {
                          setVerifyTicketInput(ord.ticketNumber);
                          handleVerifyTicketLookup(undefined, ord.ticketNumber);
                        }}
                        className="px-2.5 py-1 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular hover:border-[var(--brand-blue)] text-[var(--text-primary)]"
                      >
                        {ord.ticketNumber} ({ord.orderNumber})
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {verifiedOrderResult && (
                <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 space-y-6">
                  {/* Instant Fulfillment Action Bar */}
                  <div className="p-4 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <span className="text-xs text-[var(--text-secondary)] block">
                        Instant Staff Fulfillment Actions for {verifiedOrderResult.ticketNumber}
                      </span>
                      <p className="text-sm font-semibold text-[var(--text-primary)] mt-0.5">
                        Current Ticket Status:{' '}
                        <span className="font-mono-tabular text-[var(--brand-blue)]">
                          {verifiedOrderResult.ticketStatus}
                        </span>{' '}
                        · Order Status:{' '}
                        <span className="font-mono-tabular">{verifiedOrderResult.status}</span>
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          handleQuickMarkTicketStatus(verifiedOrderResult, 'READY')
                        }
                        className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#0B4DA8] hover:bg-blue-800 transition-colors"
                      >
                        Mark as READY
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleQuickMarkTicketStatus(verifiedOrderResult, 'FULFILLED')
                        }
                        className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"
                      >
                        Mark as FULFILLED (Completed)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleQuickMarkTicketStatus(verifiedOrderResult, 'PROCESSING')
                        }
                        className="px-3 py-2 rounded-lg text-xs font-medium bg-[var(--bg-surface)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)]"
                      >
                        Mark PROCESSING
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleQuickMarkTicketStatus(verifiedOrderResult, 'CONFIRMED')
                        }
                        className="px-3 py-2 rounded-lg text-xs font-medium bg-[var(--bg-surface)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)]"
                      >
                        Mark CONFIRMED
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleQuickMarkTicketStatus(verifiedOrderResult, 'CANCELLED')
                        }
                        className="px-3 py-2 rounded-lg text-xs font-medium text-red-600 bg-[var(--bg-surface)] border border-red-200 hover:bg-red-50"
                      >
                        Cancel Ticket
                      </button>
                    </div>
                  </div>

                  {/* Full Printable & Resendable Ticket Card */}
                  <TicketCard
                    ticket={{
                      ticketNumber: verifiedOrderResult.ticketNumber,
                      orderNumber: verifiedOrderResult.orderNumber,
                      ticketStatus: verifiedOrderResult.ticketStatus,
                      orderStatus: verifiedOrderResult.status,
                      paymentStatus: verifiedOrderResult.paymentStatus,
                      customerName: verifiedOrderResult.customerName,
                      customerPhone: verifiedOrderResult.customerPhone,
                      customerEmail: verifiedOrderResult.customerEmail,
                      serviceCategory: verifiedOrderResult.serviceCategory,
                      serviceName: verifiedOrderResult.serviceName,
                      createdAt: verifiedOrderResult.createdAt,
                      deadline: verifiedOrderResult.deadline,
                      deliveryMethod: verifiedOrderResult.deliveryMethod,
                      priceKes: verifiedOrderResult.priceKes,
                      paidKes: verifiedOrderResult.paidKes,
                      mpesaReceiptCode: verifiedOrderResult.mpesaReceiptCode,
                      receiptNumber: verifiedOrderResult.receiptNumber,
                      verifyUrl: verifiedOrderResult.verifyUrl,
                      qrCodeData: verifiedOrderResult.qrCodeData,
                    }}
                    settings={dashboard.settings}
                    isAdminView={true}
                  />
                </div>
              )}
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 3: INVOICES & RECEIPTS */}
          {/* ================================================================= */}
          {activeTab === 'invoices' && dashboard && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Create Invoice Form */}
              <div className="lg:col-span-5 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5 space-y-4">
                <h2 className="text-sm font-heading font-semibold">Create Invoice (INV- Sequence)</h2>
                <form onSubmit={handleCreateInvoice} className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-medium mb-1">Customer Name</label>
                      <input
                        type="text"
                        required
                        value={invCustomerName}
                        onChange={(e) => setInvCustomerName(e.target.value)}
                        placeholder="e.g. John Kamau"
                        className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                      />
                    </div>
                    <div>
                      <label className="block font-medium mb-1">Phone (Kenyan)</label>
                      <input
                        type="tel"
                        required
                        value={invCustomerPhone}
                        onChange={(e) => setInvCustomerPhone(e.target.value)}
                        placeholder="0712 345 678"
                        className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Line Items</span>
                      <button
                        type="button"
                        onClick={() =>
                          setInvItems([
                            ...invItems,
                            { description: '', quantity: 1, unitPriceKes: 500 },
                          ])
                        }
                        className="text-[var(--brand-blue)] font-medium inline-flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" /> Add item
                      </button>
                    </div>
                    {invItems.map((item, idx) => (
                      <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                        <input
                          type="text"
                          required
                          placeholder="Item description"
                          value={item.description}
                          onChange={(e) => {
                            const copy = [...invItems];
                            copy[idx].description = e.target.value;
                            setInvItems(copy);
                          }}
                          className="col-span-6 px-2.5 py-1.5 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                        />
                        <input
                          type="number"
                          min={1}
                          value={item.quantity}
                          onChange={(e) => {
                            const copy = [...invItems];
                            copy[idx].quantity = Number(e.target.value || 1);
                            setInvItems(copy);
                          }}
                          className="col-span-2 px-2 py-1.5 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                        />
                        <input
                          type="number"
                          min={0}
                          value={item.unitPriceKes}
                          onChange={(e) => {
                            const copy = [...invItems];
                            copy[idx].unitPriceKes = Number(e.target.value || 0);
                            setInvItems(copy);
                          }}
                          className="col-span-3 px-2 py-1.5 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            invItems.length > 1 &&
                            setInvItems(invItems.filter((_, i) => i !== idx))
                          }
                          aria-label="Remove line item"
                          className="col-span-1 text-slate-400 hover:text-red-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-medium mb-1">Discount (KES)</label>
                      <input
                        type="number"
                        min={0}
                        value={invDiscountKes}
                        onChange={(e) => setInvDiscountKes(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                      />
                    </div>
                    <div>
                      <label className="block font-medium mb-1">Due Date</label>
                      <input
                        type="date"
                        value={invDueDate}
                        onChange={(e) => setInvDueDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg"
                  >
                    Create Invoice
                  </button>
                </form>
              </div>

              {/* Invoices & Receipts Lists */}
              <div className="lg:col-span-7 space-y-6">
                <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5">
                  <h2 className="text-sm font-heading font-semibold mb-3">
                    Invoices ({dashboard.invoices.length})
                  </h2>
                  {dashboard.invoices.length === 0 ? (
                    <p className="text-xs text-[var(--text-secondary)]">No invoices created yet.</p>
                  ) : (
                    <div className="divide-y divide-[var(--border-subtle)] text-xs">
                      {dashboard.invoices.map((inv: any) => (
                        <div
                          key={inv.id}
                          className="py-3 flex flex-wrap items-center justify-between gap-2"
                        >
                          <div>
                            <span className="font-mono-tabular font-semibold text-[var(--brand-blue)]">
                              {inv.invoiceNumber}
                            </span>
                            <span className="mx-2 text-[var(--text-muted)]">·</span>
                            <span className="font-medium">{inv.customerName}</span>
                            <span className="mx-2 text-[var(--text-muted)]">·</span>
                            <span className="font-mono-tabular">
                              KES {inv.totalKes.toLocaleString()} ({inv.status})
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                const url = `${window.location.origin}/?invoice=${inv.publicToken}`;
                                navigator.clipboard?.writeText(url);
                                showNotice('success', `Copied private link for ${inv.invoiceNumber}.`);
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[var(--bg-subtle)] text-[var(--text-primary)]"
                            >
                              <Copy className="w-3 h-3" /> Copy Pay Link
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setDocModal({
                                  type: 'invoice',
                                  invoice: {
                                    ...inv,
                                    customerPhoneMasked: `${inv.customerPhone.slice(0, 4)}****${inv.customerPhone.slice(-4)}`,
                                    balanceKes: Math.max(0, inv.totalKes - inv.paidKes),
                                  },
                                })
                              }
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[var(--brand-blue)] text-white"
                            >
                              <Printer className="w-3 h-3" /> View / Print
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5">
                  <h2 className="text-sm font-heading font-semibold mb-3">
                    Receipts ({dashboard.receipts.length})
                  </h2>
                  {dashboard.receipts.length === 0 ? (
                    <p className="text-xs text-[var(--text-secondary)]">
                      Receipts (RC-0001 sequence) are generated automatically when payments are confirmed.
                    </p>
                  ) : (
                    <div className="divide-y divide-[var(--border-subtle)] text-xs">
                      {dashboard.receipts.map((rec: any) => (
                        <div
                          key={rec.id}
                          className="py-3 flex flex-wrap items-center justify-between gap-2"
                        >
                          <div>
                            <span className="font-mono-tabular font-semibold text-emerald-700 dark:text-emerald-400">
                              {rec.receiptNumber}
                            </span>
                            <span className="mx-2 text-[var(--text-muted)]">·</span>
                            <span>{rec.orderNumber}</span>
                            <span className="mx-2 text-[var(--text-muted)]">·</span>
                            <span className="font-mono-tabular font-medium">
                              KES {rec.amountKes.toLocaleString()}
                            </span>
                            {rec.mpesaReceiptCode && (
                              <span className="ml-2 font-mono-tabular text-[var(--text-secondary)]">
                                ({rec.mpesaReceiptCode})
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              setDocModal({
                                type: 'receipt',
                                receipt: {
                                  ...rec,
                                  customerPhoneMasked: `${rec.customerPhone.slice(0, 4)}****${rec.customerPhone.slice(-4)}`,
                                },
                              })
                            }
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[var(--brand-blue)] text-white"
                          >
                            <Printer className="w-3 h-3" /> A4 / 80mm Print
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 4: CUSTOMERS */}
          {/* ================================================================= */}
          {activeTab === 'customers' && dashboard && (
            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5">
              <h2 className="text-sm font-heading font-semibold mb-4">
                Customers & Account Balances ({dashboard.customers.length})
              </h2>
              {dashboard.customers.length === 0 ? (
                <p className="text-xs text-[var(--text-secondary)]">
                  Customers are added automatically when they submit an order or when an invoice is created.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-[var(--border-subtle)] text-[var(--text-secondary)]">
                        <th className="py-2.5 px-3 font-medium">Name</th>
                        <th className="py-2.5 px-3 font-medium">Phone</th>
                        <th className="py-2.5 px-3 font-medium text-right">Orders</th>
                        <th className="py-2.5 px-3 font-medium text-right">Total Billed (KES)</th>
                        <th className="py-2.5 px-3 font-medium text-right">Total Paid (KES)</th>
                        <th className="py-2.5 px-3 font-medium text-right">Balance (KES)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border-subtle)]">
                      {dashboard.customers.map((c: any) => {
                        const bal = Math.max(0, c.totalBilledKes - c.totalPaidKes);
                        return (
                          <tr key={c.id}>
                            <td className="py-3 px-3 font-medium">{c.name}</td>
                            <td className="py-3 px-3 font-mono-tabular">{c.phone}</td>
                            <td className="py-3 px-3 text-right font-mono-tabular">
                              {c.totalOrders}
                            </td>
                            <td className="py-3 px-3 text-right font-mono-tabular">
                              {c.totalBilledKes.toLocaleString()}
                            </td>
                            <td className="py-3 px-3 text-right font-mono-tabular">
                              {c.totalPaidKes.toLocaleString()}
                            </td>
                            <td className="py-3 px-3 text-right font-mono-tabular font-semibold">
                              {bal.toLocaleString()}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 5: PORTFOLIO MANAGER */}
          {/* ================================================================= */}
          {activeTab === 'portfolio' && dashboard && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Add / Edit Portfolio Item + Bulk Upload + Category Creator */}
              <div className="lg:col-span-5 space-y-5">
                <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="text-sm font-heading font-semibold">
                      {editingPortfolioId ? 'Edit Portfolio Work' : 'Add Work to #work Section'}
                    </h2>
                    {editingPortfolioId && (
                      <button
                        type="button"
                        onClick={resetPortfolioForm}
                        className="text-xs text-[var(--brand-blue)] hover:underline"
                      >
                        Cancel edit
                      </button>
                    )}
                  </div>

                  <form onSubmit={handleSavePortfolioItem} className="space-y-3.5 text-xs">
                    <div>
                      <label className="block font-medium mb-1">Project Title</label>
                      <input
                        type="text"
                        required
                        value={portTitle}
                        onChange={(e) => setPortTitle(e.target.value)}
                        placeholder="e.g. Floral Gold Wedding Invitation Card"
                        className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-medium mb-1">Category</label>
                        <select
                          value={portCategory}
                          onChange={(e) => setPortCategory(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                        >
                          {(dashboard.portfolioCategories?.length > 0
                            ? dashboard.portfolioCategories.map((c: any) => c.name)
                            : DEFAULT_PORTFOLIO_CATEGORIES
                          ).map((catName: string) => (
                            <option key={catName} value={catName}>
                              {catName}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block font-medium mb-1">Project Date</label>
                        <input
                          type="date"
                          value={portDate}
                          onChange={(e) => setPortDate(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-medium mb-1">Short Description</label>
                      <textarea
                        rows={2}
                        value={portDesc}
                        onChange={(e) => setPortDesc(e.target.value)}
                        placeholder="e.g. Two-sided A5 wedding card with programme and RSVP details"
                        className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-medium mb-1">Tags (comma-separated)</label>
                        <input
                          type="text"
                          value={portTags}
                          onChange={(e) => setPortTags(e.target.value)}
                          placeholder="wedding, A5, print"
                          className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                        />
                      </div>
                      <div>
                        <label className="block font-medium mb-1">Client Label (Optional)</label>
                        <input
                          type="text"
                          value={portClientLabel}
                          onChange={(e) => setPortClientLabel(e.target.value)}
                          placeholder="e.g. Private Client"
                          className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                        />
                      </div>
                    </div>

                    {/* Privacy, Watermark, Featured & Visibility Switches */}
                    <div className="p-3 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <label className="flex items-start gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={portIsSample}
                          onChange={(e) => setPortIsSample(e.target.checked)}
                          className="mt-0.5 rounded"
                        />
                        <span>
                          <span className="font-medium block">Mark as Sample</span>
                          <span className="text-[11px] text-[var(--text-secondary)]">
                            Shows client privacy note
                          </span>
                        </span>
                      </label>

                      <label className="flex items-start gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={portWatermark}
                          onChange={(e) => setPortWatermark(e.target.checked)}
                          className="mt-0.5 rounded"
                        />
                        <span>
                          <span className="font-medium block">Mannu Visuals Watermark</span>
                          <span className="text-[11px] text-[var(--text-secondary)]">
                            Originals stay private
                          </span>
                        </span>
                      </label>

                      <label className="flex items-start gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={portFeatured}
                          onChange={(e) => setPortFeatured(e.target.checked)}
                          className="mt-0.5 rounded"
                        />
                        <span>
                          <span className="font-medium block">Featured Work</span>
                          <span className="text-[11px] text-[var(--text-secondary)]">
                            Shown first in "All" view
                          </span>
                        </span>
                      </label>

                      <label className="flex items-start gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={portVisible}
                          onChange={(e) => setPortVisible(e.target.checked)}
                          className="mt-0.5 rounded"
                        />
                        <span>
                          <span className="font-medium block">Published on Site</span>
                          <span className="text-[11px] text-[var(--text-secondary)]">
                            Uncheck to hide draft
                          </span>
                        </span>
                      </label>
                    </div>

                    {/* Multi-Image Upload (Front/Back or Before/After) */}
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="font-medium">
                          Project Images ({portImages.length})
                        </label>
                        <span className="text-[11px] text-[var(--text-secondary)]">
                          Upload 2+ images for Front/Back strip & Before/After slider
                        </span>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <label className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg border border-dashed border-[var(--border-subtle)] bg-[var(--bg-page)] hover:border-[var(--brand-blue)] cursor-pointer font-medium">
                          <Upload className="w-3.5 h-3.5 text-[var(--brand-blue)]" />
                          <span>
                            {portUploading ? 'Processing WebP...' : 'Upload 1 or More Images'}
                          </span>
                          <input
                            type="file"
                            multiple
                            accept="image/jpeg,image/png,image/webp,image/svg+xml"
                            onChange={handlePortfolioImageUpload}
                            disabled={portUploading}
                            className="hidden"
                          />
                        </label>

                        <button
                          type="button"
                          onClick={() =>
                            handleGenerateSampleSvgImage(portCategory, portTitle, true)
                          }
                          className="px-3 py-2 rounded-lg bg-[var(--bg-subtle)] border border-[var(--border-subtle)] font-medium hover:border-[var(--brand-blue)]"
                        >
                          Generate Front & Back Sample
                        </button>
                      </div>

                      {portImages.length > 0 && (
                        <div className="space-y-2 pt-1 max-h-60 overflow-y-auto">
                          {portImages.map((img, idx) => (
                            <div
                              key={img.id}
                              className="p-2.5 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] flex items-start gap-2.5"
                            >
                              <img
                                src={img.thumbUrl}
                                alt={img.altText}
                                referrerPolicy="no-referrer"
                                className="w-14 h-14 rounded object-cover shrink-0 border border-[var(--border-subtle)]"
                              />
                              <div className="flex-1 min-w-0 space-y-1.5">
                                <input
                                  type="text"
                                  required
                                  value={img.altText}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setPortImages((prev) =>
                                      prev.map((item, i) =>
                                        i === idx ? { ...item, altText: val } : item
                                      )
                                    );
                                  }}
                                  placeholder="Required alt text for accessibility"
                                  className="w-full px-2.5 py-1 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs"
                                />
                                <div className="flex items-center justify-between text-[11px] text-[var(--text-secondary)]">
                                  <label className="inline-flex items-center gap-1 cursor-pointer">
                                    <input
                                      type="radio"
                                      name="coverImageRadio"
                                      checked={img.isCover}
                                      onChange={() =>
                                        setPortImages((prev) =>
                                          prev.map((item, i) => ({
                                            ...item,
                                            isCover: i === idx,
                                          }))
                                        )
                                      }
                                    />
                                    <span>Cover image</span>
                                  </label>
                                  <span className="font-mono-tabular">
                                    {img.width}×{img.height}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setPortImages((prev) => prev.filter((_, i) => i !== idx))
                                    }
                                    className="text-red-600 hover:underline"
                                  >
                                    Remove
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={portUploading}
                      className="w-full py-2.5 px-4 font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg disabled:opacity-50"
                    >
                      {editingPortfolioId ? 'Update Portfolio Item' : 'Save to Portfolio (#work)'}
                    </button>
                  </form>
                </div>

                {/* Bulk Upload & OWNER Category Creation */}
                <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5 space-y-4 text-xs">
                  <div>
                    <h3 className="font-heading font-semibold text-sm">
                      Bulk Upload Multiple Designs
                    </h3>
                    <p className="text-[var(--text-secondary)] mt-0.5">
                      Select multiple image files at once to create separate portfolio items under "{portCategory}".
                    </p>
                    <label className="mt-2.5 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[var(--bg-subtle)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)] cursor-pointer font-medium">
                      <Upload className="w-3.5 h-3.5 text-[var(--brand-blue)]" />
                      <span>Select Multiple Files for Bulk Upload</span>
                      <input
                        type="file"
                        multiple
                        accept="image/jpeg,image/png,image/webp"
                        onChange={handleBulkPortfolioUpload}
                        disabled={portUploading}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {currentUser?.role === 'OWNER' && (
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        if (!newCategoryName.trim()) return;
                        try {
                          const res = await callPortfolioAdminApi({
                            subAction: 'create-category',
                            name: newCategoryName.trim(),
                          });
                          setDashboard(res.dashboard);
                          setPortCategory(res.category.name);
                          setNewCategoryName('');
                          onPublicDataChanged();
                          showNotice('success', `Added category "${res.category.name}".`);
                        } catch (err: any) {
                          showNotice('error', err.message);
                        }
                      }}
                      className="pt-3 border-t border-[var(--border-subtle)] space-y-2"
                    >
                      <label className="block font-medium">
                        Add Custom Filter Category (OWNER Only)
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={newCategoryName}
                          onChange={(e) => setNewCategoryName(e.target.value)}
                          placeholder="e.g. Certificates"
                          className="flex-1 px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                        />
                        <button
                          type="submit"
                          className="px-3.5 py-2 rounded-lg bg-[var(--brand-blue)] text-white font-medium"
                        >
                          Add
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              </div>

              {/* Right Column: Portfolio Items List with Drag-and-Drop Reorder & Filters */}
              <div className="lg:col-span-7 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-sm font-heading font-semibold">
                      Portfolio Items ({dashboard.portfolioItems.length})
                    </h2>
                    <p className="text-xs text-[var(--text-secondary)]">
                      Drag rows or use arrows to reorder. Featured items appear first in the "All" view.
                    </p>
                  </div>

                  <select
                    value={adminPortfolioFilter}
                    onChange={(e) => setAdminPortfolioFilter(e.target.value)}
                    className="px-3 py-1.5 text-xs rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                  >
                    <option value="ALL">All categories</option>
                    {(dashboard.portfolioCategories || []).map((c: any) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {dashboard.portfolioItems.length === 0 ? (
                  <div className="p-8 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-center space-y-1.5">
                    <p className="text-xs font-medium text-[var(--text-primary)]">
                      No portfolio items added yet
                    </p>
                    <p className="text-xs text-[var(--text-secondary)]">
                      The #work section on the main page currently displays the friendly WhatsApp empty state. Add work on the left to publish samples.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {dashboard.portfolioItems
                      .filter(
                        (item: any) =>
                          adminPortfolioFilter === 'ALL' ||
                          (item.categoryName || item.category) === adminPortfolioFilter
                      )
                      .map((item: any, idx: number) => {
                        const coverImg =
                          item.images?.find((i: any) => i.isCover) ||
                          item.images?.[0] || {
                            thumbUrl: item.imageUrl || '/logo.svg',
                          };
                        const imageCount = Array.isArray(item.images) ? item.images.length : 1;

                        return (
                          <div
                            key={item.id}
                            draggable
                            onDragStart={() => setDraggedPortfolioId(item.id)}
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={() => handlePortfolioDropReorder(item.id)}
                            className="p-3 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] flex flex-wrap sm:flex-nowrap items-center justify-between gap-3 text-xs cursor-move hover:border-[var(--brand-blue)] transition-colors"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <img
                                src={coverImg.thumbUrl}
                                alt={item.title}
                                referrerPolicy="no-referrer"
                                className="w-14 h-14 rounded object-cover shrink-0 border border-[var(--border-subtle)] bg-[var(--bg-subtle)]"
                              />
                              <div className="min-w-0 space-y-0.5">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <p className="font-semibold text-[var(--text-primary)] truncate">
                                    {item.title}
                                  </p>
                                  {item.featured && (
                                    <span className="px-2 py-0.5 text-[10px] font-medium rounded bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                                      Featured
                                    </span>
                                  )}
                                  {item.isSample && (
                                    <span className="px-2 py-0.5 text-[10px] rounded bg-[var(--bg-subtle)] text-[var(--text-secondary)]">
                                      Sample
                                    </span>
                                  )}
                                </div>
                                <p className="text-[var(--text-secondary)]">
                                  {item.categoryName || item.category} · {imageCount} image
                                  {imageCount > 1 ? 's' : ''} ·{' '}
                                  {item.visible ? 'Published' : 'Hidden'}
                                </p>
                                <p className="text-[11px] font-mono-tabular text-[var(--text-muted)]">
                                  #work/{item.slug}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => {
                                  const url = `${window.location.origin}/#work/${item.slug}`;
                                  navigator.clipboard?.writeText(url);
                                  showNotice('success', `Copied link #work/${item.slug}`);
                                }}
                                title="Copy direct #work/<slug> link"
                                className="px-2 py-1.5 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-[11px] font-medium"
                              >
                                Copy Link
                              </button>
                              <button
                                type="button"
                                onClick={() => handleEditPortfolioItemClick(item)}
                                className="px-2.5 py-1.5 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-[11px] font-medium"
                              >
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  const res = await callPortfolioAdminApi({
                                    subAction: 'update',
                                    id: item.id,
                                    featured: !item.featured,
                                  });
                                  setDashboard(res.dashboard);
                                  onPublicDataChanged();
                                }}
                                className={`px-2 py-1.5 rounded border text-[11px] font-medium ${
                                  item.featured
                                    ? 'bg-amber-50 border-amber-300 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300'
                                    : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] text-[var(--text-secondary)]'
                                }`}
                              >
                                {item.featured ? 'Featured' : 'Feature'}
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  const res = await callPortfolioAdminApi({
                                    subAction: 'reorder',
                                    id: item.id,
                                    direction: 'up',
                                  });
                                  setDashboard(res.dashboard);
                                  onPublicDataChanged();
                                }}
                                disabled={idx === 0}
                                aria-label="Move up"
                                className="p-1.5 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)] disabled:opacity-40"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  const res = await callPortfolioAdminApi({
                                    subAction: 'reorder',
                                    id: item.id,
                                    direction: 'down',
                                  });
                                  setDashboard(res.dashboard);
                                  onPublicDataChanged();
                                }}
                                aria-label="Move down"
                                className="p-1.5 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)]"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  const res = await callPortfolioAdminApi({
                                    subAction: 'update',
                                    id: item.id,
                                    visible: !item.visible,
                                  });
                                  setDashboard(res.dashboard);
                                  onPublicDataChanged();
                                }}
                                aria-label="Toggle visibility"
                                className="p-1.5 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)]"
                              >
                                {item.visible ? (
                                  <Eye className="w-3.5 h-3.5" />
                                ) : (
                                  <EyeOff className="w-3.5 h-3.5" />
                                )}
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  const res = await callPortfolioAdminApi({
                                    subAction: 'delete',
                                    id: item.id,
                                  });
                                  setDashboard(res.dashboard);
                                  onPublicDataChanged();
                                  showNotice('success', `Deleted "${item.title}".`);
                                }}
                                aria-label="Delete item"
                                className="p-1.5 rounded text-red-600 bg-[var(--bg-surface)] border border-[var(--border-subtle)]"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 6: SERVICES MANAGER */}
          {/* ================================================================= */}
          {activeTab === 'services' && dashboard && (
            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-heading font-semibold">
                  Services Catalogue ({dashboard.services.length})
                </h2>
                <span className="text-xs text-[var(--text-secondary)]">
                  Modifying services requires OWNER role
                </span>
              </div>
              <div className="divide-y divide-[var(--border-subtle)] text-xs">
                {dashboard.services.map((srv: any) => (
                  <div
                    key={srv.id}
                    className="py-3 flex flex-wrap items-center justify-between gap-3"
                  >
                    <div>
                      <span className="font-semibold text-[var(--text-primary)]">{srv.name}</span>
                      <span className="mx-2 text-[var(--text-muted)]">·</span>
                      <span className="text-[var(--text-secondary)]">{srv.category}</span>
                      <p className="text-[var(--text-muted)] mt-0.5">{srv.items.join(' · ')}</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const res = await callAdminApi({
                            action: 'update-service',
                            id: srv.id,
                            active: !srv.active,
                          });
                          setDashboard(res.dashboard);
                          onPublicDataChanged();
                          showNotice('success', `Updated "${srv.name}".`);
                        } catch (err: any) {
                          showNotice('error', err.message);
                        }
                      }}
                      className={`px-3 py-1.5 rounded-lg font-medium ${
                        srv.active
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {srv.active ? 'Active on site' : 'Hidden'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 7: REPORTS & CSV EXPORT */}
          {/* ================================================================= */}
          {activeTab === 'reports' && dashboard && (
            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 space-y-5">
              <h2 className="text-sm font-heading font-semibold">Reports & CSV Exports</h2>
              <p className="text-xs text-[var(--text-secondary)]">
                Download spreadsheet-ready CSV exports of orders, payments, receipts and customers.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() =>
                    handleExportCsv(
                      'mannu-visuals-orders.csv',
                      dashboard.orders.map((o: any) => ({
                        orderNumber: o.orderNumber,
                        customerName: o.customerName,
                        customerPhone: o.customerPhone,
                        serviceCategory: o.serviceCategory,
                        serviceName: o.serviceName,
                        status: o.status,
                        paymentStatus: o.paymentStatus,
                        priceKes: o.priceKes,
                        paidKes: o.paidKes,
                        createdAt: o.createdAt,
                      }))
                    )
                  }
                  className="p-4 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)] text-left flex items-center justify-between"
                >
                  <div>
                    <p className="text-xs font-semibold">Orders CSV</p>
                    <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">
                      {dashboard.orders.length} records
                    </p>
                  </div>
                  <Download className="w-4 h-4 text-[var(--brand-blue)]" />
                </button>

                <button
                  type="button"
                  onClick={() =>
                    handleExportCsv(
                      'mannu-visuals-payments.csv',
                      dashboard.payments.map((p: any) => ({
                        orderNumber: p.orderNumber,
                        phone: p.phone,
                        amountKes: p.amountKes,
                        method: p.method,
                        mpesaReceiptCode: p.mpesaReceiptCode || '',
                        status: p.status,
                        createdAt: p.createdAt,
                      }))
                    )
                  }
                  className="p-4 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)] text-left flex items-center justify-between"
                >
                  <div>
                    <p className="text-xs font-semibold">Payments CSV</p>
                    <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">
                      {dashboard.payments.length} records
                    </p>
                  </div>
                  <Download className="w-4 h-4 text-[var(--brand-blue)]" />
                </button>

                <button
                  type="button"
                  onClick={() =>
                    handleExportCsv(
                      'mannu-visuals-customers.csv',
                      dashboard.customers.map((c: any) => ({
                        name: c.name,
                        phone: c.phone,
                        totalOrders: c.totalOrders,
                        totalBilledKes: c.totalBilledKes,
                        totalPaidKes: c.totalPaidKes,
                        balanceKes: Math.max(0, c.totalBilledKes - c.totalPaidKes),
                      }))
                    )
                  }
                  className="p-4 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)] text-left flex items-center justify-between"
                >
                  <div>
                    <p className="text-xs font-semibold">Customers CSV</p>
                    <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">
                      {dashboard.customers.length} records
                    </p>
                  </div>
                  <Download className="w-4 h-4 text-[var(--brand-blue)]" />
                </button>
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 8: SETTINGS (OWNER ONLY) */}
          {/* ================================================================= */}
          {activeTab === 'settings' && dashboard && (
            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 max-w-2xl">
              <h2 className="text-sm font-heading font-semibold mb-1">
                Business & M-Pesa Settings (OWNER Only)
              </h2>
              <p className="text-xs text-[var(--text-secondary)] mb-5">
                Update public contact details, working hours, logo and M-Pesa configuration.
              </p>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  try {
                    const res = await callAdminApi({
                      action: 'update-settings',
                      businessName: formData.get('businessName'),
                      description: formData.get('description'),
                      whatsappDisplay: formData.get('whatsappDisplay'),
                      whatsappWaMe: formData.get('whatsappWaMe'),
                      facebookLink: formData.get('facebookLink'),
                      email: formData.get('email'),
                      workingHours: formData.get('workingHours'),
                      mpesaTillOrPaybill: formData.get('mpesaTillOrPaybill'),
                      mpesaTransactionType: formData.get('mpesaTransactionType'),
                    });
                    setDashboard(res.dashboard);
                    onPublicDataChanged();
                    showNotice('success', 'Business settings updated.');
                  } catch (err: any) {
                    showNotice('error', err.message);
                  }
                }}
                className="space-y-4 text-xs"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium mb-1">Business Name</label>
                    <input
                      name="businessName"
                      defaultValue={dashboard.settings.businessName}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">WhatsApp & Phone Display</label>
                    <input
                      name="whatsappDisplay"
                      defaultValue={dashboard.settings.whatsappDisplay}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">WhatsApp wa.me Number</label>
                    <input
                      name="whatsappWaMe"
                      defaultValue={dashboard.settings.whatsappWaMe}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] font-mono-tabular"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Email</label>
                    <input
                      name="email"
                      defaultValue={dashboard.settings.email}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">
                      Social Media (TikTok, Facebook, Instagram, YouTube)
                    </label>
                    <input
                      name="facebookLink"
                      defaultValue={dashboard.settings.facebookLink}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Working Hours</label>
                    <input
                      name="workingHours"
                      defaultValue={dashboard.settings.workingHours}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">M-Pesa Till / Paybill Display</label>
                    <input
                      name="mpesaTillOrPaybill"
                      defaultValue={dashboard.settings.mpesaTillOrPaybill}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Daraja Transaction Type</label>
                    <select
                      name="mpesaTransactionType"
                      defaultValue={dashboard.settings.mpesaTransactionType}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    >
                      <option value="CustomerPayBillOnline">CustomerPayBillOnline (Paybill)</option>
                      <option value="CustomerBuyGoodsOnline">CustomerBuyGoodsOnline (Till)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-medium mb-1">One-Line Description</label>
                  <input
                    name="description"
                    defaultValue={dashboard.settings.description}
                    className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                  />
                </div>

                <div>
                  <label className="block font-medium mb-1">Upload Custom Logo (Optional)</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      const reader = new FileReader();
                      reader.onload = async () => {
                        try {
                          const res = await callAdminApi({
                            action: 'update-settings',
                            logoUrl: String(reader.result),
                          });
                          setDashboard(res.dashboard);
                          onPublicDataChanged();
                          showNotice('success', 'Uploaded custom logo.');
                        } catch (err: any) {
                          showNotice('error', err.message);
                        }
                      };
                      reader.readAsDataURL(file);
                    }}
                    className="text-xs"
                  />
                </div>

                <button
                  type="submit"
                  className="py-2.5 px-5 font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg"
                >
                  Save Settings
                </button>
              </form>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 9: USERS & AUDIT LOG (OWNER ONLY) */}
          {/* ================================================================= */}
          {activeTab === 'users' && dashboard && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-5 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5 space-y-4">
                <h2 className="text-sm font-heading font-semibold">
                  Create Staff / Owner Account (OWNER Only)
                </h2>
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    try {
                      const res = await callAdminApi({
                        action: 'create-admin-user',
                        username: newUsername,
                        password: newPassword,
                        role: newRole,
                      });
                      setDashboard(res.dashboard);
                      setNewUsername('');
                      setNewPassword('');
                      showNotice('success', `Created ${newRole} account "${newUsername}".`);
                    } catch (err: any) {
                      showNotice('error', err.message);
                    }
                  }}
                  className="space-y-3 text-xs"
                >
                  <div>
                    <label className="block font-medium mb-1">Username</label>
                    <input
                      type="text"
                      required
                      value={newUsername}
                      onChange={(e) => setNewUsername(e.target.value)}
                      placeholder="e.g. staff_mary"
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Password (min 8 chars)</label>
                    <input
                      type="password"
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimum 8 characters"
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Role</label>
                    <select
                      value={newRole}
                      onChange={(e) => setNewRole(e.target.value as 'OWNER' | 'STAFF')}
                      className="w-full px-3 py-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]"
                    >
                      <option value="STAFF">STAFF (Orders, Invoices, Receipts, Customers, Portfolio)</option>
                      <option value="OWNER">OWNER (Full Access)</option>
                    </select>
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 font-medium text-white bg-[var(--brand-red)] rounded-lg"
                  >
                    Create User Account
                  </button>
                </form>

                <div className="pt-4 border-t border-[var(--border-subtle)] space-y-2">
                  <p className="text-xs font-semibold">Admin Users</p>
                  {dashboard.adminUsers.length === 0 ? (
                    <p className="text-xs text-[var(--text-secondary)]">
                      {currentUser.role === 'STAFF'
                        ? 'User list is restricted to OWNER accounts.'
                        : 'No password accounts created yet.'}
                    </p>
                  ) : (
                    dashboard.adminUsers.map((u: any) => (
                      <div
                        key={u.id}
                        className="p-2.5 rounded bg-[var(--bg-page)] border border-[var(--border-subtle)] flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-semibold">{u.username}</span>
                          <span className="mx-1.5">·</span>
                          <span className="font-mono-tabular text-[var(--brand-blue)]">
                            {u.role}
                          </span>
                          {u.lockedUntil && (
                            <span className="ml-2 text-red-600 font-medium">(Locked)</span>
                          )}
                        </div>
                        {u.lockedUntil && (
                          <button
                            type="button"
                            onClick={async () => {
                              const res = await callAdminApi({
                                action: 'update-admin-user',
                                userId: u.id,
                                unlockAccount: true,
                              });
                              setDashboard(res.dashboard);
                              showNotice('success', `Unlocked ${u.username}.`);
                            }}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)]"
                          >
                            <Unlock className="w-3 h-3" /> Unlock
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="lg:col-span-7 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-5">
                <h2 className="text-sm font-heading font-semibold mb-3">
                  Security & Operations Audit Log
                </h2>
                <div className="divide-y divide-[var(--border-subtle)] text-xs max-h-[480px] overflow-y-auto">
                  {dashboard.auditLog.map((log: any) => (
                    <div key={log.id} className="py-2.5 space-y-0.5">
                      <div className="flex justify-between">
                        <span className="font-mono-tabular font-semibold text-[var(--brand-blue)]">
                          {log.action}
                        </span>
                        <span className="font-mono-tabular text-[var(--text-muted)]">
                          {new Date(log.createdAt).toLocaleString('en-KE')}
                        </span>
                      </div>
                      <p className="text-[var(--text-primary)]">{log.details}</p>
                      <p className="text-[var(--text-muted)]">
                        Actor: {log.actorUsername} ({log.actorRole}) · Target: {log.targetType}/{log.targetId}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 10: 9-POINT SYSTEM VERIFICATION SUITE */}
          {/* ================================================================= */}
          {activeTab === 'verification' && (
            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-heading font-semibold">
                    End-to-End 9-Point Verification Test Suite
                  </h2>
                  <p className="text-xs text-[var(--text-secondary)] mt-0.5">
                    Tests: new order, file upload, price setting, partial payment, duplicate callback idempotency, failed payment, full payment + deliverable, wrong password lockout, and STAFF blocked from OWNER actions.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleRunVerificationSuite}
                  disabled={runningVerification}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg"
                >
                  <Play className="w-3.5 h-3.5" />
                  {runningVerification ? 'Running Tests...' : 'Run All 9 Tests Now'}
                </button>
              </div>

              {verificationReport && (
                <div className="space-y-2.5 text-xs">
                  {verificationReport.results.map((r: any) => (
                    <div
                      key={r.step}
                      className="p-3.5 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] flex items-start justify-between gap-3"
                    >
                      <div className="flex items-start gap-2.5">
                        {r.passed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        ) : (
                          <Lock className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="font-semibold text-[var(--text-primary)]">
                            {r.step}. {r.name}
                          </p>
                          <p className="text-[var(--text-secondary)] mt-0.5">{r.details}</p>
                        </div>
                      </div>
                      <span className="font-mono-tabular font-semibold text-emerald-700 dark:text-emerald-400">
                        {r.passed ? 'PASSED' : 'FAILED'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Document Print / View Modal */}
      {docModal && dashboard && (
        <PublicDocumentModal
          type={docModal.type}
          invoice={docModal.invoice}
          receipt={docModal.receipt}
          settings={dashboard.settings}
          onClose={() => setDocModal(null)}
          onRefreshDocument={() => loadDashboard()}
        />
      )}
    </div>
  );
};
