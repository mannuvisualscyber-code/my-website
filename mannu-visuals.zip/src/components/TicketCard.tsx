import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import {
  Printer,
  Download,
  CheckCircle2,
  Clock,
  AlertCircle,
  QrCode,
  Share2,
  Mail,
  MessageSquare,
  ExternalLink,
  Copy,
  X,
} from 'lucide-react';
import { Logo } from './Logo.tsx';

export type TicketStatusType =
  | 'PENDING_PAYMENT'
  | 'CONFIRMED'
  | 'PROCESSING'
  | 'READY'
  | 'COMPLETED'
  | 'CANCELLED';

export interface TicketData {
  ticketNumber: string;
  orderNumber: string;
  ticketStatus: TicketStatusType | string;
  orderStatus?: string;
  paymentStatus: string;
  customerName: string;
  customerPhoneMasked?: string;
  customerPhone?: string;
  customerEmail?: string;
  customerEmailMasked?: string | null;
  serviceCategory: string;
  serviceName: string;
  createdAt?: string;
  issuedAt?: string;
  deadline?: string | null;
  deliveryMethod?: string;
  priceKes?: number;
  paidKes?: number;
  balanceKes?: number;
  mpesaReceiptCode?: string | null;
  receiptNumber?: string | null;
  verifyUrl?: string;
  qrCodeData?: string;
}

interface TicketCardProps {
  ticket: TicketData;
  settings: {
    businessName: string;
    whatsappDisplay: string;
    whatsappWaMe: string;
    email: string;
    logoUrl: string;
  };
  isAdminView?: boolean;
  onResendWhatsApp?: (ticket: TicketData, verifyUrl: string) => void;
  onResendEmail?: (ticket: TicketData, verifyUrl: string) => void;
}

export function formatServiceCategoryLabel(cat: string): string {
  if (cat === 'government') return 'Online Government Services';
  if (cat === 'graphic_design') return 'Graphic Design';
  if (cat === 'other') return 'Other Online Services';
  return cat || 'Online Service';
}

export function getTicketStatusMeta(status: string): {
  label: string;
  badgeClass: string;
  dotClass: string;
} {
  const normalized = String(status || 'PENDING_PAYMENT').toUpperCase();
  switch (normalized) {
    case 'CONFIRMED':
      return {
        label: 'CONFIRMED',
        badgeClass:
          'bg-blue-50 text-[#0B4DA8] border-blue-200 dark:bg-blue-950/50 dark:text-blue-300 dark:border-blue-800',
        dotClass: 'bg-[#0B4DA8]',
      };
    case 'PROCESSING':
      return {
        label: 'PROCESSING',
        badgeClass:
          'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/50 dark:text-indigo-300 dark:border-indigo-800',
        dotClass: 'bg-indigo-600',
      };
    case 'READY':
      return {
        label: 'READY FOR COLLECTION / DOWNLOAD',
        badgeClass:
          'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800',
        dotClass: 'bg-emerald-600',
      };
    case 'COMPLETED':
    case 'FULFILLED':
      return {
        label: 'COMPLETED / FULFILLED',
        badgeClass:
          'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-200 dark:border-emerald-700',
        dotClass: 'bg-emerald-600',
      };
    case 'CANCELLED':
      return {
        label: 'CANCELLED',
        badgeClass:
          'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/50 dark:text-red-300 dark:border-red-800',
        dotClass: 'bg-red-600',
      };
    default:
      return {
        label: 'PENDING PAYMENT',
        badgeClass:
          'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800',
        dotClass: 'bg-amber-500',
      };
  }
}

export function maskContactPhone(phone?: string): string {
  if (!phone) return '2547****00';
  if (phone.includes('*')) return phone;
  if (phone.length < 8) return '2547****00';
  return `${phone.slice(0, 4)}****${phone.slice(-3)}`;
}

export const TicketCard: React.FC<TicketCardProps> = ({
  ticket,
  settings,
  isAdminView = false,
  onResendWhatsApp,
  onResendEmail,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [printModalOpen, setPrintModalOpen] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const origin =
    typeof window !== 'undefined' && window.location.origin
      ? window.location.origin
      : 'https://mannuvisuals.netlify.app';

  const verifyUrl =
    ticket.verifyUrl ||
    `${origin}/verify-ticket?ticket=${encodeURIComponent(ticket.ticketNumber)}`;

  useEffect(() => {
    let active = true;
    if (ticket.qrCodeData && ticket.qrCodeData.startsWith('data:image/')) {
      setQrDataUrl(ticket.qrCodeData);
      return;
    }
    QRCode.toDataURL(verifyUrl, {
      width: 240,
      margin: 1,
      color: {
        dark: '#0F172A',
        light: '#FFFFFF',
      },
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {
        if (active) setQrDataUrl('');
      });
    return () => {
      active = false;
    };
  }, [ticket.qrCodeData, verifyUrl]);

  const statusMeta = getTicketStatusMeta(ticket.ticketStatus);
  const issuedDateStr = ticket.issuedAt || ticket.createdAt || new Date().toISOString();
  const formattedIssuedDate = new Date(issuedDateStr).toLocaleDateString('en-KE', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const formattedDeadline = ticket.deadline
    ? new Date(ticket.deadline).toLocaleDateString('en-KE', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
    : 'Standard turnaround';

  const maskedContact =
    ticket.customerPhoneMasked || maskContactPhone(ticket.customerPhone);

  const handlePrintOrDownloadPdf = () => {
    setPrintModalOpen(true);
    window.setTimeout(() => {
      window.print();
    }, 180);
  };

  const handleCopyVerifyLink = async () => {
    try {
      await navigator.clipboard.writeText(verifyUrl);
      setCopiedLink(true);
      window.setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // Ignore clipboard failure
    }
  };

  const defaultResendWhatsApp = () => {
    if (onResendWhatsApp) {
      onResendWhatsApp(ticket, verifyUrl);
      return;
    }
    const targetPhone = (ticket.customerPhone || settings.whatsappWaMe).replace(/\D/g, '');
    const lines = [
      `Hello ${ticket.customerName}, here is your official ${settings.businessName} Service Ticket:`,
      `Ticket Number: ${ticket.ticketNumber}`,
      `Order Number: ${ticket.orderNumber}`,
      `Service: ${ticket.serviceName} (${formatServiceCategoryLabel(ticket.serviceCategory)})`,
      `Ticket Status: ${ticket.ticketStatus}`,
      `Payment Status: ${ticket.paymentStatus}${
        ticket.mpesaReceiptCode ? ` (M-Pesa Ref: ${ticket.mpesaReceiptCode})` : ''
      }`,
      `Verify / View Digital Ticket: ${verifyUrl}`,
    ];
    const waUrl = `https://wa.me/${targetPhone}?text=${encodeURIComponent(lines.join('\n'))}`;
    const a = document.createElement('a');
    a.href = waUrl;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const defaultResendEmail = () => {
    if (onResendEmail) {
      onResendEmail(ticket, verifyUrl);
      return;
    }
    const subject = `${settings.businessName} Ticket ${ticket.ticketNumber} (Order ${ticket.orderNumber})`;
    const bodyLines = [
      `Hello ${ticket.customerName},`,
      '',
      `Here are the details of your ${settings.businessName} digital service ticket:`,
      '',
      `Ticket Number: ${ticket.ticketNumber}`,
      `Order Number: ${ticket.orderNumber}`,
      `Ticket Status: ${ticket.ticketStatus}`,
      `Service Category: ${formatServiceCategoryLabel(ticket.serviceCategory)}`,
      `Service Requested: ${ticket.serviceName}`,
      `Date Issued: ${formattedIssuedDate}`,
      `Deadline: ${formattedDeadline}`,
      `Payment Status: ${ticket.paymentStatus}${
        ticket.mpesaReceiptCode ? ` (M-Pesa Receipt: ${ticket.mpesaReceiptCode})` : ''
      }`,
      '',
      `Verify or download your ticket online:`,
      verifyUrl,
      '',
      `Thank you,`,
      `${settings.businessName}`,
      `WhatsApp / Phone: ${settings.whatsappDisplay}`,
      `Email: ${settings.email}`,
    ];
    const mailto = `mailto:${encodeURIComponent(
      ticket.customerEmail || ''
    )}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(
      bodyLines.join('\n')
    )}`;
    const a = document.createElement('a');
    a.href = mailto;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <>
      <div className="rounded-[12px] border border-[var(--border-subtle)] bg-[var(--bg-surface)] overflow-hidden shadow-[var(--shadow-soft)]">
        {/* Top Brand Accent Bar */}
        <div className="h-2 bg-gradient-to-r from-[#0B4DA8] via-[#0B4DA8] to-[#E53935]" />

        {/* Ticket Header */}
        <div className="p-5 sm:p-6 border-b border-dashed border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Logo
              logoUrl={settings.logoUrl}
              businessName={settings.businessName}
              size="sm"
            />
            <div className="h-6 w-px bg-[var(--border-subtle)] hidden sm:block" />
            <div>
              <span className="text-[11px] uppercase tracking-wider font-semibold text-[var(--text-secondary)] block">
                Digital Service Ticket
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="font-mono-tabular text-base sm:text-lg font-bold text-[var(--brand-blue)]">
                  {ticket.ticketNumber}
                </span>
                <span className="text-xs font-mono-tabular px-2 py-0.5 rounded bg-[var(--bg-subtle)] text-[var(--text-secondary)] border border-[var(--border-subtle)]">
                  Order {ticket.orderNumber}
                </span>
              </div>
            </div>
          </div>

          <div
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-md border text-xs font-mono-tabular font-semibold ${statusMeta.badgeClass}`}
          >
            <span className={`w-2 h-2 rounded-full ${statusMeta.dotClass}`} />
            <span>{statusMeta.label}</span>
          </div>
        </div>

        {/* Ticket Body + Embedded QR Code */}
        <div className="p-5 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Ticket Details Grid */}
          <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-secondary)] block mb-0.5">
                Client Name &amp; Contact
              </span>
              <p className="font-semibold text-[var(--text-primary)] text-sm">
                {ticket.customerName || 'Valued Client'}
              </p>
              <p className="font-mono-tabular text-[var(--text-secondary)] mt-0.5">
                Phone: {maskedContact}
                {isAdminView && ticket.customerPhone && (
                  <span className="ml-1 text-[11px] text-[var(--brand-blue)]">
                    ({ticket.customerPhone})
                  </span>
                )}
              </p>
            </div>

            <div className="p-3 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-secondary)] block mb-0.5">
                Service Category &amp; Request
              </span>
              <p className="font-semibold text-[var(--text-primary)] text-sm">
                {ticket.serviceName}
              </p>
              <p className="text-[var(--text-secondary)] mt-0.5">
                {formatServiceCategoryLabel(ticket.serviceCategory)}
              </p>
            </div>

            <div className="p-3 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-secondary)] block mb-0.5">
                Date Issued &amp; Deadline
              </span>
              <p className="font-mono-tabular font-semibold text-[var(--text-primary)]">
                Issued: {formattedIssuedDate}
              </p>
              <p className="font-mono-tabular text-[var(--text-secondary)] mt-0.5">
                Deadline: {formattedDeadline}
              </p>
            </div>

            <div className="p-3 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-secondary)] block mb-0.5">
                Payment Status &amp; M-Pesa Ref
              </span>
              <div className="flex items-center gap-2">
                <span
                  className={`font-mono-tabular font-bold ${
                    ticket.paymentStatus === 'PAID'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-[var(--text-primary)]'
                  }`}
                >
                  {ticket.paymentStatus}
                </span>
                {typeof ticket.priceKes === 'number' && ticket.priceKes > 0 && (
                  <span className="font-mono-tabular text-[var(--text-secondary)]">
                    · KES {ticket.paidKes?.toLocaleString() || 0} /{' '}
                    {ticket.priceKes.toLocaleString()}
                  </span>
                )}
              </div>
              <p className="font-mono-tabular text-[var(--text-secondary)] mt-0.5">
                {ticket.mpesaReceiptCode ? (
                  <>
                    M-Pesa Code:{' '}
                    <span className="font-semibold text-[var(--text-primary)]">
                      {ticket.mpesaReceiptCode}
                    </span>
                  </>
                ) : (
                  'M-Pesa code appears once paid'
                )}
              </p>
            </div>
          </div>

          {/* QR Code Verification Box */}
          <div className="md:col-span-4 flex flex-col items-center justify-center p-4 rounded-[12px] bg-white border border-slate-200 text-slate-900">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={`Verification QR Code for Ticket ${ticket.ticketNumber}`}
                className="w-36 h-36 object-contain"
              />
            ) : (
              <div className="w-36 h-36 flex items-center justify-center bg-slate-50 rounded border border-slate-200">
                <QrCode className="w-10 h-10 text-slate-400" />
              </div>
            )}
            <p className="mt-2 font-mono-tabular text-xs font-bold text-slate-900">
              {ticket.ticketNumber}
            </p>
            <p className="text-[11px] text-slate-500 text-center mt-0.5">
              Scan to verify ticket status
            </p>
          </div>
        </div>

        {/* Ticket Actions Footer */}
        <div className="px-5 py-4 bg-[var(--bg-subtle)] border-t border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handlePrintOrDownloadPdf}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium text-white bg-[var(--brand-blue)] hover:bg-[var(--brand-blue-hover)] transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Download PDF / Print Ticket</span>
            </button>

            <button
              type="button"
              onClick={handleCopyVerifyLink}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-[var(--bg-surface)] text-[var(--text-primary)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)] transition-colors"
            >
              <Copy className="w-3.5 h-3.5 text-[var(--brand-blue)]" />
              <span>{copiedLink ? 'Verification Link Copied' : 'Copy Verify Link'}</span>
            </button>
          </div>

          {isAdminView && (
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={defaultResendWhatsApp}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Resend to WhatsApp</span>
              </button>
              <button
                type="button"
                onClick={defaultResendEmail}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-[var(--bg-surface)] text-[var(--text-primary)] border border-[var(--border-subtle)] hover:border-[var(--brand-blue)] transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-[var(--brand-blue)]" />
                <span>Resend to Email</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Printable / PDF Ticket Modal */}
      {printModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-[12px] max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
            {/* Non-printed top toolbar */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 print:hidden">
              <span className="text-xs font-semibold text-slate-600">
                Print or Save as PDF — Ticket {ticket.ticketNumber}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium text-white bg-[#0B4DA8] hover:bg-blue-800"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print / Save PDF
                </button>
                <button
                  type="button"
                  onClick={() => setPrintModalOpen(false)}
                  className="p-2 rounded-lg text-slate-500 hover:bg-slate-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Ticket Sheet */}
            <div className="border-2 border-slate-900 rounded-xl p-6 space-y-6 bg-white text-slate-900">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b-2 border-dashed border-slate-300 pb-5">
                <div>
                  <Logo
                    logoUrl={settings.logoUrl}
                    businessName={settings.businessName}
                    size="md"
                  />
                  <p className="text-xs text-slate-600 mt-1">
                    WhatsApp / Phone: {settings.whatsappDisplay} · Email: {settings.email}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] uppercase tracking-wider font-bold text-slate-500 block">
                    Official Service Ticket
                  </span>
                  <p className="text-xl font-bold font-mono-tabular text-[#0B4DA8] mt-0.5">
                    {ticket.ticketNumber}
                  </p>
                  <p className="text-xs font-mono-tabular text-slate-700 mt-0.5">
                    Order Number: {ticket.orderNumber}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
                <div className="sm:col-span-8 grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 block">Client Name</span>
                    <span className="font-bold text-sm text-slate-900">
                      {ticket.customerName}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Client Contact (Masked)</span>
                    <span className="font-mono-tabular font-semibold text-sm text-slate-900">
                      {maskedContact}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Service Category</span>
                    <span className="font-semibold text-slate-900">
                      {formatServiceCategoryLabel(ticket.serviceCategory)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Service Requested</span>
                    <span className="font-bold text-slate-900">{ticket.serviceName}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Date Issued</span>
                    <span className="font-mono-tabular font-semibold text-slate-900">
                      {formattedIssuedDate}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Deadline</span>
                    <span className="font-mono-tabular font-semibold text-slate-900">
                      {formattedDeadline}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Ticket Status</span>
                    <span className="font-mono-tabular font-bold text-[#0B4DA8]">
                      {statusMeta.label}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">
                      Payment Status &amp; M-Pesa Code
                    </span>
                    <span className="font-mono-tabular font-bold text-slate-900">
                      {ticket.paymentStatus}
                      {ticket.mpesaReceiptCode ? ` · ${ticket.mpesaReceiptCode}` : ''}
                    </span>
                  </div>
                </div>

                <div className="sm:col-span-4 flex flex-col items-center justify-center border border-slate-200 rounded-lg p-3 bg-white">
                  {qrDataUrl && (
                    <img
                      src={qrDataUrl}
                      alt={`QR Code ${ticket.ticketNumber}`}
                      className="w-32 h-32 object-contain"
                    />
                  )}
                  <span className="font-mono-tabular text-[11px] font-bold text-slate-900 mt-1">
                    {ticket.ticketNumber}
                  </span>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                <span>Verify online: {verifyUrl}</span>
                <span>{settings.businessName} — Online Cyber &amp; Graphic Design</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
