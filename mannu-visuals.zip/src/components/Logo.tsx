import React from 'react';

interface LogoProps {
  logoUrl?: string;
  businessName?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: React.FC<LogoProps> = ({
  logoUrl,
  businessName = 'Mannu Visuals',
  size = 'md',
}) => {
  const heightClass =
    size === 'sm' ? 'h-8' : size === 'lg' ? 'h-12' : 'h-10';

  const hasCustomLogo =
    logoUrl && logoUrl !== '/logo.svg' && logoUrl.startsWith('data:image');

  return (
    <span className="inline-flex items-center select-none" aria-label={businessName}>
      {hasCustomLogo ? (
        <img
          src={logoUrl}
          alt={businessName}
          referrerPolicy="no-referrer"
          className={`${heightClass} w-auto object-contain shrink-0`}
        />
      ) : (
        <svg
          viewBox="0 0 540 200"
          fill="none"
          role="img"
          aria-label={businessName}
          className={`${heightClass} w-auto shrink-0`}
        >
          {/* Left outer black/ink diagonal of M */}
          <polygon
            points="74,18 93,58 38,144 58,76"
            className="fill-slate-950 dark:fill-white"
          />
          {/* Crimson red slash of M */}
          <polygon
            points="111,28 116,68 59,155 32,172"
            fill="#D50000"
          />
          {/* Right black/ink body of M */}
          <polygon
            points="98,115 115,131 148,84 142,145 162,169 180,42 158,42 116,105 107,89"
            className="fill-slate-950 dark:fill-white"
          />
          {/* "annu" */}
          <text
            x="184"
            y="118"
            fontFamily="'Plus Jakarta Sans', 'Inter', sans-serif"
            fontSize="94"
            fontWeight="800"
            letterSpacing="-2"
            className="fill-slate-950 dark:fill-white"
          >
            annu
          </text>
          {/* "VISUALS" */}
          <text
            x="178"
            y="172"
            fontFamily="'Plus Jakarta Sans', 'Inter', sans-serif"
            fontSize="43"
            fontWeight="800"
            letterSpacing="1.5"
            fill="#D50000"
          >
            VISUALS
          </text>
          {/* Red vertical divider bar */}
          <rect x="427" y="132" width="6" height="50" fill="#D50000" />
          {/* "KE" */}
          <text
            x="445"
            y="172"
            fontFamily="'Plus Jakarta Sans', 'Inter', sans-serif"
            fontSize="37"
            fontWeight="800"
            letterSpacing="1"
            className="fill-slate-950 dark:fill-white"
          >
            KE
          </text>
        </svg>
      )}
    </span>
  );
};
