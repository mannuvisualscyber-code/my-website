import React, { useEffect, useRef, useState } from 'react';
import { MessageSquare } from 'lucide-react';
import { Logo } from './Logo.tsx';

const ROTATING_PHRASES = [
  'Wedding cards',
  'Posters and flyers',
  'Business logos',
  'CV writing',
  'KRA and eCitizen help',
  'Church posters',
] as const;

interface HeroSectionProps {
  businessName: string;
  logoUrl?: string;
  whatsappWaMe: string;
  onOrderClick: (e: React.MouseEvent<HTMLAnchorElement>) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  businessName,
  logoUrl,
  whatsappWaMe,
  onOrderClick,
}) => {
  const sectionRef = useRef<HTMLElement | null>(null);
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [phraseVisible, setPhraseVisible] = useState(true);
  const [isInView, setIsInView] = useState(true);
  const [isTabVisible, setIsTabVisible] = useState(true);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // Detect prefers-reduced-motion & tab visibility for battery savings
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);

    const handleMediaChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };
    mediaQuery.addEventListener('change', handleMediaChange);

    const handleVisibilityChange = () => {
      setIsTabVisible(document.visibilityState === 'visible');
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      mediaQuery.removeEventListener('change', handleMediaChange);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  // Pause animations when the Hero section scrolls off-screen
  useEffect(() => {
    const el = sectionRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]) {
          setIsInView(entries[0].isIntersecting);
        }
      },
      { threshold: 0.05 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const isMotionPaused = prefersReducedMotion || !isInView || !isTabVisible;

  // Rotate phrase every 3 seconds with a soft fade
  useEffect(() => {
    if (isMotionPaused) {
      setPhraseVisible(true);
      return;
    }

    let fadeTimeout: number | null = null;
    const interval = window.setInterval(() => {
      setPhraseVisible(false);
      fadeTimeout = window.setTimeout(() => {
        setPhraseIndex((prev) => (prev + 1) % ROTATING_PHRASES.length);
        setPhraseVisible(true);
      }, 240);
    }, 3000);

    return () => {
      window.clearInterval(interval);
      if (fadeTimeout) window.clearTimeout(fadeTimeout);
    };
  }, [isMotionPaused]);

  return (
    <section
      ref={sectionRef}
      data-motion-paused={isMotionPaused ? 'true' : 'false'}
      className="relative overflow-hidden py-16 sm:py-24 px-4 sm:px-6 border-b border-[var(--border-subtle)] bg-[var(--bg-surface)]"
    >
      {/* =================================================================== */}
      {/* LAYER 1: Soft Brand Colour Gradient Mesh (#0B4DA8 & #E53935 tints)  */}
      {/* =================================================================== */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 overflow-hidden select-none"
      >
        <div
          className="mv-anim-mesh absolute -top-24 -left-20 w-80 h-80 sm:w-[440px] sm:h-[440px] rounded-full opacity-90"
          style={{
            background:
              'radial-gradient(circle, rgba(11, 77, 168, 0.085) 0%, rgba(11, 77, 168, 0) 70%)',
          }}
        />
        <div
          className="mv-anim-mesh absolute -bottom-28 -right-20 w-80 h-80 sm:w-[460px] sm:h-[460px] rounded-full opacity-90"
          style={{
            background:
              'radial-gradient(circle, rgba(229, 57, 53, 0.07) 0%, rgba(229, 57, 53, 0) 70%)',
            animationDelay: '-9s',
          }}
        />
      </div>

      {/* =================================================================== */}
      {/* LAYER 2: 6 Floating SVG Design Mockup Cards (Placeholder Grey Bars) */}
      {/* =================================================================== */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 max-w-6xl mx-auto select-none"
      >
        {/* 1. Wedding Card Mockup (Top-Left) — with bars filling one by one */}
        <div className="mv-anim-card-a absolute top-4 left-2 sm:top-6 sm:left-4 md:left-6 w-28 sm:w-36 opacity-55 sm:opacity-75">
          <svg
            viewBox="0 0 140 176"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-auto drop-shadow-xs"
          >
            <rect
              x="2"
              y="2"
              width="136"
              height="172"
              rx="12"
              className="fill-[var(--bg-surface)] stroke-[var(--border-subtle)]"
              strokeWidth="1.5"
            />
            {/* Arch inner frame */}
            <path
              d="M20 156V62C20 34.3858 42.3858 12 70 12C97.6142 12 120 34.3858 120 62V156H20Z"
              stroke="#0B4DA8"
              strokeOpacity="0.28"
              strokeWidth="1.2"
            />
            {/* Minimal floral emblem */}
            <circle cx="70" cy="40" r="6" fill="#E53935" fillOpacity="0.22" />
            <circle cx="70" cy="40" r="2.5" fill="#E53935" fillOpacity="0.7" />
            {/* Animated grey placeholder bars filling in one by one */}
            <rect
              x="36"
              y="62"
              width="68"
              height="6"
              rx="3"
              fill="#64748B"
              fillOpacity="0.45"
              className="mv-anim-bar-1"
            />
            <rect
              x="44"
              y="76"
              width="52"
              height="5"
              rx="2.5"
              fill="#94A3B8"
              fillOpacity="0.45"
              className="mv-anim-bar-2"
            />
            <rect
              x="32"
              y="96"
              width="76"
              height="5"
              rx="2.5"
              fill="#94A3B8"
              fillOpacity="0.38"
              className="mv-anim-bar-3"
            />
            <rect
              x="48"
              y="110"
              width="44"
              height="4"
              rx="2"
              fill="#CBD5E1"
              fillOpacity="0.6"
            />
            {/* Colour swatches fading into place */}
            <circle
              cx="58"
              cy="134"
              r="5"
              fill="#0B4DA8"
              fillOpacity="0.75"
              className="mv-anim-swatch"
            />
            <circle
              cx="72"
              cy="134"
              r="5"
              fill="#E53935"
              fillOpacity="0.75"
              className="mv-anim-swatch"
            />
            <circle cx="86" cy="134" r="5" fill="#94A3B8" fillOpacity="0.45" />
          </svg>
        </div>

        {/* 2. Poster Mockup (Bottom-Left) */}
        <div
          className="mv-anim-card-b absolute bottom-3 left-3 sm:bottom-6 sm:left-8 md:left-12 w-28 sm:w-36 opacity-50 sm:opacity-75"
          style={{ animationDelay: '-4s' }}
        >
          <svg
            viewBox="0 0 140 176"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-auto drop-shadow-xs"
          >
            <rect
              x="2"
              y="2"
              width="136"
              height="172"
              rx="12"
              className="fill-[var(--bg-surface)] stroke-[var(--border-subtle)]"
              strokeWidth="1.5"
            />
            {/* Poster header banner */}
            <rect
              x="14"
              y="14"
              width="112"
              height="44"
              rx="7"
              fill="#0B4DA8"
              fillOpacity="0.14"
            />
            <rect x="24" y="26" width="58" height="7" rx="3.5" fill="#0B4DA8" fillOpacity="0.65" />
            <rect x="24" y="39" width="38" height="5" rx="2.5" fill="#64748B" fillOpacity="0.45" />
            {/* Accent pill */}
            <rect x="14" y="68" width="34" height="6" rx="3" fill="#E53935" fillOpacity="0.7" />
            {/* Placeholder lines */}
            <rect x="14" y="84" width="104" height="6" rx="3" fill="#64748B" fillOpacity="0.4" />
            <rect x="14" y="96" width="88" height="5" rx="2.5" fill="#94A3B8" fillOpacity="0.4" />
            <rect x="14" y="108" width="96" height="5" rx="2.5" fill="#94A3B8" fillOpacity="0.35" />
            {/* Footer blocks */}
            <rect x="14" y="132" width="52" height="24" rx="5" fill="#94A3B8" fillOpacity="0.2" />
            <rect x="74" y="132" width="52" height="24" rx="5" fill="#94A3B8" fillOpacity="0.2" />
          </svg>
        </div>

        {/* 3. Business Logo Mark Mockup (Top-Right) — with cursor moving across */}
        <div
          className="mv-anim-card-c absolute top-4 right-2 sm:top-7 sm:right-4 md:right-6 w-28 sm:w-40 opacity-55 sm:opacity-75"
          style={{ animationDelay: '-2.5s' }}
        >
          <svg
            viewBox="0 0 156 144"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-auto drop-shadow-xs"
          >
            <rect
              x="2"
              y="2"
              width="152"
              height="140"
              rx="12"
              className="fill-[var(--bg-surface)] stroke-[var(--border-subtle)]"
              strokeWidth="1.5"
            />
            {/* Construction grid guides */}
            <line
              x1="18"
              y1="54"
              x2="138"
              y2="54"
              stroke="#94A3B8"
              strokeOpacity="0.22"
              strokeDasharray="3 3"
            />
            <line
              x1="78"
              y1="16"
              x2="78"
              y2="92"
              stroke="#94A3B8"
              strokeOpacity="0.22"
              strokeDasharray="3 3"
            />
            {/* Generic geometric logo mark (interlocking circle + diamond) */}
            <circle
              cx="68"
              cy="54"
              r="18"
              stroke="#0B4DA8"
              strokeOpacity="0.75"
              strokeWidth="3.5"
            />
            <rect
              x="76"
              y="38"
              width="22"
              height="22"
              rx="4"
              transform="rotate(45 87 49)"
              fill="#E53935"
              fillOpacity="0.7"
            />
            {/* Placeholder title bars */}
            <rect x="38" y="98" width="80" height="6" rx="3" fill="#64748B" fillOpacity="0.45" />
            <rect x="52" y="110" width="52" height="5" rx="2.5" fill="#94A3B8" fillOpacity="0.4" />
            {/* Animated studio cursor arrow */}
            <g className="mv-anim-cursor">
              <path
                d="M112 72L116 88L120.5 82.5L126.5 87L128.5 84.5L122.5 80L128 77.5L112 72Z"
                fill="#0B4DA8"
                stroke="#FFFFFF"
                strokeWidth="1.2"
              />
            </g>
          </svg>
        </div>

        {/* 4. CV Page Mockup (Bottom-Right) */}
        <div
          className="mv-anim-card-d hidden sm:block absolute bottom-4 right-5 md:right-12 w-32 sm:w-36 opacity-70"
          style={{ animationDelay: '-7s' }}
        >
          <svg
            viewBox="0 0 140 176"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-auto drop-shadow-xs"
          >
            <rect
              x="2"
              y="2"
              width="136"
              height="172"
              rx="12"
              className="fill-[var(--bg-surface)] stroke-[var(--border-subtle)]"
              strokeWidth="1.5"
            />
            {/* Profile avatar circle + header bars */}
            <circle cx="30" cy="30" r="12" fill="#0B4DA8" fillOpacity="0.2" />
            <rect x="50" y="22" width="66" height="6" rx="3" fill="#64748B" fillOpacity="0.5" />
            <rect x="50" y="33" width="44" height="5" rx="2.5" fill="#94A3B8" fillOpacity="0.45" />
            <line x1="16" y1="52" x2="124" y2="52" stroke="#94A3B8" strokeOpacity="0.25" />
            {/* Two-column CV layout */}
            <rect x="16" y="64" width="28" height="5" rx="2.5" fill="#0B4DA8" fillOpacity="0.5" />
            <rect x="16" y="75" width="24" height="4" rx="2" fill="#94A3B8" fillOpacity="0.4" />
            <rect x="16" y="84" width="28" height="4" rx="2" fill="#94A3B8" fillOpacity="0.4" />
            <rect x="16" y="104" width="26" height="5" rx="2.5" fill="#E53935" fillOpacity="0.55" />
            <rect x="16" y="115" width="22" height="4" rx="2" fill="#94A3B8" fillOpacity="0.4" />
            {/* Right column experience bars */}
            <rect x="54" y="64" width="68" height="5" rx="2.5" fill="#64748B" fillOpacity="0.45" />
            <rect x="54" y="74" width="62" height="4" rx="2" fill="#94A3B8" fillOpacity="0.38" />
            <rect x="54" y="83" width="56" height="4" rx="2" fill="#94A3B8" fillOpacity="0.38" />
            <rect x="54" y="102" width="68" height="5" rx="2.5" fill="#64748B" fillOpacity="0.45" />
            <rect x="54" y="112" width="58" height="4" rx="2" fill="#94A3B8" fillOpacity="0.38" />
            <rect x="54" y="121" width="64" height="4" rx="2" fill="#94A3B8" fillOpacity="0.38" />
            <rect x="54" y="140" width="48" height="4" rx="2" fill="#94A3B8" fillOpacity="0.35" />
          </svg>
        </div>

        {/* 5. Social Media Post Mockup (Mid-Left on Desktop) */}
        <div
          className="mv-anim-card-d hidden lg:block absolute top-1/2 -translate-y-1/2 left-44 w-28 opacity-65"
          style={{ animationDelay: '-11s' }}
        >
          <svg
            viewBox="0 0 124 136"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-auto drop-shadow-xs"
          >
            <rect
              x="2"
              y="2"
              width="120"
              height="132"
              rx="12"
              className="fill-[var(--bg-surface)] stroke-[var(--border-subtle)]"
              strokeWidth="1.5"
            />
            {/* Square social image canvas */}
            <rect
              x="12"
              y="12"
              width="100"
              height="78"
              rx="7"
              fill="#0B4DA8"
              fillOpacity="0.1"
            />
            <circle cx="34" cy="32" r="7" fill="#E53935" fillOpacity="0.45" />
            <path
              d="M16 84L44 54L68 76L86 60L108 84H16Z"
              fill="#0B4DA8"
              fillOpacity="0.24"
            />
            {/* Caption bars */}
            <rect x="12" y="100" width="74" height="5" rx="2.5" fill="#64748B" fillOpacity="0.45" />
            <rect x="12" y="111" width="52" height="4" rx="2" fill="#94A3B8" fillOpacity="0.4" />
          </svg>
        </div>

        {/* 6. Church Flyer Mockup (Mid-Right on Desktop) */}
        <div
          className="mv-anim-card-a hidden lg:block absolute top-1/2 -translate-y-1/2 right-44 w-28 opacity-65"
          style={{ animationDelay: '-6s' }}
        >
          <svg
            viewBox="0 0 124 152"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-auto drop-shadow-xs"
          >
            <rect
              x="2"
              y="2"
              width="120"
              height="148"
              rx="12"
              className="fill-[var(--bg-surface)] stroke-[var(--border-subtle)]"
              strokeWidth="1.5"
            />
            {/* Minimal church arch + cross icon */}
            <path
              d="M36 68V42C36 27.6406 47.6406 16 62 16C76.3594 16 88 27.6406 88 42V68H36Z"
              fill="#0B4DA8"
              fillOpacity="0.1"
            />
            <path
              d="M62 26V52M53 35H71"
              stroke="#0B4DA8"
              strokeOpacity="0.65"
              strokeWidth="2.2"
              strokeLinecap="round"
            />
            {/* Event lines */}
            <rect x="24" y="82" width="76" height="6" rx="3" fill="#64748B" fillOpacity="0.45" />
            <rect x="34" y="95" width="56" height="5" rx="2.5" fill="#94A3B8" fillOpacity="0.4" />
            <rect x="28" y="112" width="68" height="16" rx="5" fill="#E53935" fillOpacity="0.18" />
          </svg>
        </div>

        {/* ================================================================= */}
        {/* LAYER 3: 5 Small Floating Service Icons                           */}
        {/* ================================================================= */}
        {/* Icon 1: Document */}
        <div
          className="mv-anim-icon absolute top-12 left-[32%] hidden sm:flex w-8 h-8 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] items-center justify-center shadow-2xs opacity-65"
          style={{ animationDelay: '-1s' }}
        >
          <svg className="w-4 h-4 text-[var(--brand-blue)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="8" y1="13" x2="16" y2="13" />
            <line x1="8" y1="17" x2="13" y2="17" />
          </svg>
        </div>

        {/* Icon 2: Pen Tool */}
        <div
          className="mv-anim-icon absolute top-14 right-[31%] hidden sm:flex w-8 h-8 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] items-center justify-center shadow-2xs opacity-65"
          style={{ animationDelay: '-5s' }}
        >
          <svg className="w-4 h-4 text-[var(--brand-red)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M12 19l7-7 3 3-7 7-3-3z" />
            <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
            <path d="M2 2l7.586 7.586" />
            <circle cx="11" cy="11" r="2" />
          </svg>
        </div>

        {/* Icon 3: Magnifier */}
        <div
          className="mv-anim-icon absolute bottom-10 left-[30%] hidden md:flex w-8 h-8 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] items-center justify-center shadow-2xs opacity-65"
          style={{ animationDelay: '-8s' }}
        >
          <svg className="w-4 h-4 text-[var(--brand-blue)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </div>

        {/* Icon 4: Checkmark */}
        <div
          className="mv-anim-icon absolute bottom-12 right-[30%] hidden md:flex w-8 h-8 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] items-center justify-center shadow-2xs opacity-65"
          style={{ animationDelay: '-3.5s' }}
        >
          <svg className="w-4 h-4 text-[var(--brand-blue)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
            <polyline points="22 4 12 14.01 9 11.01" />
          </svg>
        </div>

        {/* Icon 5: Photo Frame */}
        <div
          className="mv-anim-icon absolute top-6 right-[18%] hidden lg:flex w-8 h-8 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] items-center justify-center shadow-2xs opacity-60"
          style={{ animationDelay: '-10s' }}
        >
          <svg className="w-4 h-4 text-[var(--brand-red)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <polyline points="21 15 16 10 5 21" />
          </svg>
        </div>
      </div>

      {/* =================================================================== */}
      {/* FOREGROUND HERO CONTENT WITH TRANSLUCENT CONTRAST OVERLAY (WCAG AA) */}
      {/* =================================================================== */}
      <div className="relative z-10 max-w-2xl mx-auto">
        <div className="rounded-2xl bg-[var(--bg-surface)]/90 backdrop-blur-xs px-5 py-8 sm:px-10 sm:py-10 text-center space-y-5 border border-[var(--border-subtle)]/70 shadow-[var(--shadow-soft)]">
          <div className="flex justify-center">
            <Logo logoUrl={logoUrl} businessName={businessName} size="lg" />
          </div>

          <div className="space-y-2.5">
            <h1
              className="text-3xl sm:text-5xl font-heading font-bold text-[var(--text-primary)] tracking-tight"
              style={{ textWrap: 'balance' }}
            >
              {businessName}
            </h1>
            <p className="text-base sm:text-lg text-[var(--text-secondary)] max-w-xl mx-auto">
              Online cyber and graphic design services.
            </p>

            {/* Rotating phrase every 3 seconds with a soft fade */}
            <div className="h-6 flex items-center justify-center" aria-live="polite">
              <span
                className={`text-xs sm:text-sm font-medium text-[var(--brand-blue)] transition-opacity duration-200 ${
                  phraseVisible ? 'opacity-100' : 'opacity-0'
                }`}
              >
                {ROTATING_PHRASES[phraseIndex]}
              </span>
            </div>
          </div>

          <div className="pt-1 flex flex-wrap items-center justify-center gap-3.5">
            <a
              href="#order"
              onClick={onOrderClick}
              className="px-6 py-3 text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors whitespace-nowrap min-h-[44px] inline-flex items-center"
            >
              Order now
            </a>
            <a
              href={`https://wa.me/${whatsappWaMe}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 text-sm font-medium text-[var(--text-primary)] bg-[var(--bg-subtle)] hover:bg-slate-200/70 dark:hover:bg-slate-800 border border-[var(--border-subtle)] rounded-lg transition-colors whitespace-nowrap min-h-[44px] inline-flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4 text-[var(--brand-blue)]" />
              Chat on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
