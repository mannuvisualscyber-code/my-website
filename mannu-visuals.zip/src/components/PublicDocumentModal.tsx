import React, { useState } from 'react';
import { Printer, X, Smartphone, CheckCircle2, FileText } from 'lucide-react';
import { Logo } from './Logo.tsx';

export interface PublicInvoiceView {
  invoiceNumber: string;
  orderNumber: string | null;
  customerName: string;
  customerPhoneMasked: string;
  items: {
    id: string;
    description: string;
    quantity: number;
    unitPriceKes: number;
    lineTotalKes: number;
  }[];
  subtotalKes: number;
  discountKes: number;
  totalKes: number;
  paidKes: number;
  balanceKes: number;
  status: string;
  dueDate: string | null;
  notes: string | null;
  publicToken: string;
  receiptToken: string | null;
  receiptNumber: string | null;
  createdAt: string;
}

export interface PublicReceiptView {
  receiptNumber: string;
  orderNumber: string;
  customerName: string;
  customerPhoneMasked: string;
  serviceDescription: string;
  amountKes: number;
  paymentMethod: string;
  mpesaReceiptCode: string | null;
  balanceAfterKes: number;
  publicToken: string;
  issuedAt: string;
}

interface PublicDocumentModalProps {
  type: 'invoice' | 'receipt';
  invoice?: PublicInvoiceView | null;
  receipt?: PublicReceiptView | null;
  settings: {
    businessName: string;
    description: string;
    whatsappDisplay: string;
    email: string;
    mpesaTillOrPaybill: string;
    logoUrl: string;
  };
  onClose: () => void;
  onRefreshDocument?: () => void;
}

export const PublicDocumentModal: React.FC<PublicDocumentModalProps> = ({
  type,
  invoice,
  receipt,
  settings,
  onClose,
  onRefreshDocument,
}) => {
  const [printFormat, setPrintFormat] = useState<'a4' | '80mm'>('a4');
  const [payPhone, setPayPhone] = useState('');
  const [payLoading, setPayLoading] = useState(false);
  const [payMessage, setPayMessage] = useState<string | null>(null);
  const [payError, setPayError] = useState<string | null>(null);
  const [activeCheckoutId, setActiveCheckoutId] = useState<string | null>(null);

  const handlePrint = () => {
    window.print();
  };

  const handlePayInvoiceStk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invoice) return;
    setPayError(null);
    setPayMessage(null);
    setPayLoading(true);
    try {
      const res = await fetch('/.netlify/functions/stkpush', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoiceToken: invoice.publicToken,
          phone: payPhone,
          amountKes: invoice.balanceKes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not initiate payment.');
      }
      setActiveCheckoutId(data.checkoutRequestId);
      setPayMessage(data.customerMessage || 'STK push sent. Please enter your M-Pesa PIN.');
    } catch (err: any) {
      setPayError(err.message || 'Could not send STK push.');
    } finally {
      setPayLoading(false);
    }
  };

  const handleCompleteTestPayment = async () => {
    if (!activeCheckoutId || !invoice) return;
    setPayLoading(true);
    try {
      const res = await fetch('/.netlify/functions/mpesa-callback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          checkoutRequestId: activeCheckoutId,
          resultCode: 0,
          resultDesc: 'The service request is processed successfully.',
          amountKes: invoice.balanceKes,
          mpesaReceiptCode: `INV${Date.now().toString().slice(-7)}`,
        }),
      });
      if (res.ok && onRefreshDocument) {
        onRefreshDocument();
        setActiveCheckoutId(null);
        setPayMessage('Payment confirmed and receipt generated.');
      }
    } finally {
      setPayLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 overflow-y-auto">
      <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] w-full max-w-3xl shadow-xl my-8 overflow-hidden">
        {/* Top Action Bar (hidden when printing) */}
        <div className="no-print flex flex-wrap items-center justify-between gap-3 px-6 py-4 bg-[var(--bg-subtle)] border-b border-[var(--border-subtle)]">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[var(--brand-blue)]" />
            <span className="text-sm font-medium text-[var(--text-primary)]">
              {type === 'invoice'
                ? `Invoice ${invoice?.invoiceNumber || ''}`
                : `Receipt ${receipt?.receiptNumber || ''}`}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="inline-flex rounded-lg bg-[var(--bg-surface)] p-1 border border-[var(--border-subtle)]">
              <button
                type="button"
                onClick={() => setPrintFormat('a4')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  printFormat === 'a4'
                    ? 'bg-[var(--brand-blue)] text-white'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                A4 Page
              </button>
              <button
                type="button"
                onClick={() => setPrintFormat('80mm')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  printFormat === '80mm'
                    ? 'bg-[var(--brand-blue)] text-white'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                80mm Thermal
              </button>
            </div>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close document"
              className="p-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-6 sm:p-8 flex justify-center bg-[var(--bg-page)]">
          <div
            id="printable-document"
            className={`bg-white text-slate-900 border border-slate-200 rounded-[12px] p-6 sm:p-8 transition-all ${
              printFormat === '80mm' ? 'w-[302px] text-xs' : 'w-full max-w-2xl text-sm'
            }`}
          >
            {/* Document Header */}
            <div
              className={`flex ${
                printFormat === '80mm'
                  ? 'flex-col items-center text-center gap-2'
                  : 'flex-col sm:flex-row sm:items-start justify-between gap-4'
              } pb-5 border-b border-slate-200`}
            >
              <div>
                <Logo logoUrl={settings.logoUrl} businessName={settings.businessName} size="sm" />
                <p className="text-xs text-slate-600 mt-1">{settings.description}</p>
                <p className="text-xs text-slate-600 mt-0.5">
                  WhatsApp / Phone: {settings.whatsappDisplay}
                </p>
                {settings.email && settings.email !== '[add email here]' && (
                  <p className="text-xs text-slate-600 mt-0.5">Email: {settings.email}</p>
                )}
              </div>
              <div className={printFormat === '80mm' ? 'text-center mt-2' : 'sm:text-right'}>
                <p className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                  {type === 'invoice' ? 'Invoice' : 'Official Receipt'}
                </p>
                <p className="text-lg font-bold font-mono-tabular text-slate-900 mt-0.5">
                  {type === 'invoice' ? invoice?.invoiceNumber : receipt?.receiptNumber}
                </p>
                <p className="text-xs text-slate-500 font-mono-tabular">
                  Date:{' '}
                  {new Date(
                    (type === 'invoice' ? invoice?.createdAt : receipt?.issuedAt) || Date.now()
                  ).toLocaleDateString('en-KE', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </p>
              </div>
            </div>

            {/* INVOICE CONTENT */}
            {type === 'invoice' && invoice && (
              <div className="mt-5 space-y-5">
                <div className="flex flex-wrap justify-between gap-4 text-xs">
                  <div>
                    <p className="text-slate-500">Billed to</p>
                    <p className="font-semibold text-slate-900 mt-0.5">{invoice.customerName}</p>
                    <p className="font-mono-tabular text-slate-600">{invoice.customerPhoneMasked}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-slate-500">Status</p>
                    <p className="font-semibold text-slate-900 mt-0.5">{invoice.status}</p>
                    {invoice.dueDate && (
                      <p className="text-slate-600 font-mono-tabular">Due: {invoice.dueDate}</p>
                    )}
                  </div>
                </div>

                <div className="border-t border-b border-slate-200 py-3">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-xs text-slate-500">
                        <th className="py-2 font-medium">Description</th>
                        <th className="py-2 font-medium text-right">Qty</th>
                        {printFormat === 'a4' && (
                          <th className="py-2 font-medium text-right">Unit (KES)</th>
                        )}
                        <th className="py-2 font-medium text-right">Total (KES)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {invoice.items.map((item) => (
                        <tr key={item.id}>
                          <td className="py-2.5 pr-2 text-slate-900">{item.description}</td>
                          <td className="py-2.5 text-right font-mono-tabular text-slate-700">
                            {item.quantity}
                          </td>
                          {printFormat === 'a4' && (
                            <td className="py-2.5 text-right font-mono-tabular text-slate-700">
                              {item.unitPriceKes.toLocaleString()}
                            </td>
                          )}
                          <td className="py-2.5 text-right font-mono-tabular font-medium text-slate-900">
                            {item.lineTotalKes.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="space-y-1.5 text-xs ml-auto max-w-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal</span>
                    <span className="font-mono-tabular">
                      KES {invoice.subtotalKes.toLocaleString()}
                    </span>
                  </div>
                  {invoice.discountKes > 0 && (
                    <div className="flex justify-between text-slate-600">
                      <span>Discount</span>
                      <span className="font-mono-tabular">
                        - KES {invoice.discountKes.toLocaleString()}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between font-semibold text-slate-900 pt-1 border-t border-slate-200">
                    <span>Total</span>
                    <span className="font-mono-tabular">
                      KES {invoice.totalKes.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Paid</span>
                    <span className="font-mono-tabular">
                      KES {invoice.paidKes.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-900 pt-1 border-t border-slate-200">
                    <span>Balance Due</span>
                    <span className="font-mono-tabular">
                      KES {invoice.balanceKes.toLocaleString()}
                    </span>
                  </div>
                </div>

                {invoice.notes && (
                  <p className="text-xs text-slate-600 pt-3 border-t border-slate-200">
                    Note: {invoice.notes}
                  </p>
                )}
              </div>
            )}

            {/* RECEIPT CONTENT */}
            {type === 'receipt' && receipt && (
              <div className="mt-5 space-y-4 text-xs">
                <div className="grid grid-cols-2 gap-3 py-3 border-b border-slate-200">
                  <div>
                    <p className="text-slate-500">Received from</p>
                    <p className="font-semibold text-slate-900 mt-0.5">{receipt.customerName}</p>
                    <p className="font-mono-tabular text-slate-600">{receipt.customerPhoneMasked}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-slate-500">Order Reference</p>
                    <p className="font-semibold font-mono-tabular text-slate-900 mt-0.5">
                      {receipt.orderNumber}
                    </p>
                    {receipt.mpesaReceiptCode && (
                      <p className="font-mono-tabular text-slate-700 mt-0.5">
                        M-Pesa Ref: {receipt.mpesaReceiptCode}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-2 py-2 border-b border-slate-200">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Service</span>
                    <span className="font-medium text-slate-900 text-right">
                      {receipt.serviceDescription}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Payment Method</span>
                    <span className="text-slate-900">{receipt.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-100">
                    <span>Amount Paid</span>
                    <span className="font-mono-tabular">
                      KES {receipt.amountKes.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Balance Remaining</span>
                    <span className="font-mono-tabular">
                      KES {receipt.balanceAfterKes.toLocaleString()}
                    </span>
                  </div>
                </div>

                <p className="text-center text-slate-500 pt-2">
                  Thank you for working with {settings.businessName}.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* M-Pesa Payment Box for Unpaid Invoices (hidden when printing) */}
        {type === 'invoice' && invoice && invoice.balanceKes > 0 && (
          <div className="no-print px-6 py-5 bg-[var(--bg-subtle)] border-t border-[var(--border-subtle)]">
            <form
              onSubmit={handlePayInvoiceStk}
              className="flex flex-col sm:flex-row sm:items-end gap-3"
            >
              <div className="flex-1">
                <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                  Pay Invoice Balance (KES {invoice.balanceKes.toLocaleString()}) via M-Pesa STK Push
                </label>
                <input
                  type="tel"
                  required
                  placeholder="Enter M-Pesa number e.g. 0712 345 678"
                  value={payPhone}
                  onChange={(e) => setPayPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-[var(--text-primary)]"
                />
              </div>
              <button
                type="submit"
                disabled={payLoading}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors whitespace-nowrap disabled:opacity-50"
              >
                <Smartphone className="w-4 h-4" />
                {payLoading ? 'Sending prompt...' : `Pay KES ${invoice.balanceKes.toLocaleString()}`}
              </button>
            </form>

            {payError && <p className="text-xs text-red-600 mt-2">{payError}</p>}
            {payMessage && (
              <div className="mt-3 p-3 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs text-[var(--text-primary)] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  {payMessage}
                </span>
                {activeCheckoutId && (
                  <button
                    type="button"
                    onClick={handleCompleteTestPayment}
                    className="px-3 py-1.5 text-xs font-medium text-white bg-[var(--brand-blue)] rounded-md"
                  >
                    Simulate M-Pesa PIN Confirmation
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
