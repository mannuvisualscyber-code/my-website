import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import {
  MessageSquare,
  Phone,
  Mail,
  Clock,
  CreditCard,
  Search,
  Upload,
  CheckCircle2,
  AlertCircle,
  Download,
  FileText,
  Smartphone,
  ShieldAlert,
  ExternalLink,
  X,
  Menu,
  Lock,
  ChevronLeft,
  ChevronRight,
  Share2,
  SlidersHorizontal,
  Copy,
} from 'lucide-react';
import { Logo } from './components/Logo.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { AdminPanel } from './components/AdminPanel.tsx';
import { TicketCard } from './components/TicketCard.tsx';
import {
  PublicDocumentModal,
  PublicInvoiceView,
  PublicReceiptView,
} from './components/PublicDocumentModal.tsx';

type ServiceCategory = 'government' | 'graphic_design' | 'other';

export const MANNU_CAST_PRO_URL =
  'https://[PASTE THE EXACT ADDRESS HERE, e.g. mannu-cast-pro.ai.studio]';

const TRACKING_STEPS = [
  'Received',
  'Price confirmed',
  'Paid',
  'In progress',
  'Ready',
  'Delivered',
] as const;

const DEFAULT_WORK_CATEGORIES = [
  { name: 'Wedding cards', slug: 'wedding-cards' },
  { name: 'Funeral programs', slug: 'funeral-programs' },
  { name: 'Posters and flyers', slug: 'posters-and-flyers' },
  { name: 'Logos', slug: 'logos' },
  { name: 'Birthday cards', slug: 'birthday-cards' },
  { name: 'Church posters', slug: 'church-posters' },
  { name: 'Company profiles', slug: 'company-profiles' },
  { name: 'Social media banners', slug: 'social-media-banners' },
] as const;

export interface PublicPortfolioImage {
  id: string;
  thumbUrl: string;
  mediumUrl: string;
  publicUrl: string;
  width: number;
  height: number;
  altText: string;
  sortOrder: number;
  isCover: boolean;
}

export interface PublicPortfolioItem {
  id: string;
  slug: string;
  title: string;
  description: string;
  categoryId: string;
  categoryName: string;
  categorySlug: string;
  tags: string[];
  clientLabel: string | null;
  projectDate: string;
  isSample: boolean;
  watermark: boolean;
  featured: boolean;
  sortOrder: number;
  coverImage: PublicPortfolioImage | null;
  images: PublicPortfolioImage[];
}

export default function App() {
  const [isAdminRoute, setIsAdminRoute] = useState<boolean>(() =>
    window.location.pathname.startsWith('/admin')
  );
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeNavSection, setActiveNavSection] = useState<string>('');

  // Public site bootstrap state
  const [settings, setSettings] = useState({
    businessName: 'Mannu Visuals',
    description: 'Online cyber and graphic design services. All work is done online.',
    whatsappDisplay: '0796 431 953',
    whatsappWaMe: '254796431953',
    facebookLink: 'Mannu Visuals KE (TikTok, Facebook, Instagram and YouTube)',
    email: 'mannuvisualscyber@gmail.com',
    workingHours: '[add hours here]',
    mpesaTillOrPaybill: 'M-Pesa [Till/Paybill number to be added]',
    mpesaTransactionType: 'CustomerPayBillOnline',
    logoUrl: '/logo.svg',
  });
  const [services, setServices] = useState<any[]>([]);

  // Portfolio (#work section) state
  const [portfolioCategories, setPortfolioCategories] = useState<
    { id?: string; name: string; slug: string }[]
  >(() => [...DEFAULT_WORK_CATEGORIES]);
  const [portfolioItems, setPortfolioItems] = useState<PublicPortfolioItem[]>([]);
  const [activeCategorySlug, setActiveCategorySlug] = useState<string>('all');
  const [visibleWorkCount, setVisibleWorkCount] = useState<number>(9);

  // Full-screen Viewer (Lightbox) state
  const [viewerItem, setViewerItem] = useState<PublicPortfolioItem | null>(null);
  const [viewerImageIndex, setViewerImageIndex] = useState<number>(0);
  const [viewerCompareMode, setViewerCompareMode] = useState<boolean>(false);
  const [viewerSliderPos, setViewerSliderPos] = useState<number>(50);
  const [shareCopied, setShareCopied] = useState<boolean>(false);

  const viewerModalRef = useRef<HTMLDivElement | null>(null);
  const tileRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const lastFocusedSlugRef = useRef<string | null>(null);
  const touchStartXRef = useRef<number | null>(null);

  // Active service tab
  const [activeServiceTab, setActiveServiceTab] = useState<ServiceCategory>('government');

  // Smart Order Form state
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [orderCategory, setOrderCategory] = useState<ServiceCategory>('government');
  const [orderServiceName, setOrderServiceName] = useState('eCitizen Services');
  const [orderDetails, setOrderDetails] = useState('');
  const [orderDeadline, setOrderDeadline] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState<'WhatsApp' | 'Email' | 'Download link'>(
    'WhatsApp'
  );
  const [paymentPreference, setPaymentPreference] = useState<'mpesa_stk' | 'pay_later'>(
    'mpesa_stk'
  );

  // Conditional Government fields
  const [portalName, setPortalName] = useState('eCitizen');
  const [helpNeeded, setHelpNeeded] = useState('');

  // Conditional Graphic Design fields
  const [designType, setDesignType] = useState('Wedding cards');
  const [exactText, setExactText] = useState('');
  const [eventDetails, setEventDetails] = useState('');
  const [colourPreferences, setColourPreferences] = useState('');
  const [sizeOrFormat, setSizeOrFormat] = useState<'Print' | 'Social media'>('Print');
  const [hasExtraWhatsappFiles, setHasExtraWhatsappFiles] = useState(true);

  // Conditional Other / CV / Typing fields
  const [documentType, setDocumentType] = useState('CV writing');
  const [pageCount, setPageCount] = useState('1 - 2 pages');
  const [documentLanguage, setDocumentLanguage] = useState('English');

  // Optional file uploads (max 5 files, up to 10 MB each)
  const [attachedFiles, setAttachedFiles] = useState<
    { fileName: string; mimeType: string; sizeBytes: number; dataUrl: string }[]
  >([]);
  const [submittingOrder, setSubmittingOrder] = useState(false);
  const [orderFormError, setOrderFormError] = useState<string | null>(null);
  const [submittedOrderConfirmation, setSubmittedOrderConfirmation] = useState<{
    orderNumber: string;
    ticketNumber?: string;
    whatsappUrl: string;
    trackingUrl: string;
    verifyUrl?: string;
    order?: any;
  } | null>(null);

  // Track Order & Public Ticket Verification state
  const [trackInput, setTrackInput] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<any | null>(null);
  const [trackLoading, setTrackLoading] = useState(false);
  const [trackError, setTrackError] = useState<string | null>(null);
  const [verifiedTicketBanner, setVerifiedTicketBanner] = useState<{
    valid: boolean;
    ticketNumber: string;
    verifiedAt: string;
  } | null>(null);

  // Track Order M-Pesa STK Push state
  const [stkPhone, setStkPhone] = useState('');
  const [stkLoading, setStkLoading] = useState(false);
  const [stkError, setStkError] = useState<string | null>(null);
  const [stkActiveCheckout, setStkActiveCheckout] = useState<{
    checkoutRequestId: string;
    amountKes: number;
    message: string;
  } | null>(null);

  // Public Invoice / Receipt Modal state
  const [publicDocModal, setPublicDocModal] = useState<{
    type: 'invoice' | 'receipt';
    token: string;
    invoice?: PublicInvoiceView;
    receipt?: PublicReceiptView;
  } | null>(null);

  // Contact quick WhatsApp message form
  const [contactName, setContactName] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  // Fetch public bootstrap + full portfolio list from Netlify Functions
  const fetchPublicBootstrap = useCallback(async () => {
    try {
      const [bootRes, portRes] = await Promise.all([
        fetch('/.netlify/functions/order-status?action=bootstrap'),
        fetch('/.netlify/functions/portfolio-list?category=all&limit=200&offset=0'),
      ]);

      if (bootRes.ok) {
        const data = await bootRes.json();
        if (data.settings) setSettings(data.settings);
        if (data.services) setServices(data.services);
        if (data.portfolioCategories?.length > 0) {
          setPortfolioCategories(data.portfolioCategories);
        }
      }

      if (portRes.ok) {
        const portData = await portRes.json();
        if (portData.categories?.length > 0) {
          setPortfolioCategories(portData.categories);
        }
        if (Array.isArray(portData.items)) {
          setPortfolioItems(portData.items);
        }
      }
    } catch {
      // Fallback defaults already populated
    }
  }, []);

  const lookupOrderByNumber = useCallback(async (orderNum: string) => {
    const clean = orderNum.trim().toUpperCase();
    if (!clean) return;
    setTrackLoading(true);
    setTrackError(null);
    try {
      const res = await fetch(
        `/.netlify/functions/order-status?order=${encodeURIComponent(clean)}`
      );
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || `Order ${clean} was not found.`);
      }
      setTrackedOrder(data.order);
      setStkActiveCheckout(null);
    } catch (err: any) {
      setTrackedOrder(null);
      setTrackError(err.message || 'Could not find that order number.');
    } finally {
      setTrackLoading(false);
    }
  }, []);

  const loadPublicDocumentByToken = useCallback(
    async (type: 'invoice' | 'receipt', token: string) => {
      try {
        const param = type === 'invoice' ? `invoice=${token}` : `receipt=${token}`;
        const res = await fetch(`/.netlify/functions/order-status?${param}`);
        if (res.ok) {
          const data = await res.json();
          setPublicDocModal({
            type,
            token,
            invoice: data.invoice,
            receipt: data.receipt,
          });
        }
      } catch {
        // Ignore invalid token
      }
    },
    []
  );

  // Normalise any legacy /portfolio or /portfolio/<slug> URL to main page #work or #work/<slug>
  useEffect(() => {
    const path = window.location.pathname;
    if (path === '/portfolio' || path.startsWith('/portfolio/')) {
      const maybeSlug = path.slice('/portfolio/'.length).trim();
      const targetHash = maybeSlug ? `#work/${maybeSlug}` : '#work';
      window.history.replaceState(null, '', `/${targetHash}`);
    }
  }, []);

  useEffect(() => {
    fetchPublicBootstrap();

    const params = new URLSearchParams(window.location.search);
    const orderParam = params.get('order');
    const ticketParam = params.get('ticket');
    const invoiceParam = params.get('invoice');
    const receiptParam = params.get('receipt');

    if (ticketParam && !window.location.pathname.startsWith('/admin')) {
      const cleanTkt = ticketParam.trim().toUpperCase();
      setTrackInput(cleanTkt);
      setTrackLoading(true);
      fetch(`/.netlify/functions/verify-ticket?ticket=${encodeURIComponent(cleanTkt)}`)
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
          if (ok && data.ticket) {
            setVerifiedTicketBanner({
              valid: Boolean(data.valid),
              ticketNumber: data.ticket.ticketNumber,
              verifiedAt: data.verifiedAt || new Date().toISOString(),
            });
            setTrackedOrder({
              ...data.ticket,
              status: data.ticket.orderStatus || 'Received',
            });
            lookupOrderByNumber(data.ticket.orderNumber || cleanTkt);
          } else {
            setTrackError(data.error || `Ticket ${cleanTkt} could not be verified.`);
          }
        })
        .catch(() => {
          lookupOrderByNumber(cleanTkt);
        })
        .finally(() => {
          setTrackLoading(false);
          setTimeout(() => {
            document.getElementById('track-order')?.scrollIntoView({ behavior: 'smooth' });
          }, 250);
        });
    } else if (orderParam) {
      setTrackInput(orderParam.toUpperCase());
      lookupOrderByNumber(orderParam);
      setTimeout(() => {
        document.getElementById('track-order')?.scrollIntoView({ behavior: 'smooth' });
      }, 250);
    }
    if (invoiceParam) {
      loadPublicDocumentByToken('invoice', invoiceParam);
    } else if (receiptParam) {
      loadPublicDocumentByToken('receipt', receiptParam);
    }

    const handlePopState = () => {
      setIsAdminRoute(window.location.pathname.startsWith('/admin'));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [fetchPublicBootstrap, lookupOrderByNumber, loadPublicDocumentByToken]);

  // Synchronise #work/<slug> hash with the full-screen Lightbox viewer
  useEffect(() => {
    const syncHashWithViewer = async () => {
      const hash = window.location.hash || '';
      if (hash.startsWith('#work/')) {
        const slug = decodeURIComponent(hash.slice('#work/'.length).trim());
        if (!slug) return;
        const foundLocal = portfolioItems.find((i) => i.slug === slug);
        if (foundLocal) {
          setViewerItem(foundLocal);
          setViewerImageIndex(0);
          setViewerCompareMode(false);
          return;
        }
        try {
          const res = await fetch(
            `/.netlify/functions/portfolio-list?slug=${encodeURIComponent(slug)}`
          );
          if (res.ok) {
            const data = await res.json();
            if (data.linkedItem || data.item) {
              setViewerItem(data.linkedItem || data.item);
              setViewerImageIndex(0);
              setViewerCompareMode(false);
            }
          }
        } catch {
          // Ignore network error
        }
      } else if (hash === '#work') {
        setViewerItem(null);
      }
    };

    syncHashWithViewer();
    window.addEventListener('hashchange', syncHashWithViewer);
    return () => window.removeEventListener('hashchange', syncHashWithViewer);
  }, [portfolioItems]);

  // IntersectionObserver to highlight active navigation link (#services, #work, #order, #track-order, #contact)
  useEffect(() => {
    if (isAdminRoute) return;
    const sectionIds = ['services', 'work', 'order', 'track-order', 'contact'];
    const elements = sectionIds
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));

    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visibleEntries = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visibleEntries.length > 0) {
          setActiveNavSection(visibleEntries[0].target.id);
        }
      },
      {
        rootMargin: '-20% 0px -55% 0px',
        threshold: [0.1, 0.25, 0.5],
      }
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [isAdminRoute]);

  // Filtered and ordered portfolio items inside #work
  const filteredPortfolioItems = useMemo(() => {
    const matching =
      activeCategorySlug === 'all'
        ? [...portfolioItems]
        : portfolioItems.filter(
            (item) =>
              item.categorySlug === activeCategorySlug ||
              item.categoryName.toLowerCase() === activeCategorySlug.toLowerCase()
          );

    // When "All" is selected, show Featured items first, then sortOrder
    return matching.sort((a, b) => {
      if (activeCategorySlug === 'all' && a.featured !== b.featured) {
        return a.featured ? -1 : 1;
      }
      if (a.sortOrder !== b.sortOrder) {
        return a.sortOrder - b.sortOrder;
      }
      return b.projectDate.localeCompare(a.projectDate);
    });
  }, [portfolioItems, activeCategorySlug]);

  const displayedPortfolioItems = useMemo(
    () => filteredPortfolioItems.slice(0, visibleWorkCount),
    [filteredPortfolioItems, visibleWorkCount]
  );

  const openPortfolioViewer = useCallback((item: PublicPortfolioItem) => {
    lastFocusedSlugRef.current = item.slug;
    setViewerItem(item);
    setViewerImageIndex(0);
    setViewerCompareMode(false);
    setViewerSliderPos(50);
    setShareCopied(false);
    window.history.replaceState(
      null,
      '',
      `${window.location.pathname}${window.location.search}#work/${item.slug}`
    );
  }, []);

  const closePortfolioViewer = useCallback(() => {
    const slugToRestore = lastFocusedSlugRef.current;
    setViewerItem(null);
    setViewerCompareMode(false);
    if (window.location.hash.startsWith('#work/')) {
      window.history.replaceState(
        null,
        '',
        `${window.location.pathname}${window.location.search}`
      );
    }
    if (slugToRestore) {
      window.setTimeout(() => {
        tileRefs.current[slugToRestore]?.focus();
      }, 20);
    }
  }, []);

  const navigateViewerProject = useCallback(
    (direction: 'prev' | 'next') => {
      if (!viewerItem || filteredPortfolioItems.length <= 1) return;
      const currentIndex = filteredPortfolioItems.findIndex((i) => i.id === viewerItem.id);
      const baseIndex = currentIndex >= 0 ? currentIndex : 0;
      const nextIndex =
        direction === 'next'
          ? (baseIndex + 1) % filteredPortfolioItems.length
          : (baseIndex - 1 + filteredPortfolioItems.length) % filteredPortfolioItems.length;
      const nextItem = filteredPortfolioItems[nextIndex];
      if (nextItem) {
        setViewerItem(nextItem);
        setViewerImageIndex(0);
        setViewerCompareMode(false);
        setViewerSliderPos(50);
        window.history.replaceState(
          null,
          '',
          `${window.location.pathname}${window.location.search}#work/${nextItem.slug}`
        );
      }
    },
    [viewerItem, filteredPortfolioItems]
  );

  // Stop background page from scrolling & trap keyboard focus while viewer is open
  useEffect(() => {
    if (!viewerItem) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    // Focus the modal container or close button when opened
    const timer = window.setTimeout(() => {
      const firstBtn = viewerModalRef.current?.querySelector<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      firstBtn?.focus();
    }, 10);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        closePortfolioViewer();
        return;
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        navigateViewerProject('next');
        return;
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        navigateViewerProject('prev');
        return;
      }
      if (e.key === 'Tab' && viewerModalRef.current) {
        const focusable = Array.from(
          viewerModalRef.current.querySelectorAll<HTMLElement>(
            'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
          )
        );
        if (focusable.length === 0) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.clearTimeout(timer);
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [viewerItem, closePortfolioViewer, navigateViewerProject]);

  const handleOrderSimilarDesign = (item: PublicPortfolioItem) => {
    const catName = item.categoryName || 'Wedding cards';
    let matchedServiceName = catName;
    if (catName.toLowerCase().includes('funeral')) {
      matchedServiceName = 'Eulogies and funeral programs';
    } else if (catName.toLowerCase().includes('logo')) {
      matchedServiceName = 'Business logos';
    }

    setOrderCategory('graphic_design');
    setOrderServiceName(matchedServiceName);
    setDesignType(catName);
    setOrderDetails((prev) => {
      const refLine = `Similar to portfolio design: "${item.title}" (${catName}).`;
      return prev ? `${refLine}\n${prev}` : refLine;
    });

    closePortfolioViewer();
    window.setTimeout(() => {
      document.getElementById('order')?.scrollIntoView({ behavior: 'smooth' });
    }, 60);
  };

  const handleSharePortfolioItem = async (item: PublicPortfolioItem) => {
    const shareUrl = `${window.location.origin}/#work/${item.slug}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${item.title} — ${settings.businessName}`,
          text: `${item.title} (${item.categoryName}) by ${settings.businessName}`,
          url: shareUrl,
        });
        return;
      } catch {
        // Fallback to clipboard copy if user cancels or share fails
      }
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      setShareCopied(true);
      window.setTimeout(() => setShareCopied(false), 3000);
    } catch {
      // Ignore clipboard error
    }
  };

  const navigateToAdmin = () => {
    window.history.pushState({}, '', '/admin');
    setIsAdminRoute(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToPublicSite = () => {
    window.history.pushState({}, '', '/');
    setIsAdminRoute(false);
    fetchPublicBootstrap();
  };

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, sectionId: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    setActiveNavSection(sectionId);
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      window.history.replaceState(null, '', `#${sectionId}`);
    }
  };

  const handleSelectServiceToOrder = (category: ServiceCategory, serviceName: string) => {
    setOrderCategory(category);
    setOrderServiceName(serviceName);
    if (category === 'government') {
      if (serviceName.toLowerCase().includes('kra')) setPortalName('KRA');
      else if (serviceName.toLowerCase().includes('kuccps')) setPortalName('KUCCPS');
      else if (serviceName.toLowerCase().includes('helb')) setPortalName('HELB');
      else setPortalName('eCitizen');
    } else if (category === 'graphic_design') {
      setDesignType(serviceName);
    } else {
      setDocumentType(serviceName);
    }
    document.getElementById('order')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleFileAttachmentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList) return;
    setOrderFormError(null);

    const selected = Array.from(fileList);
    if (attachedFiles.length + selected.length > 5) {
      setOrderFormError('You can attach a maximum of 5 files per order.');
      return;
    }

    selected.forEach((file) => {
      if (file.size > 10 * 1024 * 1024) {
        setOrderFormError(`File "${file.name}" is larger than 10 MB.`);
        return;
      }
      if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
        setOrderFormError(`File "${file.name}" must be an image or a PDF document.`);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedFiles((prev) =>
          prev.length < 5
            ? [
                ...prev,
                {
                  fileName: file.name,
                  mimeType: file.type,
                  sizeBytes: file.size,
                  dataUrl: String(reader.result),
                },
              ]
            : prev
        );
      };
      reader.readAsDataURL(file);
    });
  };

  const handleOrderFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submittingOrder) return;
    setOrderFormError(null);
    setSubmittingOrder(true);

    try {
      const res = await fetch('/.netlify/functions/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName,
          customerPhone,
          customerEmail: customerEmail || undefined,
          serviceCategory: orderCategory,
          serviceName: orderServiceName,
          details: orderDetails,
          deadline: orderDeadline || undefined,
          deliveryMethod,
          paymentPreference,
          portalName: orderCategory === 'government' ? portalName : undefined,
          helpNeeded: orderCategory === 'government' ? helpNeeded : undefined,
          designType: orderCategory === 'graphic_design' ? designType : undefined,
          exactText: orderCategory === 'graphic_design' ? exactText : undefined,
          eventDetails: orderCategory === 'graphic_design' ? eventDetails : undefined,
          colourPreferences: orderCategory === 'graphic_design' ? colourPreferences : undefined,
          sizeOrFormat: orderCategory === 'graphic_design' ? sizeOrFormat : undefined,
          hasExtraWhatsappFiles:
            orderCategory === 'graphic_design' ? hasExtraWhatsappFiles : undefined,
          documentType: orderCategory === 'other' ? documentType : undefined,
          pageCount: orderCategory === 'other' ? pageCount : undefined,
          documentLanguage: orderCategory === 'other' ? documentLanguage : undefined,
          files: attachedFiles,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not submit your order. Please check your entries.');
      }

      setSubmittedOrderConfirmation({
        orderNumber: data.orderNumber,
        ticketNumber: data.ticketNumber || data.order?.ticketNumber,
        whatsappUrl: data.whatsappUrl,
        trackingUrl: data.trackingUrl,
        verifyUrl: data.verifyUrl || data.order?.verifyUrl,
        order: data.order,
      });
      setTrackInput(data.orderNumber);
      setTrackedOrder(data.order);
      setAttachedFiles([]);
    } catch (err: any) {
      setOrderFormError(err.message || 'Could not submit your order.');
    } finally {
      setSubmittingOrder(false);
    }
  };

  const handleTrackOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    lookupOrderByNumber(trackInput);
  };

  const handleTrackOrderStkPush = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackedOrder) return;
    setStkError(null);
    setStkLoading(true);
    try {
      const res = await fetch('/.netlify/functions/stkpush', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderNumber: trackedOrder.orderNumber,
          phone: stkPhone,
          amountKes: trackedOrder.balanceKes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not initiate M-Pesa payment.');
      }
      setStkActiveCheckout({
        checkoutRequestId: data.checkoutRequestId,
        amountKes: data.amountKes,
        message: data.customerMessage,
      });
    } catch (err: any) {
      setStkError(err.message || 'Could not send M-Pesa prompt.');
    } finally {
      setStkLoading(false);
    }
  };

  // Poll /.netlify/functions/payment-status by checkout_request_id to show success, cancelled or failed
  useEffect(() => {
    if (!stkActiveCheckout || !trackedOrder) return;
    const interval = window.setInterval(async () => {
      try {
        const res = await fetch(
          `/.netlify/functions/payment-status?checkoutRequestId=${encodeURIComponent(
            stkActiveCheckout.checkoutRequestId
          )}`
        );
        if (!res.ok) return;
        const data = await res.json();
        const st = data.payment?.status;
        if (st === 'SUCCESS') {
          await lookupOrderByNumber(trackedOrder.orderNumber);
          setStkActiveCheckout(null);
        } else if (st === 'CANCELLED') {
          setStkError('M-Pesa payment was cancelled on your phone.');
          setStkActiveCheckout(null);
        } else if (st === 'FAILED') {
          setStkError(data.payment?.resultDesc || 'M-Pesa payment could not be completed.');
          setStkActiveCheckout(null);
        }
      } catch {
        // Ignore transient network poll error
      }
    }, 4000);
    return () => window.clearInterval(interval);
  }, [stkActiveCheckout, trackedOrder, lookupOrderByNumber]);

  const handleConfirmSandboxStkPayment = async () => {
    if (!stkActiveCheckout || !trackedOrder) return;
    setStkLoading(true);
    try {
      const res = await fetch('/.netlify/functions/mpesa-callback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          checkoutRequestId: stkActiveCheckout.checkoutRequestId,
          resultCode: 0,
          resultDesc: 'The service request is processed successfully.',
          amountKes: stkActiveCheckout.amountKes,
          mpesaReceiptCode: `MPE${Date.now().toString().slice(-7)}`,
        }),
      });
      if (res.ok) {
        await lookupOrderByNumber(trackedOrder.orderNumber);
        setStkActiveCheckout(null);
      }
    } finally {
      setStkLoading(false);
    }
  };

  if (isAdminRoute) {
    return (
      <AdminPanel
        onBackToSite={navigateToPublicSite}
        onPublicDataChanged={fetchPublicBootstrap}
      />
    );
  }

  const servicesForActiveTab = services.filter((s) => s.category === activeServiceTab);
  const categoryServicesList = services.filter((s) => s.category === orderCategory);

  const navLinkClass = (sectionId: string) =>
    `transition-colors whitespace-nowrap py-1 border-b-2 ${
      activeNavSection === sectionId
        ? 'text-[var(--brand-blue)] border-[var(--brand-blue)] font-semibold'
        : 'text-[var(--text-secondary)] border-transparent hover:text-[var(--text-primary)]'
    }`;

  const activeViewerImages = viewerItem?.images || [];
  const currentViewerImage =
    activeViewerImages[viewerImageIndex] ||
    viewerItem?.coverImage ||
    activeViewerImages[0] ||
    null;

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg-page)] text-[var(--text-primary)]">
      {/* =================================================================== */}
      {/* 1. HEADER (Strict 3-Zone Top Bar Contract)                          */}
      {/* =================================================================== */}
      <header className="sticky top-0 z-30 bg-[var(--bg-surface)]/95 backdrop-blur border-b border-[var(--border-subtle)]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Zone 1: Brand */}
          <a href="#" className="shrink-0">
            <Logo logoUrl={settings.logoUrl} businessName={settings.businessName} size="md" />
          </a>

          {/* Zone 2: 5 clean navigation links (Portfolio -> #work) */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium"
          >
            <a
              href="#services"
              onClick={(e) => scrollToSection(e, 'services')}
              className={navLinkClass('services')}
            >
              Services
            </a>
            <a
              href="#work"
              onClick={(e) => scrollToSection(e, 'work')}
              className={navLinkClass('work')}
            >
              Portfolio
            </a>
            <a
              href="#order"
              onClick={(e) => scrollToSection(e, 'order')}
              className={navLinkClass('order')}
            >
              Order
            </a>
            <a
              href="#track-order"
              onClick={(e) => scrollToSection(e, 'track-order')}
              className={navLinkClass('track-order')}
            >
              Track order
            </a>
            <a
              href="#contact"
              onClick={(e) => scrollToSection(e, 'contact')}
              className={navLinkClass('contact')}
            >
              Contact
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-2">
            <a
              href="#order"
              onClick={(e) => scrollToSection(e, 'order')}
              className="px-4 py-2.5 text-xs sm:text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Order now
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle navigation menu"
              className="md:hidden p-2.5 rounded-lg text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <nav
            aria-label="Mobile Navigation"
            className="md:hidden px-4 pt-2 pb-4 bg-[var(--bg-surface)] border-b border-[var(--border-subtle)] flex flex-col gap-1.5 text-sm font-medium"
          >
            {[
              { id: 'services', label: 'Services' },
              { id: 'work', label: 'Portfolio' },
              { id: 'order', label: 'Order' },
              { id: 'track-order', label: 'Track order' },
              { id: 'contact', label: 'Contact' },
            ].map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => scrollToSection(e, item.id)}
                className={`py-2.5 px-3 rounded-lg transition-colors ${
                  activeNavSection === item.id
                    ? 'bg-[var(--bg-subtle)] text-[var(--brand-blue)] font-semibold'
                    : 'text-[var(--text-secondary)] hover:bg-[var(--bg-subtle)]'
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>
        )}
      </header>

      <main className="flex-1">
        {/* ================================================================= */}
        {/* 2. HERO SECTION (Subtle Animated Studio Motion Background)        */}
        {/* ================================================================= */}
        <HeroSection
          businessName={settings.businessName}
          logoUrl={settings.logoUrl}
          whatsappWaMe={settings.whatsappWaMe}
          onOrderClick={(e) => scrollToSection(e, 'order')}
        />

        {/* ================================================================= */}
        {/* 3. SERVICES SECTION                                               */}
        {/* ================================================================= */}
        <section id="services" className="py-16 sm:py-20 px-4 sm:px-6 max-w-6xl mx-auto space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-heading font-bold text-[var(--text-primary)]">
                Services
              </h2>
              <p className="text-sm text-[var(--text-secondary)] mt-1">
                All work is done online. Select a service below to start your request.
              </p>
            </div>

            {/* Interactive Service Category Tabs */}
            <div
              role="tablist"
              aria-label="Service categories"
              className="inline-flex p-1 rounded-xl bg-[var(--bg-subtle)] border border-[var(--border-subtle)] self-start overflow-x-auto max-w-full"
            >
              {[
                { id: 'government', label: 'Government services' },
                { id: 'graphic_design', label: 'Graphic design' },
                { id: 'other', label: 'Other services' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={activeServiceTab === tab.id}
                  type="button"
                  onClick={() => setActiveServiceTab(tab.id as ServiceCategory)}
                  className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap min-h-[40px] ${
                    activeServiceTab === tab.id
                      ? 'bg-[var(--bg-surface)] text-[var(--text-primary)] shadow-xs'
                      : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Government Services Plain-Text Partner Disclaimer */}
          {activeServiceTab === 'government' && (
            <div className="p-4 rounded-[12px] bg-[var(--bg-surface)] border border-[var(--border-subtle)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[var(--text-secondary)]">
              <div className="flex items-center flex-wrap gap-2">
                <span className="font-semibold text-[var(--text-primary)]">Portals supported:</span>
                <span>eCitizen</span>
                <span aria-hidden="true">·</span>
                <span>KRA</span>
                <span aria-hidden="true">·</span>
                <span>KUCCPS</span>
                <span aria-hidden="true">·</span>
                <span>HELB</span>
                <span aria-hidden="true">·</span>
                <span>TIMS</span>
                <span aria-hidden="true">·</span>
                <span>SHA</span>
                <span aria-hidden="true">·</span>
                <span>NHIF</span>
                <span aria-hidden="true">·</span>
                <span>NSSF</span>
              </div>
              <p className="text-[var(--text-secondary)] font-medium">
                We help you with the online steps. We are not part of these government offices.
              </p>
            </div>
          )}

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {servicesForActiveTab.map((srv) => (
              <div
                key={srv.id}
                className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 flex flex-col justify-between gap-5 shadow-[var(--shadow-soft)]"
              >
                <div className="space-y-2.5">
                  {srv.partnerLabel && (
                    <p className="text-xs font-medium text-[var(--brand-blue)]">
                      {srv.partnerLabel}
                    </p>
                  )}
                  <h3 className="text-base font-heading font-semibold text-[var(--text-primary)]">
                    {srv.name}
                  </h3>
                  <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                    {srv.description}
                  </p>
                  {srv.items && srv.items.length > 0 && (
                    <ul className="pt-2 space-y-1.5 text-xs text-[var(--text-secondary)] border-t border-[var(--border-subtle)]">
                      {srv.items.map((item: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-[var(--brand-blue)] select-none">-</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => handleSelectServiceToOrder(srv.category, srv.name)}
                  className="w-full py-2.5 px-4 text-xs font-medium text-[var(--text-primary)] bg-[var(--bg-subtle)] hover:bg-[var(--brand-red)] hover:text-white rounded-lg transition-colors whitespace-nowrap min-h-[42px]"
                >
                  Order this
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* ================================================================= */}
        {/* 4. PORTFOLIO SECTION (#work) — Placed after Services, before Order */}
        {/* ================================================================= */}
        <section
          id="work"
          aria-labelledby="work-heading"
          className="py-16 sm:py-20 px-4 sm:px-6 border-t border-[var(--border-subtle)] bg-[var(--bg-surface)] scroll-mt-16"
        >
          <div className="max-w-6xl mx-auto space-y-8">
            <div className="space-y-2">
              <h2
                id="work-heading"
                className="text-2xl sm:text-3xl font-heading font-bold text-[var(--text-primary)]"
              >
                Our work
              </h2>
              <p className="text-sm text-[var(--text-secondary)]">
                Samples of designs we have made for clients.
              </p>
            </div>

            {/* Horizontally Scrolling Filter Chips Row */}
            <div
              role="tablist"
              aria-label="Filter designs by category"
              className="flex items-center gap-2 overflow-x-auto pb-2 -mx-1 px-1 no-scrollbar"
            >
              <button
                type="button"
                role="tab"
                aria-selected={activeCategorySlug === 'all'}
                onClick={() => {
                  setActiveCategorySlug('all');
                  setVisibleWorkCount(9);
                }}
                className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 min-h-[40px] ${
                  activeCategorySlug === 'all'
                    ? 'bg-[var(--brand-blue)] text-white border-[var(--brand-blue)]'
                    : 'bg-[var(--bg-page)] text-[var(--text-secondary)] border-[var(--border-subtle)] hover:text-[var(--text-primary)] hover:border-slate-300'
                }`}
              >
                All
              </button>

              {portfolioCategories.map((cat) => {
                const isSelected = activeCategorySlug === cat.slug;
                return (
                  <button
                    key={cat.slug}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    onClick={() => {
                      setActiveCategorySlug(cat.slug);
                      setVisibleWorkCount(9);
                    }}
                    className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 min-h-[40px] ${
                      isSelected
                        ? 'bg-[var(--brand-blue)] text-white border-[var(--brand-blue)]'
                        : 'bg-[var(--bg-page)] text-[var(--text-secondary)] border-[var(--border-subtle)] hover:text-[var(--text-primary)] hover:border-slate-300'
                    }`}
                  >
                    {cat.name}
                  </button>
                );
              })}
            </div>

            {/* Friendly Empty State when there is nothing yet */}
            {filteredPortfolioItems.length === 0 ? (
              <div className="p-10 sm:p-12 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] text-center max-w-xl mx-auto space-y-4">
                <p className="text-sm sm:text-base font-medium text-[var(--text-primary)] leading-relaxed">
                  Our work will be added here soon. Chat with us on WhatsApp to see samples.
                </p>
                <div>
                  <a
                    href={`https://wa.me/${settings.whatsappWaMe}?text=${encodeURIComponent(
                      'Hello Mannu Visuals, please share design samples with me.'
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-5 py-2.5 text-xs sm:text-sm font-medium text-white bg-[var(--brand-blue)] hover:bg-[var(--brand-blue-hover)] rounded-lg inline-flex items-center gap-2 min-h-[42px]"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Chat on WhatsApp
                  </a>
                </div>
              </div>
            ) : (
              <>
                {/* Responsive Grid: 1 col at 360px, 2 on tablets, 3 or 4 on desktop */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 items-start">
                  {displayedPortfolioItems.map((item) => {
                    const cover = item.coverImage || item.images?.[0];
                    const imgW = cover?.width || 800;
                    const imgH = cover?.height || 600;
                    const thumbSrc = cover?.thumbUrl || cover?.publicUrl || '/logo.svg';
                    const altText = cover?.altText || item.title;

                    return (
                      <button
                        key={item.id}
                        ref={(el) => {
                          tileRefs.current[item.slug] = el;
                        }}
                        type="button"
                        onClick={() => openPortfolioViewer(item)}
                        className="group w-full text-left bg-[var(--bg-page)] border border-[var(--border-subtle)] rounded-[12px] overflow-hidden shadow-[var(--shadow-soft)] hover:border-[var(--brand-blue)] transition-colors focus:outline-none focus:ring-2 focus:ring-[var(--brand-blue)]"
                      >
                        {/* Real image proportions reserved so the page never jumps or stretches */}
                        <div
                          className="w-full bg-[var(--bg-subtle)] overflow-hidden relative"
                          style={{ aspectRatio: `${imgW} / ${imgH}` }}
                        >
                          <img
                            src={thumbSrc}
                            alt={altText}
                            width={imgW}
                            height={imgH}
                            loading="lazy"
                            decoding="async"
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-contain bg-[var(--bg-subtle)] group-hover:scale-[1.015] transition-transform duration-150"
                          />
                          {item.images && item.images.length > 1 && (
                            <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-slate-900/75 text-white text-[11px] font-medium">
                              {item.images.length} views
                            </span>
                          )}
                        </div>

                        <div className="p-4 space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs text-[var(--brand-blue)] font-medium">
                              {item.categoryName}
                            </span>
                            {item.featured && activeCategorySlug === 'all' && (
                              <span className="text-[11px] text-[var(--text-secondary)]">
                                Featured
                              </span>
                            )}
                          </div>
                          <h3 className="text-sm font-heading font-semibold text-[var(--text-primary)] leading-snug">
                            {item.title}
                          </h3>
                          {item.isSample && (
                            <p className="text-[11px] text-[var(--text-muted)] pt-0.5">
                              Names and details may be changed to protect client privacy.
                            </p>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* "Show more" button (loads next 9 items inside the same section, no endless auto-scroll) */}
                {filteredPortfolioItems.length > visibleWorkCount && (
                  <div className="pt-4 text-center">
                    <button
                      type="button"
                      onClick={() => setVisibleWorkCount((prev) => prev + 9)}
                      className="px-6 py-3 text-xs sm:text-sm font-medium text-[var(--text-primary)] bg-[var(--bg-page)] hover:bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-lg transition-colors min-h-[44px]"
                    >
                      Show more ({filteredPortfolioItems.length - visibleWorkCount} remaining)
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </section>

        {/* ================================================================= */}
        {/* 4B. OUR SOFTWARE SECTION (#software) — After Portfolio, before Order */}
        {/* ================================================================= */}
        <section
          id="software"
          aria-labelledby="software-heading"
          className="py-16 sm:py-20 px-4 sm:px-6 border-t border-[var(--border-subtle)] bg-[var(--bg-page)] scroll-mt-16"
        >
          <div className="max-w-6xl mx-auto space-y-6">
            <div className="space-y-1.5">
              <h2
                id="software-heading"
                className="text-2xl sm:text-3xl font-heading font-bold text-[var(--text-primary)]"
              >
                Our software
              </h2>
              <p className="text-sm text-[var(--text-secondary)]">
                We also built presentation software for church services.
              </p>
            </div>

            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-5 shadow-[var(--shadow-soft)] max-w-2xl">
              <div className="space-y-1.5">
                <h3 className="text-base font-heading font-semibold text-[var(--text-primary)]">
                  Mannu Cast Pro
                </h3>
                <p className="text-xs sm:text-sm text-[var(--text-secondary)] leading-relaxed">
                  Presentation software for church services.
                </p>
              </div>

              <a
                href={MANNU_CAST_PRO_URL}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Open Mannu Cast Pro (opens in a new tab)"
                className="px-5 py-2.5 text-xs sm:text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors whitespace-nowrap min-h-[42px] inline-flex items-center justify-center gap-2 shrink-0"
              >
                <span>Open Mannu Cast Pro</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </section>

        {/* ================================================================= */}
        {/* 5. SMART ORDER FORM SECTION                                       */}
        {/* ================================================================= */}
        <section
          id="order"
          className="py-16 sm:py-20 px-4 sm:px-6 border-t border-[var(--border-subtle)] max-w-3xl mx-auto space-y-8 scroll-mt-16"
        >
          <div>
            <h2 className="text-2xl sm:text-3xl font-heading font-bold text-[var(--text-primary)]">
              Send an Order Request
            </h2>
            <p className="text-sm text-[var(--text-secondary)] mt-1">
              Fill in the details below. After saving your order, we will open WhatsApp with your order reference so we can confirm the details and price.
            </p>
          </div>

          {submittedOrderConfirmation ? (
            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 sm:p-8 space-y-6 shadow-[var(--shadow-soft)]">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">
                      Order &amp; Digital Service Ticket Generated
                    </p>
                    <div className="flex flex-wrap items-center gap-2.5 mt-0.5">
                      <h3 className="text-xl font-heading font-bold font-mono-tabular text-[var(--text-primary)]">
                        {submittedOrderConfirmation.orderNumber}
                      </h3>
                      {submittedOrderConfirmation.ticketNumber && (
                        <span className="text-xs font-mono-tabular font-semibold px-2.5 py-1 rounded bg-blue-50 dark:bg-blue-950/60 text-[#0B4DA8] dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                          Ticket: {submittedOrderConfirmation.ticketNumber}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {submittedOrderConfirmation.order && (
                <TicketCard
                  ticket={{
                    ticketNumber:
                      submittedOrderConfirmation.ticketNumber ||
                      submittedOrderConfirmation.order.ticketNumber ||
                      `TKT-${new Date().getFullYear()}-8942`,
                    orderNumber: submittedOrderConfirmation.orderNumber,
                    ticketStatus:
                      submittedOrderConfirmation.order.ticketStatus || 'PENDING_PAYMENT',
                    orderStatus: submittedOrderConfirmation.order.status,
                    paymentStatus:
                      submittedOrderConfirmation.order.paymentStatus || 'UNPAID',
                    customerName:
                      submittedOrderConfirmation.order.customerName || customerName,
                    customerPhoneMasked:
                      submittedOrderConfirmation.order.customerPhoneMasked,
                    serviceCategory:
                      submittedOrderConfirmation.order.serviceCategory || orderCategory,
                    serviceName:
                      submittedOrderConfirmation.order.serviceName || orderServiceName,
                    createdAt: submittedOrderConfirmation.order.createdAt,
                    deadline:
                      submittedOrderConfirmation.order.deadline || orderDeadline || null,
                    deliveryMethod:
                      submittedOrderConfirmation.order.deliveryMethod || deliveryMethod,
                    priceKes: submittedOrderConfirmation.order.priceKes || 0,
                    paidKes: submittedOrderConfirmation.order.paidKes || 0,
                    mpesaReceiptCode:
                      submittedOrderConfirmation.order.mpesaReceiptCode || null,
                    verifyUrl: submittedOrderConfirmation.verifyUrl,
                    qrCodeData: submittedOrderConfirmation.order.qrCodeData,
                  }}
                  settings={settings}
                />
              )}

              <div className="p-4 rounded-lg bg-[var(--bg-subtle)] border border-[var(--border-subtle)] text-xs sm:text-sm text-[var(--text-primary)] space-y-1.5">
                <p className="font-medium">
                  Send your photos or documents to our WhatsApp {settings.whatsappDisplay} and quote your order number ({submittedOrderConfirmation.orderNumber}) or ticket number ({submittedOrderConfirmation.ticketNumber}).
                </p>
                <p className="text-xs text-[var(--text-secondary)]">
                  Once we review your request on WhatsApp and confirm the price, you can pay by M-Pesa from the Track Order section below. Your ticket will automatically transition from PENDING_PAYMENT to CONFIRMED upon payment.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <a
                  href={submittedOrderConfirmation.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg inline-flex items-center gap-2 whitespace-nowrap"
                >
                  <MessageSquare className="w-4 h-4" />
                  Open WhatsApp with Order Details
                </a>
                <a
                  href="#track-order"
                  onClick={(e) => scrollToSection(e, 'track-order')}
                  className="px-5 py-3 text-sm font-medium text-[var(--text-primary)] bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-lg whitespace-nowrap"
                >
                  Track Order {submittedOrderConfirmation.orderNumber}
                </a>
                <button
                  type="button"
                  onClick={() => setSubmittedOrderConfirmation(null)}
                  className="px-4 py-3 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
                >
                  Send another order
                </button>
              </div>
            </div>
          ) : (
            <form
              onSubmit={handleOrderFormSubmit}
              className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 sm:p-8 space-y-6 shadow-[var(--shadow-soft)]"
            >
              {orderFormError && (
                <div className="p-4 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-start gap-2.5 text-xs sm:text-sm text-red-700 dark:text-red-300">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{orderFormError}</span>
                </div>
              )}

              {/* Common Fields: Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="order-name"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Your Name
                  </label>
                  <input
                    id="order-name"
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Mary Wanjiku"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] min-h-[44px]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="order-phone"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Phone / WhatsApp Number (Kenya)
                  </label>
                  <input
                    id="order-phone"
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 0712 345 678"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] font-mono-tabular min-h-[44px]"
                  />
                </div>
              </div>

              {/* Service Category & Specific Service */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="order-category"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Service Category
                  </label>
                  <select
                    id="order-category"
                    value={orderCategory}
                    onChange={(e) => {
                      const cat = e.target.value as ServiceCategory;
                      setOrderCategory(cat);
                      const firstInCat = services.find((s) => s.category === cat);
                      if (firstInCat) setOrderServiceName(firstInCat.name);
                    }}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] min-h-[44px]"
                  >
                    <option value="government">Online government services</option>
                    <option value="graphic_design">Graphic design</option>
                    <option value="other">Other online services</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="order-service"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Service
                  </label>
                  <select
                    id="order-service"
                    value={orderServiceName}
                    onChange={(e) => {
                      setOrderServiceName(e.target.value);
                      if (orderCategory === 'graphic_design') {
                        setDesignType(e.target.value);
                      }
                    }}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] min-h-[44px]"
                  >
                    {categoryServicesList.map((srv) => (
                      <option key={srv.id} value={srv.name}>
                        {srv.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* ADAPTIVE SECTION 1: GOVERNMENT SERVICES */}
              {orderCategory === 'government' && (
                <div className="p-4 sm:p-5 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] space-y-4">
                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[var(--bg-subtle)] text-xs text-[var(--text-primary)]">
                    <ShieldAlert className="w-4 h-4 text-[var(--brand-blue)] shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="font-semibold">
                        Never send your password to us in the form. We will guide you on the call or chat.
                      </p>
                      <p className="text-[var(--text-secondary)]">
                        Privacy reminder: Do not enter your national ID number, KRA PIN or account password in any field below.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="gov-portal"
                        className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                      >
                        Which portal do you need help with?
                      </label>
                      <select
                        id="gov-portal"
                        value={portalName}
                        onChange={(e) => setPortalName(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                      >
                        <option value="eCitizen">eCitizen</option>
                        <option value="KRA">KRA (iTax)</option>
                        <option value="KUCCPS">KUCCPS</option>
                        <option value="HELB">HELB</option>
                        <option value="TIMS">TIMS</option>
                        <option value="SHA">SHA</option>
                        <option value="NHIF">NHIF</option>
                        <option value="NSSF">NSSF</option>
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="gov-help"
                        className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                      >
                        What help is needed?
                      </label>
                      <input
                        id="gov-help"
                        type="text"
                        value={helpNeeded}
                        onChange={(e) => setHelpNeeded(e.target.value)}
                        placeholder="e.g. Good conduct application or returns filing"
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* ADAPTIVE SECTION 2: GRAPHIC DESIGN */}
              {orderCategory === 'graphic_design' && (
                <div className="p-4 sm:p-5 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="design-type"
                        className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                      >
                        Design Type
                      </label>
                      <input
                        id="design-type"
                        type="text"
                        value={designType}
                        onChange={(e) => setDesignType(e.target.value)}
                        placeholder="e.g. Wedding cards, Posters and flyers, Funeral programs"
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="design-format"
                        className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                      >
                        Size or Format
                      </label>
                      <select
                        id="design-format"
                        value={sizeOrFormat}
                        onChange={(e) =>
                          setSizeOrFormat(e.target.value as 'Print' | 'Social media')
                        }
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                      >
                        <option value="Print">Print (PDF / A4 / A5 / Banner)</option>
                        <option value="Social media">Social media (WhatsApp / Facebook / Instagram)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="design-exact-text"
                      className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                    >
                      Exact Text to Appear on the Design
                    </label>
                    <textarea
                      id="design-exact-text"
                      rows={2}
                      value={exactText}
                      onChange={(e) => setExactText(e.target.value)}
                      placeholder="Write the names, title or wording that should appear"
                      className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="design-event"
                        className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                      >
                        Event Name, Date and Venue (if applicable)
                      </label>
                      <input
                        id="design-event"
                        type="text"
                        value={eventDetails}
                        onChange={(e) => setEventDetails(e.target.value)}
                        placeholder="e.g. Saturday 14 Nov, Nakuru"
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="design-colours"
                        className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                      >
                        Colour Preferences
                      </label>
                      <input
                        id="design-colours"
                        type="text"
                        value={colourPreferences}
                        onChange={(e) => setColourPreferences(e.target.value)}
                        placeholder="e.g. Royal blue, white and gold"
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 pt-1">
                    <input
                      id="design-whatsapp-files"
                      type="checkbox"
                      checked={hasExtraWhatsappFiles}
                      onChange={(e) => setHasExtraWhatsappFiles(e.target.checked)}
                      className="w-4 h-4 rounded border-[var(--border-subtle)]"
                    />
                    <label
                      htmlFor="design-whatsapp-files"
                      className="text-xs text-[var(--text-primary)]"
                    >
                      I have a logo or photos to send afterwards on WhatsApp
                    </label>
                  </div>
                </div>
              )}

              {/* ADAPTIVE SECTION 3: CV / TYPING / LETTERS / OTHER */}
              {orderCategory === 'other' && (
                <div className="p-4 sm:p-5 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label
                      htmlFor="other-doc-type"
                      className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                    >
                      Document Type
                    </label>
                    <input
                      id="other-doc-type"
                      type="text"
                      value={documentType}
                      onChange={(e) => setDocumentType(e.target.value)}
                      placeholder="e.g. CV, Letter, Typing"
                      className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="other-pages"
                      className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                    >
                      Number of Pages (Approx.)
                    </label>
                    <input
                      id="other-pages"
                      type="text"
                      value={pageCount}
                      onChange={(e) => setPageCount(e.target.value)}
                      placeholder="e.g. 2 pages"
                      className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="other-language"
                      className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                    >
                      Language
                    </label>
                    <select
                      id="other-language"
                      value={documentLanguage}
                      onChange={(e) => setDocumentLanguage(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                    >
                      <option value="English">English</option>
                      <option value="Kiswahili">Kiswahili</option>
                      <option value="English and Kiswahili">Both English and Kiswahili</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Additional Notes */}
              <div>
                <label
                  htmlFor="order-details"
                  className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                >
                  Additional Details
                </label>
                <textarea
                  id="order-details"
                  rows={3}
                  value={orderDetails}
                  onChange={(e) => setOrderDetails(e.target.value)}
                  placeholder="Describe any specific instructions for your request..."
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)]"
                />
              </div>

              {/* Deadline, Delivery Method & Optional Email */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label
                    htmlFor="order-deadline"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Deadline (Optional)
                  </label>
                  <input
                    id="order-deadline"
                    type="date"
                    value={orderDeadline}
                    onChange={(e) => setOrderDeadline(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] min-h-[44px]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="order-delivery"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Delivery Method
                  </label>
                  <select
                    id="order-delivery"
                    value={deliveryMethod}
                    onChange={(e) =>
                      setDeliveryMethod(
                        e.target.value as 'WhatsApp' | 'Email' | 'Download link'
                      )
                    }
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] min-h-[44px]"
                  >
                    <option value="WhatsApp">WhatsApp</option>
                    <option value="Email">Email</option>
                    <option value="Download link">Download link on Track Order page</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="order-email"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Email {deliveryMethod === 'Email' ? '(Required)' : '(Optional)'}
                  </label>
                  <input
                    id="order-email"
                    type="email"
                    required={deliveryMethod === 'Email'}
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] min-h-[44px]"
                  />
                </div>
              </div>

              {/* Files & WhatsApp Instruction */}
              <div className="p-4 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] space-y-3">
                <p className="text-xs text-[var(--text-primary)] font-medium">
                  Send your photos or documents to our WhatsApp {settings.whatsappDisplay} and quote your order number.
                </p>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-[var(--text-secondary)]">
                    Or attach up to 5 small files here (images or PDF up to 10 MB each):
                  </span>
                  <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs font-medium cursor-pointer hover:border-[var(--brand-blue)]">
                    <Upload className="w-3.5 h-3.5 text-[var(--brand-blue)]" />
                    <span>Select Files ({attachedFiles.length}/5)</span>
                    <input
                      type="file"
                      multiple
                      accept="image/*,application/pdf"
                      onChange={handleFileAttachmentChange}
                      className="hidden"
                    />
                  </label>
                </div>

                {attachedFiles.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {attachedFiles.map((f, i) => (
                      <div
                        key={i}
                        className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs"
                      >
                        <span className="truncate max-w-[180px]">{f.fileName}</span>
                        <button
                          type="button"
                          onClick={() =>
                            setAttachedFiles(attachedFiles.filter((_, idx) => idx !== i))
                          }
                          className="text-slate-400 hover:text-red-600"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Payment Preference */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-[var(--text-secondary)]">
                <span className="font-medium text-[var(--text-primary)]">Payment option:</span>
                <label className="inline-flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="paymentPref"
                    checked={paymentPreference === 'mpesa_stk'}
                    onChange={() => setPaymentPreference('mpesa_stk')}
                  />
                  <span>Pay by M-Pesa after price is confirmed</span>
                </label>
                <label className="inline-flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="paymentPref"
                    checked={paymentPreference === 'pay_later'}
                    onChange={() => setPaymentPreference('pay_later')}
                  />
                  <span>Pay later / pay on delivery</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={submittingOrder}
                className="w-full py-3.5 px-6 text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors disabled:opacity-50 min-h-[48px]"
              >
                {submittingOrder ? 'Saving order...' : 'Submit Order & Continue to WhatsApp'}
              </button>
            </form>
          )}
        </section>

        {/* ================================================================= */}
        {/* 6. HOW IT WORKS (4 Plain Steps)                                   */}
        {/* ================================================================= */}
        <section className="py-16 sm:py-20 px-4 sm:px-6 border-t border-[var(--border-subtle)] bg-[var(--bg-surface)]">
          <div className="max-w-6xl mx-auto space-y-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-heading font-bold text-[var(--text-primary)]">
                How It Works
              </h2>
              <p className="text-sm text-[var(--text-secondary)] mt-1">
                Four simple steps from sending your request to receiving your finished work online.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {[
                {
                  step: '01.',
                  title: 'Send your request',
                  desc: 'Choose a service in the order form and share the details of what you need.',
                },
                {
                  step: '02.',
                  title: 'We confirm the details and price on WhatsApp',
                  desc: 'We review your request with you on WhatsApp and set the agreed price on your order.',
                },
                {
                  step: '03.',
                  title: 'You pay by M-Pesa',
                  desc: 'Pay securely from your order tracking link via M-Pesa STK Push using your order number.',
                },
                {
                  step: '04.',
                  title: 'We deliver online',
                  desc: 'Receive your completed document or design by WhatsApp, email or direct download link.',
                },
              ].map((item) => (
                <div
                  key={item.step}
                  className="p-6 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] space-y-2"
                >
                  <span className="text-xs font-mono-tabular font-semibold text-[var(--brand-blue)]">
                    {item.step}
                  </span>
                  <h3 className="text-base font-heading font-semibold text-[var(--text-primary)]">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ================================================================= */}
        {/* 7. TRACK ORDER SECTION                                            */}
        {/* ================================================================= */}
        <section
          id="track-order"
          className="py-16 sm:py-20 px-4 sm:px-6 border-t border-[var(--border-subtle)] max-w-3xl mx-auto space-y-8 scroll-mt-16"
        >
          <div>
            <h2 className="text-2xl sm:text-3xl font-heading font-bold text-[var(--text-primary)]">
              Track Order &amp; Digital Ticket
            </h2>
            <p className="text-sm text-[var(--text-secondary)] mt-1">
              Enter your Order Number (e.g. MV-4821) or Ticket Number (e.g. TKT-2026-8942) to view your digital ticket, check progress, pay by M-Pesa, or download your finished file.
            </p>
          </div>

          {verifiedTicketBanner && (
            <div className="p-4 rounded-[12px] bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5 text-emerald-800 dark:text-emerald-200">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <p className="font-semibold">
                    Official Ticket Verified: {verifiedTicketBanner.ticketNumber}
                  </p>
                  <p className="text-[11px] opacity-80">
                    Verified at {new Date(verifiedTicketBanner.verifiedAt).toLocaleTimeString('en-KE')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  window.history.pushState(
                    {},
                    '',
                    `/admin/verify?ticket=${encodeURIComponent(
                      verifiedTicketBanner.ticketNumber
                    )}`
                  );
                  setIsAdminRoute(true);
                }}
                className="px-3 py-1.5 rounded-lg bg-[var(--brand-blue)] text-white font-medium hover:bg-[var(--brand-blue-hover)]"
              >
                Staff: Open in /admin/verify
              </button>
            </div>
          )}

          <form onSubmit={handleTrackOrderSubmit} className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[var(--text-muted)] absolute left-3.5 top-3.5" />
              <input
                type="text"
                required
                value={trackInput}
                onChange={(e) => setTrackInput(e.target.value)}
                placeholder="Enter Order Number (MV-4821) or Ticket Number (TKT-2026-8942)"
                className="w-full pl-10 pr-4 py-3 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] font-mono-tabular min-h-[46px]"
              />
            </div>
            <button
              type="submit"
              disabled={trackLoading}
              className="px-6 py-3 text-sm font-medium text-white bg-[var(--brand-blue)] hover:bg-[var(--brand-blue-hover)] rounded-lg transition-colors whitespace-nowrap min-h-[46px]"
            >
              {trackLoading ? 'Checking...' : 'Check Status'}
            </button>
          </form>

          {trackError && (
            <div className="p-4 rounded-[12px] bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs sm:text-sm text-[var(--text-secondary)]">
              {trackError}
            </div>
          )}

          {trackedOrder && (
            <div className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] p-6 sm:p-8 space-y-6 shadow-[var(--shadow-soft)]">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--border-subtle)] pb-5">
                <div>
                  <span className="text-xs text-[var(--text-secondary)]">Order Number</span>
                  <h3 className="text-xl font-heading font-bold font-mono-tabular text-[var(--brand-blue)] mt-0.5">
                    {trackedOrder.orderNumber}
                  </h3>
                  <p className="text-xs text-[var(--text-secondary)] mt-1">
                    {trackedOrder.serviceName} · Phone: {trackedOrder.customerPhoneMasked}
                  </p>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-xs text-[var(--text-secondary)]">Payment Status</span>
                  <p className="text-sm font-semibold font-mono-tabular text-[var(--text-primary)] mt-0.5">
                    {trackedOrder.paymentStatus}
                  </p>
                  {trackedOrder.priceKes > 0 ? (
                    <p className="text-xs font-mono-tabular text-[var(--text-secondary)] mt-0.5">
                      Price: KES {trackedOrder.priceKes.toLocaleString()} · Paid: KES{' '}
                      {trackedOrder.paidKes.toLocaleString()}
                    </p>
                  ) : (
                    <p className="text-xs text-[var(--text-secondary)] mt-0.5">
                      Price will appear once confirmed on WhatsApp
                    </p>
                  )}
                </div>
              </div>

              {/* 6-Step Progress Bar */}
              <div className="space-y-3">
                <p className="text-xs font-medium text-[var(--text-secondary)]">Order Progress</p>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                  {TRACKING_STEPS.map((step, index) => {
                    const currentIdx = TRACKING_STEPS.indexOf(trackedOrder.status);
                    const isCompleted = index <= currentIdx;
                    return (
                      <div
                        key={step}
                        className={`p-2.5 rounded-lg border text-xs transition-colors ${
                          isCompleted
                            ? 'bg-[var(--bg-subtle)] border-[var(--brand-blue)] text-[var(--text-primary)] font-semibold'
                            : 'bg-[var(--bg-page)] border-[var(--border-subtle)] text-[var(--text-muted)]'
                        }`}
                      >
                        <div className="font-mono-tabular text-[11px] text-[var(--brand-blue)]">
                          0{index + 1}
                        </div>
                        <div className="mt-0.5 truncate">{step}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Printable Digital Ticket Card with QR Code */}
              <TicketCard
                ticket={{
                  ticketNumber:
                    trackedOrder.ticketNumber ||
                    `TKT-${new Date().getFullYear()}-8942`,
                  orderNumber: trackedOrder.orderNumber,
                  ticketStatus: trackedOrder.ticketStatus || 'PENDING_PAYMENT',
                  orderStatus: trackedOrder.status,
                  paymentStatus: trackedOrder.paymentStatus || 'UNPAID',
                  customerName: trackedOrder.customerName || 'Valued Client',
                  customerPhoneMasked: trackedOrder.customerPhoneMasked,
                  customerEmailMasked: trackedOrder.customerEmailMasked,
                  serviceCategory: trackedOrder.serviceCategory || 'other',
                  serviceName: trackedOrder.serviceName,
                  createdAt: trackedOrder.createdAt,
                  deadline: trackedOrder.deadline,
                  deliveryMethod: trackedOrder.deliveryMethod,
                  priceKes: trackedOrder.priceKes,
                  paidKes: trackedOrder.paidKes,
                  balanceKes: trackedOrder.balanceKes,
                  mpesaReceiptCode: trackedOrder.mpesaReceiptCode,
                  receiptNumber: trackedOrder.receiptNumber,
                  verifyUrl: trackedOrder.verifyUrl,
                  qrCodeData: trackedOrder.qrCodeData,
                }}
                settings={settings}
              />

              {/* M-Pesa Receipt Display when Paid */}
              {trackedOrder.mpesaReceiptCode && (
                <div className="p-4 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="text-[var(--text-secondary)]">M-Pesa Receipt Code: </span>
                    <span className="font-mono-tabular font-semibold text-[var(--text-primary)]">
                      {trackedOrder.mpesaReceiptCode}
                    </span>
                    {trackedOrder.receiptNumber && (
                      <span className="ml-2 text-[var(--text-secondary)]">
                        (Receipt {trackedOrder.receiptNumber})
                      </span>
                    )}
                  </div>
                  {trackedOrder.receiptToken && (
                    <button
                      type="button"
                      onClick={() =>
                        loadPublicDocumentByToken('receipt', trackedOrder.receiptToken)
                      }
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[var(--brand-blue)] text-white font-medium"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      View / Print Receipt
                    </button>
                  )}
                </div>
              )}

              {/* Pay Now via M-Pesa STK Push */}
              {trackedOrder.priceKes > 0 && trackedOrder.balanceKes > 0 && (
                <div className="p-5 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-heading font-semibold text-[var(--text-primary)]">
                        Pay Now by M-Pesa (KES {trackedOrder.balanceKes.toLocaleString()})
                      </h4>
                      <p className="text-xs text-[var(--text-secondary)] mt-0.5">
                        Account reference: {trackedOrder.orderNumber}. Enter your M-Pesa number below to receive the STK prompt on your phone.
                      </p>
                    </div>
                  </div>

                  <form
                    onSubmit={handleTrackOrderStkPush}
                    className="flex flex-col sm:flex-row gap-3"
                  >
                    <input
                      type="tel"
                      required
                      value={stkPhone}
                      onChange={(e) => setStkPhone(e.target.value)}
                      placeholder="Enter M-Pesa phone e.g. 0712 345 678"
                      className="flex-1 px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] font-mono-tabular min-h-[44px]"
                    />
                    <button
                      type="submit"
                      disabled={stkLoading}
                      className="px-5 py-2.5 text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg inline-flex items-center justify-center gap-2 whitespace-nowrap min-h-[44px]"
                    >
                      <Smartphone className="w-4 h-4" />
                      {stkLoading
                        ? 'Sending prompt...'
                        : `Pay KES ${trackedOrder.balanceKes.toLocaleString()} Now`}
                    </button>
                  </form>

                  {stkError && <p className="text-xs text-red-600">{stkError}</p>}

                  {stkActiveCheckout && (
                    <div className="p-3.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-3 text-xs">
                      <span className="text-[var(--text-primary)]">
                        {stkActiveCheckout.message}
                      </span>
                      <button
                        type="button"
                        onClick={handleConfirmSandboxStkPayment}
                        className="px-3 py-1.5 rounded bg-[var(--brand-blue)] text-white font-medium"
                      >
                        Confirm Sandbox M-Pesa Payment
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Download Finished Deliverable when Attached */}
              {trackedOrder.deliverableAvailable && trackedOrder.deliverableFileUrl && (
                <div className="p-4 rounded-[12px] bg-[var(--bg-subtle)] border border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-3">
                  <div className="text-xs">
                    <p className="font-semibold text-[var(--text-primary)]">
                      Your finished file is ready for download
                    </p>
                    <p className="text-[var(--text-secondary)] mt-0.5">
                      {trackedOrder.deliverableFileName}
                    </p>
                  </div>
                  <a
                    href={trackedOrder.deliverableFileUrl}
                    download={trackedOrder.deliverableFileName || `${trackedOrder.orderNumber}-file`}
                    className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg"
                  >
                    <Download className="w-4 h-4" />
                    Download Finished File
                  </a>
                </div>
              )}
            </div>
          )}
        </section>

        {/* ================================================================= */}
        {/* 8. CONTACT SECTION                                                */}
        {/* ================================================================= */}
        <section
          id="contact"
          className="py-16 sm:py-20 px-4 sm:px-6 border-t border-[var(--border-subtle)] bg-[var(--bg-surface)] scroll-mt-16"
        >
          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-6 space-y-5">
              <div>
                <h2 className="text-2xl sm:text-3xl font-heading font-bold text-[var(--text-primary)]">
                  Contact
                </h2>
                <p className="text-sm text-[var(--text-secondary)] mt-1">
                  Reach us on WhatsApp or phone for any online cyber or graphic design request.
                </p>
              </div>

              <div className="space-y-3.5 text-sm">
                <div className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-[var(--brand-blue)] shrink-0 mt-1" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">WhatsApp and Phone</p>
                    <a
                      href={`https://wa.me/${settings.whatsappWaMe}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-mono-tabular font-medium text-[var(--brand-blue)] hover:underline"
                    >
                      {settings.whatsappDisplay}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-[var(--brand-blue)] shrink-0 mt-1" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">Email</p>
                    <a
                      href={`mailto:${settings.email}`}
                      className="font-medium text-[var(--brand-blue)] hover:underline break-all"
                    >
                      {settings.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <ExternalLink className="w-4 h-4 text-[var(--brand-blue)] shrink-0 mt-1" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">Social Media</p>
                    <p className="text-[var(--text-primary)]">{settings.facebookLink}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-[var(--brand-blue)] shrink-0 mt-1" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">Working Hours</p>
                    <p className="text-[var(--text-primary)]">{settings.workingHours}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CreditCard className="w-4 h-4 text-[var(--brand-blue)] shrink-0 mt-1" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">Payments</p>
                    <p className="text-[var(--text-primary)]">{settings.mpesaTillOrPaybill}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Short Message Form that Opens WhatsApp */}
            <div className="lg:col-span-6">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const text = `Hello ${settings.businessName}, my name is ${contactName}. ${contactMessage}`;
                  const waUrl = `https://wa.me/${settings.whatsappWaMe}?text=${encodeURIComponent(text)}`;
                  const link = document.createElement('a');
                  link.href = waUrl;
                  link.target = '_blank';
                  link.rel = 'noopener noreferrer';
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                }}
                className="p-6 rounded-[12px] bg-[var(--bg-page)] border border-[var(--border-subtle)] space-y-4"
              >
                <h3 className="text-base font-heading font-semibold text-[var(--text-primary)]">
                  Send a Quick WhatsApp Message
                </h3>
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Your Name
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    required
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] min-h-[44px]"
                  />
                </div>
                <div>
                  <label
                    htmlFor="contact-message"
                    className="block text-xs font-medium text-[var(--text-primary)] mb-1.5"
                  >
                    Message
                  </label>
                  <textarea
                    id="contact-message"
                    rows={3}
                    required
                    value={contactMessage}
                    onChange={(e) => setContactMessage(e.target.value)}
                    placeholder="How can we help you today?"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)]"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3 px-5 text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors min-h-[44px]"
                >
                  Continue to WhatsApp
                </button>
              </form>
            </div>
          </div>
        </section>
      </main>

      {/* =================================================================== */}
      {/* 9. FOOTER                                                           */}
      {/* =================================================================== */}
      <footer className="py-10 px-4 sm:px-6 border-t border-[var(--border-subtle)] bg-[var(--bg-page)] text-xs text-[var(--text-secondary)]">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <Logo logoUrl={settings.logoUrl} businessName={settings.businessName} size="sm" />
            <p>{settings.description}</p>
          </div>

          <div className="flex flex-wrap items-center gap-5">
            <a
              href={`https://wa.me/${settings.whatsappWaMe}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[var(--text-primary)]"
            >
              WhatsApp: {settings.whatsappDisplay}
            </a>
            <a
              href={`mailto:${settings.email}`}
              className="hover:text-[var(--text-primary)]"
            >
              {settings.email}
            </a>
            <span>Socials: {settings.facebookLink}</span>
            <a
              href="#services"
              onClick={(e) => scrollToSection(e, 'services')}
              className="hover:text-[var(--text-primary)]"
            >
              Services
            </a>
            <a
              href="#work"
              onClick={(e) => scrollToSection(e, 'work')}
              className="hover:text-[var(--text-primary)]"
            >
              Portfolio
            </a>
            <a
              href={MANNU_CAST_PRO_URL}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Open Mannu Cast Pro (opens in a new tab)"
              className="inline-flex items-center gap-1 hover:text-[var(--text-primary)]"
            >
              <span>Mannu Cast Pro</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href="#order"
              onClick={(e) => scrollToSection(e, 'order')}
              className="hover:text-[var(--text-primary)]"
            >
              Order
            </a>
            <a
              href="#track-order"
              onClick={(e) => scrollToSection(e, 'track-order')}
              className="hover:text-[var(--text-primary)]"
            >
              Track order
            </a>
            <button
              type="button"
              onClick={navigateToAdmin}
              className="inline-flex items-center gap-1 hover:text-[var(--text-primary)]"
            >
              <Lock className="w-3 h-3" />
              Admin
            </button>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-6 pt-6 border-t border-[var(--border-subtle)] flex flex-wrap justify-between gap-2 text-[var(--text-muted)]">
          <span>
            © {new Date().getFullYear()} {settings.businessName}. All rights reserved.
          </span>
          <span>We help you with the online steps. We are not part of government offices.</span>
        </div>
      </footer>

      {/* Floating Small WhatsApp Button */}
      <a
        href={`https://wa.me/${settings.whatsappWaMe}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="fixed bottom-5 right-5 z-40 w-12 h-12 rounded-full bg-[var(--brand-blue)] hover:bg-[var(--brand-blue-hover)] text-white shadow-md flex items-center justify-center transition-transform hover:scale-105"
      >
        <MessageSquare className="w-5 h-5" />
      </a>

      {/* =================================================================== */}
      {/* FULL-SCREEN PORTFOLIO VIEWER (LIGHTBOX) OVER THE MAIN PAGE          */}
      {/* =================================================================== */}
      {viewerItem && (
        <div
          ref={viewerModalRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby="viewer-project-title"
          onClick={closePortfolioViewer}
          onTouchStart={(e) => {
            touchStartXRef.current = e.touches[0]?.clientX ?? null;
          }}
          onTouchEnd={(e) => {
            if (touchStartXRef.current === null) return;
            const deltaX = (e.changedTouches[0]?.clientX ?? 0) - touchStartXRef.current;
            touchStartXRef.current = null;
            if (Math.abs(deltaX) > 55) {
              if (deltaX < 0) navigateViewerProject('next');
              else navigateViewerProject('prev');
            }
          }}
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-2 sm:p-6 overflow-y-auto"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-[12px] max-w-5xl w-full overflow-hidden shadow-2xl flex flex-col max-h-[94vh]"
          >
            {/* Viewer Top Bar */}
            <div className="flex items-center justify-between gap-4 px-4 sm:px-6 py-3.5 border-b border-[var(--border-subtle)] shrink-0">
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-xs text-[var(--text-secondary)]">
                  <span className="font-medium text-[var(--brand-blue)]">
                    {viewerItem.categoryName}
                  </span>
                  {viewerItem.projectDate && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-tabular">{viewerItem.projectDate}</span>
                    </>
                  )}
                </div>
                <h3
                  id="viewer-project-title"
                  className="text-base sm:text-lg font-heading font-bold text-[var(--text-primary)] truncate"
                >
                  {viewerItem.title}
                </h3>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* Optional Before / After (Front / Back) Comparison Slider Toggle when 2+ images exist */}
                {activeViewerImages.length >= 2 && (
                  <button
                    type="button"
                    onClick={() => setViewerCompareMode((prev) => !prev)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors min-h-[36px] ${
                      viewerCompareMode
                        ? 'bg-[var(--brand-blue)] text-white border-[var(--brand-blue)]'
                        : 'bg-[var(--bg-page)] text-[var(--text-primary)] border-[var(--border-subtle)]'
                    }`}
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    <span>{viewerCompareMode ? 'Single view' : 'Before / After slider'}</span>
                  </button>
                )}

                {filteredPortfolioItems.length > 1 && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => navigateViewerProject('prev')}
                      aria-label="Previous project"
                      className="p-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] hover:border-[var(--brand-blue)] min-h-[36px]"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => navigateViewerProject('next')}
                      aria-label="Next project"
                      className="p-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-primary)] hover:border-[var(--brand-blue)] min-h-[36px]"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

                <button
                  type="button"
                  onClick={closePortfolioViewer}
                  aria-label="Close viewer"
                  className="p-2 rounded-lg bg-[var(--bg-page)] border border-[var(--border-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] min-h-[36px]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Viewer Main Image Canvas / Before-After Slider */}
            <div className="relative bg-[var(--bg-page)] flex-1 flex flex-col items-center justify-center p-4 sm:p-6 overflow-y-auto min-h-[280px]">
              {viewerCompareMode && activeViewerImages.length >= 2 ? (
                <div className="w-full max-w-3xl space-y-3">
                  <div
                    className="relative w-full overflow-hidden rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-subtle)] select-none"
                    style={{
                      aspectRatio: `${activeViewerImages[0].width || 800} / ${
                        activeViewerImages[0].height || 600
                      }`,
                    }}
                  >
                    {/* Base Image (Second image / Back / After) */}
                    <img
                      src={
                        viewerItem.watermark
                          ? activeViewerImages[1].publicUrl
                          : activeViewerImages[1].mediumUrl
                      }
                      alt={activeViewerImages[1].altText || `${viewerItem.title} view 2`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain"
                    />
                    {/* Clipped Overlay Image (First image / Front / Before) */}
                    <div
                      className="absolute inset-0 overflow-hidden"
                      style={{ clipPath: `inset(0 ${100 - viewerSliderPos}% 0 0)` }}
                    >
                      <img
                        src={
                          viewerItem.watermark
                            ? activeViewerImages[0].publicUrl
                            : activeViewerImages[0].mediumUrl
                        }
                        alt={activeViewerImages[0].altText || `${viewerItem.title} view 1`}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain bg-[var(--bg-subtle)]"
                      />
                    </div>
                    {/* Vertical Split Line */}
                    <div
                      className="absolute inset-y-0 w-0.5 bg-[var(--brand-red)] pointer-events-none"
                      style={{ left: `${viewerSliderPos}%` }}
                    />
                  </div>

                  <div className="flex items-center gap-3 text-xs text-[var(--text-secondary)]">
                    <span>Image 1</span>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={viewerSliderPos}
                      onChange={(e) => setViewerSliderPos(Number(e.target.value))}
                      aria-label="Compare first and second design image"
                      className="flex-1 accent-[var(--brand-blue)]"
                    />
                    <span>Image 2</span>
                  </div>
                </div>
              ) : (
                currentViewerImage && (
                  <img
                    src={
                      viewerItem.watermark
                        ? currentViewerImage.publicUrl
                        : currentViewerImage.mediumUrl || currentViewerImage.publicUrl
                    }
                    alt={currentViewerImage.altText || viewerItem.title}
                    width={currentViewerImage.width || 800}
                    height={currentViewerImage.height || 600}
                    referrerPolicy="no-referrer"
                    className="max-h-[58vh] w-auto max-w-full object-contain rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)]"
                  />
                )
              )}

              {/* Multi-image Thumbnail Strip (when project has several images, e.g. front and back of a card) */}
              {activeViewerImages.length > 1 && !viewerCompareMode && (
                <div className="mt-4 flex items-center gap-2.5 overflow-x-auto max-w-full py-1 px-2">
                  {activeViewerImages.map((img, idx) => (
                    <button
                      key={img.id || idx}
                      type="button"
                      onClick={() => setViewerImageIndex(idx)}
                      className={`relative rounded-lg overflow-hidden border-2 transition-all shrink-0 ${
                        viewerImageIndex === idx
                          ? 'border-[var(--brand-blue)] scale-105'
                          : 'border-[var(--border-subtle)] opacity-75 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={img.thumbUrl || img.publicUrl}
                        alt={img.altText || `${viewerItem.title} view ${idx + 1}`}
                        referrerPolicy="no-referrer"
                        className="w-16 h-12 object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Viewer Footer: Description, Privacy Note, and 3 Action Buttons */}
            <div className="px-4 sm:px-6 py-4 border-t border-[var(--border-subtle)] bg-[var(--bg-surface)] space-y-3.5 shrink-0">
              <div className="space-y-1">
                {viewerItem.description && (
                  <p className="text-xs sm:text-sm text-[var(--text-primary)] leading-relaxed">
                    {viewerItem.description}
                  </p>
                )}
                {viewerItem.isSample && (
                  <p className="text-xs text-[var(--text-secondary)]">
                    Names and details may be changed to protect client privacy.
                  </p>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1">
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => handleOrderSimilarDesign(viewerItem)}
                    className="px-4 py-2.5 text-xs sm:text-sm font-medium text-white bg-[var(--brand-red)] hover:bg-[var(--brand-red-hover)] rounded-lg transition-colors min-h-[42px]"
                  >
                    Order a similar design
                  </button>

                  <a
                    href={`https://wa.me/${settings.whatsappWaMe}?text=${encodeURIComponent(
                      `Hello ${settings.businessName}, I am looking at "${viewerItem.title}" (${viewerItem.categoryName}) in your portfolio (#work/${viewerItem.slug}) and would like to ask about a similar design.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 text-xs sm:text-sm font-medium text-[var(--text-primary)] bg-[var(--bg-subtle)] hover:bg-slate-200/70 dark:hover:bg-slate-800 border border-[var(--border-subtle)] rounded-lg inline-flex items-center gap-2 transition-colors min-h-[42px]"
                  >
                    <MessageSquare className="w-4 h-4 text-[var(--brand-blue)]" />
                    Ask on WhatsApp
                  </a>
                </div>

                <button
                  type="button"
                  onClick={() => handleSharePortfolioItem(viewerItem)}
                  className="px-3.5 py-2.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] bg-[var(--bg-page)] border border-[var(--border-subtle)] rounded-lg inline-flex items-center gap-1.5 min-h-[42px]"
                >
                  {shareCopied ? (
                    <>
                      <Copy className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Link copied</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-3.5 h-3.5 text-[var(--brand-blue)]" />
                      <span>Share</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Public Invoice / Receipt Modal */}
      {publicDocModal && (
        <PublicDocumentModal
          type={publicDocModal.type}
          invoice={publicDocModal.invoice}
          receipt={publicDocModal.receipt}
          settings={settings}
          onClose={() => setPublicDocModal(null)}
          onRefreshDocument={() =>
            loadPublicDocumentByToken(publicDocModal.type, publicDocModal.token)
          }
        />
      )}
    </div>
  );
}
