import dotenv from 'dotenv';
import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { handler as adminApiHandler } from './netlify/functions/admin-api.ts';
import { handler as createOrderHandler } from './netlify/functions/create-order.ts';
import { handler as mpesaCallbackHandler } from './netlify/functions/mpesa-callback.ts';
import { handler as orderStatusHandler } from './netlify/functions/order-status.ts';
import { handler as paymentStatusHandler } from './netlify/functions/payment-status.ts';
import { handler as portfolioAdminHandler } from './netlify/functions/portfolio-admin.ts';
import { handler as portfolioListHandler } from './netlify/functions/portfolio-list.ts';
import { handler as portfolioUploadUrlHandler } from './netlify/functions/portfolio-upload-url.ts';
import { handler as stkpushHandler } from './netlify/functions/stkpush.ts';
import { handler as verifyTicketHandler } from './netlify/functions/verify-ticket.ts';

dotenv.config();

const FUNCTION_HANDLERS: Record<string, (event: any) => Promise<any>> = {
  'admin-api': adminApiHandler,
  'create-order': createOrderHandler,
  'mpesa-callback': mpesaCallbackHandler,
  'order-status': orderStatusHandler,
  'payment-status': paymentStatusHandler,
  'portfolio-admin': portfolioAdminHandler,
  'portfolio-list': portfolioListHandler,
  'portfolio-upload-url': portfolioUploadUrlHandler,
  stkpush: stkpushHandler,
  'verify-ticket': verifyTicketHandler,
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '20mb' }));

  const handleNetlifyFunctionRequest = async (
    fnName: string,
    req: express.Request,
    res: express.Response
  ) => {
    const fn = FUNCTION_HANDLERS[fnName];
    if (!fn) {
      res.status(404).json({ error: `Netlify Function "${fnName}" not found.` });
      return;
    }

    try {
      const queryStringParameters: Record<string, string> = {};
      for (const [k, v] of Object.entries(req.query)) {
        if (v !== undefined) {
          queryStringParameters[k] = String(v);
        }
      }

      const event = {
        httpMethod: req.method,
        headers: req.headers,
        queryStringParameters,
        body: req.body && Object.keys(req.body).length > 0 ? JSON.stringify(req.body) : '',
      };

      const result = await fn(event);
      if (result.headers) {
        for (const [hk, hv] of Object.entries(result.headers)) {
          res.setHeader(hk, String(hv));
        }
      }
      res.status(result.statusCode || 200).send(result.body || '');
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Function execution error.' });
    }
  };

  app.all('/.netlify/functions/:fnName', (req, res) =>
    handleNetlifyFunctionRequest(req.params.fnName, req, res)
  );

  app.all('/api/:fnName', (req, res) =>
    handleNetlifyFunctionRequest(req.params.fnName, req, res)
  );

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Preview server running on http://localhost:${PORT}`);
  });
}

startServer();
