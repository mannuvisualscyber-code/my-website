-- =============================================================================
-- MANNU VISUALS — SUPABASE (POSTGRESQL) DATABASE, FUNCTIONS & STORAGE SCHEMA
-- Accessed strictly from Netlify Functions using SUPABASE_SERVICE_KEY.
-- Row Level Security (RLS) is enabled on all tables with NO public access.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- -----------------------------------------------------------------------------
-- 1. SEQUENCES FOR MV- (Orders), TKT- (Tickets), INV- (Invoices), AND RC- (Receipts)
-- -----------------------------------------------------------------------------
CREATE SEQUENCE IF NOT EXISTS mv_order_seq START WITH 4821 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS tkt_number_seq START WITH 8942 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS inv_number_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS rc_number_seq START WITH 1 INCREMENT BY 1;

-- -----------------------------------------------------------------------------
-- 2. TABLES (14 TABLES)
-- -----------------------------------------------------------------------------

-- 2.1 services
CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL CHECK (category IN ('government', 'graphic_design', 'other')),
  name TEXT NOT NULL,
  partner_label TEXT,
  items TEXT[] NOT NULL DEFAULT '{}',
  description TEXT NOT NULL DEFAULT '',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.2 customers
CREATE TABLE IF NOT EXISTS customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE, -- Normalised Kenyan format: 2547XXXXXXXX or 2541XXXXXXXX
  email TEXT,
  total_orders INTEGER NOT NULL DEFAULT 0,
  total_billed_kes INTEGER NOT NULL DEFAULT 0 CHECK (total_billed_kes >= 0),
  total_paid_kes INTEGER NOT NULL DEFAULT 0 CHECK (total_paid_kes >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.3 orders
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT NOT NULL UNIQUE DEFAULT ('MV-' || nextval('mv_order_seq')::TEXT),
  ticket_number TEXT NOT NULL UNIQUE DEFAULT ('TKT-' || EXTRACT(YEAR FROM NOW())::TEXT || '-' || nextval('tkt_number_seq')::TEXT),
  ticket_status TEXT NOT NULL DEFAULT 'PENDING_PAYMENT' CHECK (
    ticket_status IN ('PENDING_PAYMENT', 'CONFIRMED', 'PROCESSING', 'READY', 'COMPLETED', 'CANCELLED')
  ),
  qr_code_data TEXT,
  customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  service_category TEXT NOT NULL CHECK (service_category IN ('government', 'graphic_design', 'other')),
  service_name TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  deadline DATE,
  delivery_method TEXT NOT NULL CHECK (delivery_method IN ('WhatsApp', 'Email', 'Download link')),
  -- Adaptive service fields (never stores passwords, PINs, or national ID numbers)
  portal_name TEXT,
  help_needed TEXT,
  design_type TEXT,
  exact_text TEXT,
  event_details TEXT,
  colour_preferences TEXT,
  size_or_format TEXT,
  has_extra_whatsapp_files BOOLEAN DEFAULT FALSE,
  document_type TEXT,
  page_count TEXT,
  document_language TEXT,
  -- Lifecycle & Integer KES pricing
  status TEXT NOT NULL DEFAULT 'Received' CHECK (
    status IN ('Received', 'Price confirmed', 'Paid', 'In progress', 'Ready', 'Delivered')
  ),
  payment_status TEXT NOT NULL DEFAULT 'UNPAID' CHECK (
    payment_status IN ('UNPAID', 'PARTIAL', 'PAID')
  ),
  payment_preference TEXT NOT NULL DEFAULT 'mpesa_stk' CHECK (
    payment_preference IN ('mpesa_stk', 'pay_later')
  ),
  price_kes INTEGER NOT NULL DEFAULT 0 CHECK (price_kes >= 0),
  paid_kes INTEGER NOT NULL DEFAULT 0 CHECK (paid_kes >= 0),
  deliverable_file_name TEXT,
  deliverable_file_url TEXT,
  tracking_token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(16), 'hex'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Safe migration for existing orders tables
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS ticket_number TEXT UNIQUE DEFAULT ('TKT-' || EXTRACT(YEAR FROM NOW())::TEXT || '-' || nextval('tkt_number_seq')::TEXT),
  ADD COLUMN IF NOT EXISTS ticket_status TEXT NOT NULL DEFAULT 'PENDING_PAYMENT',
  ADD COLUMN IF NOT EXISTS qr_code_data TEXT;

-- 2.4 order_files
CREATE TABLE IF NOT EXISTS order_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 10485760),
  storage_path TEXT NOT NULL,
  file_kind TEXT NOT NULL DEFAULT 'customer_upload' CHECK (file_kind IN ('customer_upload', 'deliverable')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.5 invoices
CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number TEXT NOT NULL UNIQUE DEFAULT ('INV-' || lpad(nextval('inv_number_seq')::TEXT, 4, '0')),
  order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  subtotal_kes INTEGER NOT NULL DEFAULT 0 CHECK (subtotal_kes >= 0),
  discount_kes INTEGER NOT NULL DEFAULT 0 CHECK (discount_kes >= 0),
  total_kes INTEGER NOT NULL DEFAULT 0 CHECK (total_kes >= 0),
  paid_kes INTEGER NOT NULL DEFAULT 0 CHECK (paid_kes >= 0),
  status TEXT NOT NULL DEFAULT 'UNPAID' CHECK (status IN ('UNPAID', 'PARTIAL', 'PAID', 'CANCELLED')),
  due_date DATE,
  notes TEXT,
  public_token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(24), 'hex'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.6 invoice_items
CREATE TABLE IF NOT EXISTS invoice_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price_kes INTEGER NOT NULL DEFAULT 0 CHECK (unit_price_kes >= 0),
  line_total_kes INTEGER NOT NULL DEFAULT 0 CHECK (line_total_kes >= 0),
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- 2.7 payments
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  invoice_id UUID REFERENCES invoices(id) ON DELETE SET NULL,
  order_number TEXT,
  phone TEXT NOT NULL,
  amount_kes INTEGER NOT NULL CHECK (amount_kes > 0),
  method TEXT NOT NULL DEFAULT 'MPESA' CHECK (method IN ('MPESA', 'MPESA_STK', 'MPESA_MANUAL', 'CASH', 'OTHER')),
  transaction_type TEXT NOT NULL DEFAULT 'CustomerPayBillOnline' CHECK (
    transaction_type IN ('CustomerPayBillOnline', 'CustomerBuyGoodsOnline')
  ),
  merchant_request_id TEXT,
  checkout_request_id TEXT UNIQUE,
  mpesa_receipt_number TEXT UNIQUE,
  mpesa_receipt_code TEXT UNIQUE,
  transaction_time TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'SUCCESS', 'FAILED', 'CANCELLED')),
  result_code INTEGER,
  result_desc TEXT,
  raw_callback JSONB,
  recorded_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.8 receipts
CREATE TABLE IF NOT EXISTS receipts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_number TEXT NOT NULL UNIQUE DEFAULT ('RC-' || lpad(nextval('rc_number_seq')::TEXT, 4, '0')),
  payment_id UUID NOT NULL UNIQUE REFERENCES payments(id) ON DELETE RESTRICT,
  order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  invoice_id UUID REFERENCES invoices(id) ON DELETE SET NULL,
  order_number TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  service_description TEXT NOT NULL,
  amount_kes INTEGER NOT NULL CHECK (amount_kes > 0),
  payment_method TEXT NOT NULL,
  mpesa_receipt_code TEXT,
  balance_after_kes INTEGER NOT NULL DEFAULT 0 CHECK (balance_after_kes >= 0),
  public_token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(24), 'hex'),
  issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.9 portfolio_categories
CREATE TABLE IF NOT EXISTS portfolio_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.10 portfolio_items
CREATE TABLE IF NOT EXISTS portfolio_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  category_id UUID NOT NULL REFERENCES portfolio_categories(id) ON DELETE RESTRICT,
  tags TEXT[] NOT NULL DEFAULT '{}',
  client_label TEXT,
  project_date DATE DEFAULT CURRENT_DATE,
  is_sample BOOLEAN NOT NULL DEFAULT TRUE,
  watermark BOOLEAN NOT NULL DEFAULT TRUE,
  featured BOOLEAN NOT NULL DEFAULT FALSE,
  visible BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.11 portfolio_images
CREATE TABLE IF NOT EXISTS portfolio_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL REFERENCES portfolio_items(id) ON DELETE CASCADE,
  thumb_url TEXT NOT NULL,      -- ~480px WEBP thumbnail in portfolio-public
  medium_url TEXT NOT NULL,     -- ~1200px WEBP in portfolio-public
  public_url TEXT NOT NULL,     -- ~1200px WEBP (watermarked when item.watermark = true)
  original_path TEXT NOT NULL,  -- Private path in portfolio-private bucket
  width INTEGER NOT NULL DEFAULT 800,
  height INTEGER NOT NULL DEFAULT 600,
  alt_text TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_cover BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.12 admin_users
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('OWNER', 'STAFF')),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TIMESTAMPTZ,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.13 audit_log
CREATE TABLE IF NOT EXISTS audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_username TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.14 settings
CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  business_name TEXT NOT NULL DEFAULT 'Mannu Visuals',
  description TEXT NOT NULL DEFAULT 'Online cyber and graphic design services. All work is done online.',
  whatsapp_display TEXT NOT NULL DEFAULT '0796 431 953',
  whatsapp_wa_me TEXT NOT NULL DEFAULT '254796431953',
  facebook_link TEXT NOT NULL DEFAULT 'Mannu Visuals KE (TikTok, Facebook, Instagram and YouTube)',
  email TEXT NOT NULL DEFAULT 'mannuvisualscyber@gmail.com',
  working_hours TEXT NOT NULL DEFAULT '[add hours here]',
  mpesa_till_or_paybill TEXT NOT NULL DEFAULT 'M-Pesa [Till/Paybill number to be added]',
  mpesa_transaction_type TEXT NOT NULL DEFAULT 'CustomerPayBillOnline' CHECK (
    mpesa_transaction_type IN ('CustomerPayBillOnline', 'CustomerBuyGoodsOnline')
  ),
  logo_url TEXT NOT NULL DEFAULT '/logo.svg',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- -----------------------------------------------------------------------------
-- 3. M-PESA DATABASE FUNCTIONS (record_mpesa_payment & record_mpesa_failure)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION record_mpesa_payment(
  p_checkout_request_id TEXT,
  p_mpesa_receipt_number TEXT,
  p_amount NUMERIC,
  p_phone TEXT,
  p_transaction_time TIMESTAMPTZ,
  p_raw_callback JSONB DEFAULT '{}'::JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_payment payments%ROWTYPE;
  v_order orders%ROWTYPE;
  v_invoice invoices%ROWTYPE;
  v_receipt receipts%ROWTYPE;
  v_amount_int INTEGER := GREATEST(1, ROUND(COALESCE(p_amount, 0))::INTEGER);
  v_new_order_paid INTEGER := 0;
  v_new_order_balance INTEGER := 0;
  v_order_payment_status TEXT;
  v_order_status TEXT;
  v_new_inv_paid INTEGER := 0;
  v_new_inv_balance INTEGER := 0;
  v_inv_status TEXT;
  v_balance_after INTEGER := 0;
  v_customer_name TEXT := 'Customer';
  v_customer_phone TEXT := COALESCE(p_phone, '');
  v_order_number TEXT := '';
  v_service_desc TEXT := 'Online Service';
BEGIN
  SELECT * INTO v_payment
  FROM payments
  WHERE checkout_request_id = p_checkout_request_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'payment_not_found');
  END IF;

  -- Idempotency check: if already SUCCESS, return existing receipt
  IF v_payment.status = 'SUCCESS' THEN
    SELECT * INTO v_receipt FROM receipts WHERE payment_id = v_payment.id LIMIT 1;
    RETURN jsonb_build_object(
      'ok', true,
      'idempotent', true,
      'payment_id', v_payment.id,
      'receipt_number', v_receipt.receipt_number,
      'receipt_token', v_receipt.public_token
    );
  END IF;

  -- Also check duplicate M-Pesa receipt code across any other payment
  IF p_mpesa_receipt_number IS NOT NULL AND EXISTS (
    SELECT 1 FROM payments
    WHERE (mpesa_receipt_number = p_mpesa_receipt_number OR mpesa_receipt_code = p_mpesa_receipt_number)
      AND id <> v_payment.id
  ) THEN
    RETURN jsonb_build_object('ok', true, 'idempotent', true, 'reason', 'duplicate_receipt_number');
  END IF;

  v_amount_int := COALESCE(NULLIF(v_amount_int, 0), v_payment.amount_kes);

  UPDATE payments
  SET status = 'SUCCESS',
      mpesa_receipt_number = p_mpesa_receipt_number,
      mpesa_receipt_code = p_mpesa_receipt_number,
      amount_kes = v_amount_int,
      phone = COALESCE(NULLIF(p_phone, ''), v_payment.phone),
      transaction_time = COALESCE(p_transaction_time, NOW()),
      result_code = 0,
      result_desc = 'Confirmed',
      raw_callback = p_raw_callback,
      updated_at = NOW()
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;

  -- Update linked order if present
  IF v_payment.order_id IS NOT NULL THEN
    SELECT * INTO v_order FROM orders WHERE id = v_payment.order_id FOR UPDATE;
    IF FOUND THEN
      v_new_order_paid := v_order.paid_kes + v_amount_int;
      v_new_order_balance := GREATEST(0, v_order.price_kes - v_new_order_paid);
      v_order_payment_status := CASE
        WHEN v_order.price_kes > 0 AND v_new_order_paid >= v_order.price_kes THEN 'PAID'
        WHEN v_new_order_paid > 0 THEN 'PARTIAL'
        ELSE 'UNPAID'
      END;
      v_order_status := CASE
        WHEN v_order_payment_status = 'PAID' AND v_order.status IN ('Received', 'Price confirmed') THEN 'Paid'
        ELSE v_order.status
      END;

      UPDATE orders
      SET paid_kes = v_new_order_paid,
          payment_status = v_order_payment_status,
          status = v_order_status,
          ticket_status = CASE
            WHEN ticket_status = 'PENDING_PAYMENT' THEN 'CONFIRMED'
            ELSE ticket_status
          END,
          updated_at = NOW()
      WHERE id = v_order.id
      RETURNING * INTO v_order;

      v_balance_after := v_new_order_balance;
      v_customer_name := v_order.customer_name;
      v_customer_phone := v_order.customer_phone;
      v_order_number := v_order.order_number;
      v_service_desc := v_order.service_name;

      IF v_order.customer_id IS NOT NULL THEN
        UPDATE customers
        SET total_paid_kes = total_paid_kes + v_amount_int,
            updated_at = NOW()
        WHERE id = v_order.customer_id;
      END IF;
    END IF;
  END IF;

  -- Update linked invoice if present
  IF v_payment.invoice_id IS NOT NULL THEN
    SELECT * INTO v_invoice FROM invoices WHERE id = v_payment.invoice_id FOR UPDATE;
    IF FOUND THEN
      v_new_inv_paid := v_invoice.paid_kes + v_amount_int;
      v_new_inv_balance := GREATEST(0, v_invoice.total_kes - v_new_inv_paid);
      v_inv_status := CASE
        WHEN v_new_inv_paid >= v_invoice.total_kes THEN 'PAID'
        WHEN v_new_inv_paid > 0 THEN 'PARTIAL'
        ELSE 'UNPAID'
      END;

      UPDATE invoices
      SET paid_kes = v_new_inv_paid,
          status = v_inv_status,
          updated_at = NOW()
      WHERE id = v_invoice.id
      RETURNING * INTO v_invoice;

      IF v_payment.order_id IS NULL THEN
        v_balance_after := v_new_inv_balance;
        v_customer_name := v_invoice.customer_name;
        v_customer_phone := v_invoice.customer_phone;
        v_order_number := v_invoice.invoice_number;
        v_service_desc := 'Invoice ' || v_invoice.invoice_number;
      END IF;
    END IF;
  END IF;

  -- Generate receipt row using database defaults for receipt_number and public_token
  INSERT INTO receipts (
    payment_id,
    order_id,
    invoice_id,
    order_number,
    customer_name,
    customer_phone,
    service_description,
    amount_kes,
    payment_method,
    mpesa_receipt_code,
    balance_after_kes
  ) VALUES (
    v_payment.id,
    v_payment.order_id,
    v_payment.invoice_id,
    COALESCE(NULLIF(v_order_number, ''), COALESCE(v_payment.order_number, 'DIRECT')),
    v_customer_name,
    v_customer_phone,
    v_service_desc,
    v_amount_int,
    'M-Pesa (' || v_payment.transaction_type || ')',
    p_mpesa_receipt_number,
    v_balance_after
  )
  ON CONFLICT (payment_id) DO UPDATE
    SET mpesa_receipt_code = EXCLUDED.mpesa_receipt_code
  RETURNING * INTO v_receipt;

  INSERT INTO audit_log (actor_username, actor_role, action, target_type, target_id, details)
  VALUES (
    'safaricom-daraja',
    'SYSTEM',
    'MPESA_PAYMENT_SUCCESS',
    'payment',
    v_payment.id::TEXT,
    'M-Pesa payment ' || COALESCE(p_mpesa_receipt_number, '') || ' of KES ' || v_amount_int::TEXT || ' recorded (' || v_receipt.receipt_number || ').'
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent', false,
    'payment_id', v_payment.id,
    'receipt_id', v_receipt.id,
    'receipt_number', v_receipt.receipt_number,
    'receipt_token', v_receipt.public_token
  );
END;
$$;

CREATE OR REPLACE FUNCTION record_mpesa_failure(
  p_checkout_request_id TEXT,
  p_result_code INTEGER,
  p_result_desc TEXT,
  p_raw_callback JSONB DEFAULT '{}'::JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_payment payments%ROWTYPE;
  v_new_status TEXT;
BEGIN
  SELECT * INTO v_payment
  FROM payments
  WHERE checkout_request_id = p_checkout_request_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'payment_not_found');
  END IF;

  -- Never overwrite an already successful payment
  IF v_payment.status = 'SUCCESS' THEN
    RETURN jsonb_build_object('ok', true, 'idempotent', true, 'status', 'SUCCESS');
  END IF;

  v_new_status := CASE
    WHEN p_result_code = 1032 THEN 'CANCELLED'
    ELSE 'FAILED'
  END;

  UPDATE payments
  SET status = v_new_status,
      result_code = p_result_code,
      result_desc = COALESCE(p_result_desc, 'Payment failed or cancelled'),
      raw_callback = p_raw_callback,
      updated_at = NOW()
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;

  INSERT INTO audit_log (actor_username, actor_role, action, target_type, target_id, details)
  VALUES (
    'safaricom-daraja',
    'SYSTEM',
    'MPESA_PAYMENT_' || v_new_status,
    'payment',
    v_payment.id::TEXT,
    'M-Pesa STK push ' || v_new_status || ' (ResultCode ' || COALESCE(p_result_code::TEXT, 'unknown') || '): ' || COALESCE(p_result_desc, '')
  );

  RETURN jsonb_build_object(
    'ok', true,
    'payment_id', v_payment.id,
    'status', v_new_status
  );
END;
$$;

-- -----------------------------------------------------------------------------
-- 4. INDEXES
-- -----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_orders_ticket_number ON orders(ticket_number);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payments_order_id ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_checkout_req ON payments(checkout_request_id);
CREATE INDEX IF NOT EXISTS idx_payments_mpesa_code ON payments(mpesa_receipt_code);
CREATE INDEX IF NOT EXISTS idx_invoices_token ON invoices(public_token);
CREATE INDEX IF NOT EXISTS idx_receipts_token ON receipts(public_token);
CREATE INDEX IF NOT EXISTS idx_portfolio_items_slug ON portfolio_items(slug);
CREATE INDEX IF NOT EXISTS idx_portfolio_items_category ON portfolio_items(category_id, visible, featured DESC, sort_order ASC);
CREATE INDEX IF NOT EXISTS idx_portfolio_images_item ON portfolio_images(item_id, is_cover DESC, sort_order ASC);
CREATE INDEX IF NOT EXISTS idx_audit_log_created_at ON audit_log(created_at DESC);

-- -----------------------------------------------------------------------------
-- 5. ROW LEVEL SECURITY (RLS ENABLED WITH NO PUBLIC ACCESS)
-- -----------------------------------------------------------------------------
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- -----------------------------------------------------------------------------
-- 6. SUPABASE STORAGE BUCKETS (portfolio-public, portfolio-private, order-files)
-- -----------------------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'portfolio-public',
  'portfolio-public',
  TRUE,
  8388608,
  ARRAY['image/webp', 'image/jpeg', 'image/png']
) ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'portfolio-private',
  'portfolio-private',
  FALSE,
  8388608,
  ARRAY['image/webp', 'image/jpeg', 'image/png']
) ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'order-files',
  'order-files',
  FALSE,
  10485760,
  ARRAY['image/webp', 'image/jpeg', 'image/png', 'application/pdf']
) ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 7. SEED INITIAL SETTINGS, SERVICES, AND PORTFOLIO CATEGORIES
-- -----------------------------------------------------------------------------
INSERT INTO settings (
  id,
  business_name,
  description,
  whatsapp_display,
  whatsapp_wa_me,
  facebook_link,
  email,
  working_hours,
  mpesa_till_or_paybill,
  mpesa_transaction_type,
  logo_url
) VALUES (
  1,
  'Mannu Visuals',
  'Online cyber and graphic design services. All work is done online.',
  '0796 431 953',
  '254796431953',
  'Mannu Visuals KE (TikTok, Facebook, Instagram and YouTube)',
  'mannuvisualscyber@gmail.com',
  '[add hours here]',
  'M-Pesa [Till/Paybill number to be added]',
  'CustomerPayBillOnline',
  '/logo.svg'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO portfolio_categories (name, slug, sort_order) VALUES
  ('Wedding cards', 'wedding-cards', 1),
  ('Funeral programs', 'funeral-programs', 2),
  ('Posters and flyers', 'posters-and-flyers', 3),
  ('Logos', 'logos', 4),
  ('Birthday cards', 'birthday-cards', 5),
  ('Church posters', 'church-posters', 6),
  ('Company profiles', 'company-profiles', 7),
  ('Social media banners', 'social-media-banners', 8)
ON CONFLICT (slug) DO NOTHING;
