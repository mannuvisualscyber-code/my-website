/**
 * Firestore Security Rules Test Specification (Dirty Dozen Verification)
 * Verifies that all 12 adversarial payloads in security_spec.md return PERMISSION_DENIED.
 */

export interface SecurityTestCase {
  id: number;
  name: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  auth: { uid: string; email: string; email_verified: boolean } | null;
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED' | 'ALLOWED';
}

export const DIRTY_DOZEN_TESTS: SecurityTestCase[] = [
  {
    id: 1,
    name: 'Shadow Field Injection on Order Create',
    operation: 'create',
    path: '/orders/order_1001',
    auth: { uid: 'owner_1', email: 'mannuvisualscyber@gmail.com', email_verified: true },
    payload: {
      orderNumber: 'MV-1001',
      customerName: 'Jane Wanjiku',
      customerPhoneMasked: '2547****1953',
      serviceCategory: 'government',
      serviceName: 'KRA PIN registration',
      status: 'Received',
      priceKes: 0,
      paidKes: 0,
      ownerId: 'owner_1',
      isVerifiedGhostField: true,
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Unverified Email Spoof Attack',
    operation: 'create',
    path: '/portfolio_items/item_1',
    auth: { uid: 'spoof_uid', email: 'mannuvisualscyber@gmail.com', email_verified: false },
    payload: {
      title: 'Wedding Card Sample',
      category: 'Cards',
      description: 'Floral print card',
      imageUrl: 'https://example.com/card.png',
      visible: true,
      sortOrder: 1,
      ownerId: 'spoof_uid',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Self-Assigned OWNER Role Escalation',
    operation: 'create',
    path: '/admins/attacker_uid',
    auth: { uid: 'attacker_uid', email: 'attacker@example.com', email_verified: true },
    payload: {
      uid: 'attacker_uid',
      email: 'attacker@example.com',
      role: 'OWNER',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Identity Spoofing (ownerId mismatch)',
    operation: 'create',
    path: '/orders/order_1002',
    auth: { uid: 'owner_1', email: 'mannuvisualscyber@gmail.com', email_verified: true },
    payload: {
      orderNumber: 'MV-1002',
      customerName: 'Peter Kamau',
      customerPhoneMasked: '2547****0000',
      serviceCategory: 'graphic_design',
      serviceName: 'Business logos',
      status: 'Received',
      priceKes: 0,
      paidKes: 0,
      ownerId: 'different_uid',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Timestamp Forgery (forged createdAt)',
    operation: 'create',
    path: '/audit_logs/log_1',
    auth: { uid: 'owner_1', email: 'mannuvisualscyber@gmail.com', email_verified: true },
    payload: {
      action: 'LOGIN',
      actorEmail: 'mannuvisualscyber@gmail.com',
      targetId: 'session_1',
      details: 'Logged in',
      ownerId: 'owner_1',
      createdAt: '2020-01-01T00:00:00Z',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Immortal Field Mutation (ownerId modified on Update)',
    operation: 'update',
    path: '/orders/order_1001',
    auth: { uid: 'owner_1', email: 'mannuvisualscyber@gmail.com', email_verified: true },
    payload: {
      ownerId: 'hijacked_owner',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'ID Poisoning Attack (invalid characters in doc ID)',
    operation: 'create',
    path: '/orders/invalid$id!@#',
    auth: { uid: 'owner_1', email: 'mannuvisualscyber@gmail.com', email_verified: true },
    payload: {},
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Value Poisoning on Whitelisted Update Key',
    operation: 'update',
    path: '/orders/order_1001',
    auth: { uid: 'owner_1', email: 'mannuvisualscyber@gmail.com', email_verified: true },
    payload: {
      status: 'INVALID_STATUS_VALUE',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Terminal State Bypass by Non-Owner',
    operation: 'update',
    path: '/orders/delivered_order_1',
    auth: { uid: 'staff_1', email: 'staff@example.com', email_verified: true },
    payload: {
      status: 'In progress',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'PII Blanket Read on /orders by Unrelated User',
    operation: 'get',
    path: '/orders/order_1001',
    auth: { uid: 'random_user', email: 'random@example.com', email_verified: true },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Hidden Portfolio Item Read by Public Visitor',
    operation: 'get',
    path: '/portfolio_items/hidden_item_1',
    auth: null,
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Audit Log Tampering (Delete Attempt)',
    operation: 'delete',
    path: '/audit_logs/log_1',
    auth: { uid: 'owner_1', email: 'mannuvisualscyber@gmail.com', email_verified: true },
    expectedResult: 'PERMISSION_DENIED',
  },
];
