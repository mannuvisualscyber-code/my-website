# Mannu Visuals — Online Cyber and Graphic Design Services

A complete, calm, mobile-first web application and administrative system for **Mannu Visuals** in Kenya, deployed on **Netlify** (Vite SPA + Netlify Functions) and connected to **Supabase** (PostgreSQL + Supabase Storage).

---

## 1. Architecture & Security

- **Server-Side Supabase Only**: `@supabase/supabase-js` is used strictly inside `netlify/functions/_supabase.js` and imported by the Netlify Functions in `netlify/functions/`.
- **Zero Browser Exposure**: The browser never talks directly to Supabase and never receives `SUPABASE_URL` or `SUPABASE_SERVICE_KEY`. All client interactions go through `/.netlify/functions/*`.
- **Database Tables Used (14 Tables)**:
  - `services`, `customers`, `orders`, `order_files`, `invoices`, `invoice_items`, `payments`, `receipts`, `portfolio_categories`, `portfolio_items`, `portfolio_images`, `admin_users`, `audit_log`, `settings`.
- **Database Functions Used**:
  - `record_mpesa_payment` (called on `ResultCode = 0` in `netlify/functions/mpesa-callback.ts`)
  - `record_mpesa_failure` (called on non-zero `ResultCode` in `netlify/functions/mpesa-callback.ts`)
- **Storage Buckets Used**:
  - `portfolio-public` (public WebP thumbnails and viewer images)
  - `portfolio-private` (private original design files)
  - `order-files` (private customer uploads and finished deliverables accessed via signed URLs)

---

## 2. Environment Variables

Configure the following variables in **Netlify Site Settings → Environment variables** (use placeholders in `.env.example`, never commit real keys):

| Variable | Description |
| :--- | :--- |
| `SUPABASE_URL` | Your Supabase project URL (`https://<project-ref>.supabase.co`) |
| `SUPABASE_SERVICE_KEY` | Your Supabase secret service key (`sb_secret_...`) — server-side only |
| `SESSION_SECRET` | Random secret string used to HMAC-sign admin session tokens |
| `ADMIN_OWNER_USER` | Initial `OWNER` username created on first run if `admin_users` is empty |
| `ADMIN_OWNER_PASSWORD` | Initial `OWNER` password (hashed with `scrypt` before storing in `admin_users`) |
| `DARAJA_KEY` | Safaricom Daraja Consumer Key |
| `DARAJA_SECRET` | Safaricom Daraja Consumer Secret |
| `DARAJA_SHORTCODE` | Safaricom Business Shortcode (e.g. `174379` for sandbox) |
| `DARAJA_PASSKEY` | Safaricom Lipa Na M-Pesa Online Passkey |
| `DARAJA_ENV` | `sandbox` or `production` |
| `DARAJA_TXN_TYPE` | `CustomerPayBillOnline` or `CustomerBuyGoodsOnline` |
| `DARAJA_TILL` | Paybill or Buy Goods Till number (`PartyB`) |
| `DARAJA_CALLBACK_URL` | `https://<your-site>.netlify.app/.netlify/functions/mpesa-callback` |
| `DARAJA_CALLBACK_SECRET` | Optional webhook verification secret |
| `APP_URL` | Public URL of your deployed site |

---

## 3. Netlify Functions (`netlify/functions/`)

- `netlify/functions/_supabase.js` — Shared Supabase client (`createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)`), HMAC session token signing (`SESSION_SECRET`), password hashing (`scrypt`), Kenyan phone normalisation (`2547XXXXXXXX`), and initial `OWNER` seeding.
- `netlify/functions/order-status.ts` — Loads `settings`, `services`, and `portfolio_categories` on bootstrap; tracks orders by `order_number` (`MV-XXXX`) or `tracking_token`; serves public invoices and receipts by `public_token`; generates signed download URLs from `order-files`.
- `netlify/functions/create-order.ts` — Matches or creates customers in `customers` by normalised phone (`2547XXXXXXXX`); inserts into `orders` using database defaults for `order_number` and `tracking_token`; generates signed upload URLs for `order-files` and records file metadata in `order_files`.
- `netlify/functions/stkpush.ts` — Initiates Safaricom Daraja STK Push and inserts a `PENDING` row with `method = 'MPESA'` and `checkout_request_id` in `payments`.
- `netlify/functions/mpesa-callback.ts` — Calls `record_mpesa_payment` when `ResultCode = 0` or `record_mpesa_failure` when failed/cancelled, and always returns `{ ResultCode: 0, ResultDesc: "Accepted" }`.
- `netlify/functions/payment-status.ts` — Queries `payments` by `checkout_request_id` so the tracking page can display `SUCCESS`, `CANCELLED`, or `FAILED`.
- `netlify/functions/portfolio-list.ts` — Queries `portfolio_categories`, `portfolio_items`, and `portfolio_images` while stripping private `original_path`.
- `netlify/functions/portfolio-upload-url.ts` — Creates signed upload URLs and uploads resized WebP variants to `portfolio-public` and originals to `portfolio-private`.
- `netlify/functions/portfolio-admin.ts` — Creates, updates, reorders, and deletes portfolio items (`portfolio_items` + `portfolio_images`) and categories (`portfolio_categories`).
- `netlify/functions/admin-api.ts` — Admin authentication against `admin_users` (with `failed_attempts` and `locked_until` lockout), audit logging to `audit_log`, order management, deliverable uploads to `order-files`, invoices (`invoices` + `invoice_items`), manual payments (`payments` + `receipts`), services, settings, and the 9-point verification suite.
