# Security Specification — Mannu Visuals

## 1. Data Invariants

1. **Default Deny & Verified Identity**: Every path is denied by default. All write operations require an authenticated user (`request.auth != null`) with a verified email (`request.auth.token.email_verified == true`).
2. **Bootstrapped Owner & Database RBAC**: Role checks never rely on client-supplied custom claims. `isOwnerAdmin()` checks either the bootstrapped owner email (`mannuvisualscyber@gmail.com` with `email_verified == true`) or an existing `/admins/$(request.auth.uid)` document with `role == 'OWNER'`. `isStaffOrOwner()` checks `isOwnerAdmin()` or an existing `/admins/$(request.auth.uid)` document with `role in ['OWNER', 'STAFF']`.
3. **Strict Key & Schema Validation (`isValid[Entity]`)**: Every `create` and `update` operation validates all field types, string length bounds, numeric bounds, regex patterns, and exact key allowlists (`hasAll` + `hasOnly`).
4. **Immortal Fields & Temporal Integrity**: `createdAt` must equal `request.time` on creation and remain immutable on update (`incoming().createdAt == existing().createdAt`). `updatedAt` must equal `request.time` on both create and update. `ownerId` and `uid` are immutable after creation.
5. **Terminal State Locking**: Once an `/orders/{orderId}` document reaches `status == 'Delivered'`, non-owner users cannot mutate it further (`existing().status != 'Delivered' || isOwnerAdmin()`).
6. **PII Isolation & Query Enforcer**: `/admins`, `/orders`, and `/audit_logs` are never publicly readable. `allow list` on `/orders` and `/audit_logs` enforces `resource.data.ownerId == request.auth.uid || isBootstrappedOwner()`. `/portfolio_items` only allows public reads when `resource.data.visible == true`.

## 2. The "Dirty Dozen" Payloads

1. **Shadow Field Injection on Order Create**: Includes unauthorized field `{"isVerified": true}` alongside required fields -> Rejected by `data.keys().hasOnly(...)`.
2. **Unverified Email Spoof Attack**: Token has `email: "mannuvisualscyber@gmail.com"` but `email_verified: false` -> Rejected by `isVerifiedUser()`.
3. **Self-Assigned OWNER Role Escalation**: Non-owner user attempts to create `/admins/{uid}` with `role: "OWNER"` -> Rejected because only `isOwnerAdmin()` can create or update `/admins/{adminId}`.
4. **Identity Spoofing (`ownerId` mismatch)**: Authenticated user attempts to create `/orders/ord_1` with `ownerId: "someone_else"` -> Rejected by `data.ownerId == request.auth.uid`.
5. **Timestamp Forgery (Past/Future `createdAt`)**: Client sends forged `createdAt` timestamp not matching `request.time` -> Rejected by `incoming().createdAt == request.time`.
6. **Immortal Field Mutation (`createdAt` or `ownerId` modified on Update)**: Update payload modifies `createdAt` or `ownerId` -> Rejected by immutability guards.
7. **ID Poisoning Attack**: Document ID contains invalid characters or exceeds 128 chars -> Rejected by `isValidId(id)`.
8. **Value Poisoning on Whitelisted Update Key**: Update to `/orders/{orderId}` changes `status` to `"HACKED_STATUS"` -> Rejected by `isValidOrderRecord(incoming())`.
9. **Terminal State Bypass**: Staff member attempts to update an order whose existing `status` is `"Delivered"` -> Rejected by terminal state gate.
10. **PII Blanket Read on `/orders`**: Authenticated regular user attempts `get` or `list` on `/orders` belonging to another user -> Rejected by ownership/admin check.
11. **Hidden Portfolio Scraping**: Unauthenticated user attempts `get` or `list` on `/portfolio_items` where `visible == false` -> Rejected by `resource.data.visible == true`.
12. **Audit Log Tampering (Update/Delete)**: Any user attempts to update or delete an existing `/audit_logs/{logId}` document -> Rejected (`allow update, delete: if false;`).
